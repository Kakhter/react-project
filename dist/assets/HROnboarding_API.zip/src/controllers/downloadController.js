const { generateExcel } = require("../services/downloadService");

const downloadCandidates = async (req, res) => {
  try {
    const tables = [
      `"PersonalDetails"`,
      `"EducationTran"`,
      `"CertificateTran"`,
      `"PreviousWorkTran"`,
    ];

    const buffer = await generateExcel(tables);

    res.setHeader(
      "Content-Disposition",
      "attachment; filename=candidates_data.xlsx"
    );
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.send(buffer);
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
};

module.exports = { downloadCandidates };
