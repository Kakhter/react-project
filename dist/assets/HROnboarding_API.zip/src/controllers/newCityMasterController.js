const NewCity = require("../models/newCityModel");

exports.createNewCity = async (req, res) => {
  try {
    const city = await NewCity.create(req.body);
    res.status(201).json(city);
  } catch (error) {
    console.error("Error creating city:", error);
    res.status(500).json({ message: "Failed to create city" });
  }
};

exports.getAllNewCities = async (req, res) => {
  try {
    const cities = await NewCity.findAll();
    res.status(200).json(cities);
  } catch (error) {
    console.error("Error fetching cities:", error);
    res.status(500).json({ message: "Failed to fetch cities" });
  }
};

exports.getCitiesByDistrictId = async (req, res) => {
  try {
    const cities = await NewCity.findAll({
      where: { DistrictID: req.params.districtID },
    });

    res.status(200).json(cities);
  } catch (error) {
    console.error("Error fetching cities:", error);
    res.status(500).json({ message: "Failed to fetch cities" });
  }
};

exports.getCityById = async (req, res) => {
  try {
    const city = await NewCity.findByPk(req.params.NewCityID);

    if (city) {
      // res.json(country);
      res.status(200).json(city);
    } else {
      res.status(404).json({ error: "City not found" });
    }
  } catch (error) {
    console.error("Error fetching city:", error);
    res.status(500).json({ error: error.message });
  }
};
