// routes/downloadRoutes.js
const express = require("express");
const { downloadCandidates } = require("../controllers/downloadController");

const router = express.Router();

// Route for downloading candidates data
router.get("/download-candidates", downloadCandidates);

module.exports = router;
