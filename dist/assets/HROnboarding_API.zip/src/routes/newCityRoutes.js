const express = require("express");
const newCityMasterController = require("../controllers/newCityMasterController");
// const {
//   authorizeRoles,
//   isPasswordChanged,
// } = require("../middleware/authMiddleware");

const router = express.Router();

// Create a new city
router.post(
  "/",
  //   authorizeRoles([1, 2, 3]),
  //   isPasswordChanged(),
  newCityMasterController.createNewCity
);

// Get all cities
router.get(
  "/",
  //   authorizeRoles([1, 2, 3]),
  //   isPasswordChanged(),
  newCityMasterController.getAllNewCities
);

// IMP -- Get cities by country ID
// router.get('/country/:countryId', cityController.getCitiesByCountryId);

// router.put(
//   "/:NewCityId",
//   authorizeRoles([1, 2, 3]),
//   isPasswordChanged(),
//   newCityMasterController.updateCity
// );

//search city according to the state
router.get(
  "/districtID/:districtID",
  //   authorizeRoles([1, 2, 3]),
  //   isPasswordChanged(),
  newCityMasterController.getCitiesByDistrictId
);

//city according to id
router.get("/:NewCityID", newCityMasterController.getCityById);
module.exports = router;
