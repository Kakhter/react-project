// // models/candidateModel.js

// const pool = require("../config/pool"); // Your database pool configuration

// const getCandidatesData = async (table) => {
//   try {
//     const result = await pool.query(`SELECT * FROM public.${table}`);
//     // const result = await pool.query("SELECT * FROM public.get_candidate()");
//     return result.rows; // Returning rows of data
//   } catch (error) {
//     throw new Error("Database query failed: " + error.message);
//   }
// };

// module.exports = { getCandidatesData };

// models/candidateModel.js

const pool = require("../config/pool"); // Your database pool configuration

const getCandidatesData = async (table) => {
  try {
    let query;
    if (table === `"PersonalDetails"`) {
      query = `
        SELECT pd.*, u."EmpID", u."GyansysEmail" 
        FROM public.${table} pd
        JOIN public."Users" u ON pd."UserID" = u."UserID";
      `;
    } else {
      // Default query for other tables
      query = `SELECT * FROM public.${table}`;
    }

    const result = await pool.query(query);
    return result.rows; // Returning rows of data
  } catch (error) {
    throw new Error("Database query failed: " + error.message);
  }
};

module.exports = { getCandidatesData };
