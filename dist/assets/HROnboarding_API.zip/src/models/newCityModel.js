const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
//const State = require('./stateModel'); // Import after defining
const NewCity = sequelize.define(
  "NewCity",
  {
    NewCityID: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    NewCityName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    DistrictID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "CityMaster",
        key: "CityID",
      },
      onDelete: "CASCADE",
      onUpdate: "CASCADE",
    },
  },
  {
    tableName: "NewCityMaster",
    timestamps: false,
  }
);

module.exports = NewCity;
