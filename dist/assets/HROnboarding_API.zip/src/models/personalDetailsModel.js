// models/personalDetails.js
const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const User = require("./userModel");
const City = require("./cityModel");
const State = require("./stateModel");
const Country = require("./countryMasterModel");
const NewCity = require("./newCityModel");

const PersonalDetails = sequelize.define(
  "PersonalDetails",
  {
    PersonalDetailsID: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    UserID: {
      type: DataTypes.INTEGER,
      allowNull: false,
      unique: true,
      references: {
        model: User,
        key: "UserID",
      },
      onDelete: "CASCADE",
    },
    FirstName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    MiddleName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    LastName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    Gender: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    BirthCountryID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: Country,
        key: "CountryID",
      },
      onDelete: "CASCADE",
    },
    BloodGroup: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    MaritalStatus: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    DOB: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    BirthPlaceCityID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: City,
        key: "CityID",
      },
      onDelete: "CASCADE",
    },
    BirthStateID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: State,
        key: "StateID",
      },
      onDelete: "CASCADE",
    },
    Nationality: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    PanNo: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
    },
    AadharNo: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
    },
    Submitted: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    Remarks: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    Accepted: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    Rejected: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    CreatedBy: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    CreatedDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    UpdatedBy: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    UpdatedDate: {
      type: DataTypes.DATE,
      allowNull: false,
    },

    PermanentAddress: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    CurrentAddress: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    PassportNumber: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    ContactNumber: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    NewCityID: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: NewCity,
        key: "NewCityID",
      },
      onDelete: "CASCADE",
    },
    EmergencyContact: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    EmergencyContactPersonName: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    Relationship: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    UAN: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    RelationshipWithOrg: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    totalExperienceYears: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    totalExperienceMonths: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    totalRelevenatExperienceYears: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    totalRelevantExperienceMonths: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    visaStatus: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    visaEndDate: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },

  {
    tableName: "PersonalDetails",
    timestamps: false,
  }
);

PersonalDetails.belongsTo(User, {
  foreignKey: "UserID",
  as: "User",
});

module.exports = PersonalDetails;
