const sequelize = require("./config/db");
const NewCity = require("./models/newCityModel"); // Adjust the path

(async () => {
  try {
    await sequelize.authenticate();

    await sequelize.sync();
    console.log("NewCity table synced successfully.");

    const newCity = await NewCity.create({
      NewCityName: "Abhishek",
      DistrictID: 1,
    });

    console.log("New city added:", newCity.toJSON());
  } catch (error) {
    console.error("Error during setup:", error);
  } finally {
    await sequelize.close();
  }
})();
