// services/downloadService.js
const XLSX = require("xlsx");
const { getCandidatesData } = require("../models/candidateModel");

const excludedColumns = [
  "CreatedBy",
  "UpdatedBy",
  "CreatedDate",
  "UpdatedDate",
];

const removeExcludedColumns = (data) => {
  return data.map((row) => {
    const filteredRow = {};
    Object.keys(row).forEach((key) => {
      if (!excludedColumns.includes(key)) {
        filteredRow[key] = row[key];
      }
    });
    return filteredRow;
  });
};

// Function to generate Excel file for the tables
const generateExcel = async (tables) => {
  const workbook = XLSX.utils.book_new();

  for (const table of tables) {
    const result = await getCandidatesData(table);
    const filteredRows = removeExcludedColumns(result);

    // Convert data to a worksheet
    const worksheet = XLSX.utils.json_to_sheet(filteredRows);

    // Add the worksheet to the workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, table);
  }

  return XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
};
// const generateExcel = async (tables) => {
//   const workbook = XLSX.utils.book_new();
//   let combinedData = [];

//   for (const table of tables) {
//     const result = await getCandidatesData(table);
//     const filteredRows = removeExcludedColumns(result);

//     const tableData = filteredRows.map((row) => ({ TableName: table, ...row }));

//     combinedData = combinedData.concat(tableData);
//   }

//   const worksheet = XLSX.utils.json_to_sheet(combinedData);

//   worksheet["!cols"] = Object.keys(combinedData[0] || {}).map(() => ({
//     wch: 20,
//   }));

//   XLSX.utils.book_append_sheet(workbook, worksheet, "All Data");

//   return XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
// };

module.exports = { generateExcel };
