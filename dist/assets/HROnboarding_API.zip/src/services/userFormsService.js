const { Op } = require("sequelize");
const PersonalDetails = require("../models/personalDetailsModel");
const User = require("../models/userModel");
const nodemailer = require("nodemailer");
const executeQuery = require("../config/postgres");

const getAll = async () => {
  try {
    const getIdsWithSubmittedTrue = async (model) => {
      const records = await model.findAll({
        attributes: ["UserID"],
        where: { Submitted: true, Accepted: false, Rejected: false },
      });
      return records.map(
        (record) => record.UserID,
        (record) => record.Accepted,
        (record) => record.Rejected
      );
    };

    const personalUserIds = await getIdsWithSubmittedTrue(PersonalDetails);
    // const educationUserIds = await getIdsWithSubmittedTrue(Education);
    // const previousGyanSysEmpUserIds = await getIdsWithSubmittedTrue(PreviousGyanSysEmp);
    // const previousWorkUserIds = await getIdsWithSubmittedTrue(PreviousWork);

    // const commonUserIds = personalUserIds
    //     .filter(UserID => educationUserIds.includes(UserID))
    //     .filter(UserID => previousGyanSysEmpUserIds.includes(UserID))
    //     .filter(UserID => previousWorkUserIds.includes(UserID));

    if (personalUserIds.length === 0) {
      return [];
    }

    const userDetails = await User.findAll({
      where: {
        UserID: {
          [Op.in]: personalUserIds,
        },
      },
    });

    return userDetails;
  } catch (error) {
    console.error("Error fetching details:", error);
    throw error;
  }
};

const markAsSubmitted = async (userId) => {
  try {
    await PersonalDetails.update(
      {
        Submitted: true,
        Accepted: false,
        Rejected: false,
        UpdatedDate: new Date(),
      },
      { where: { UserID: userId } }
    );
    // await Education.update({ Submitted: true }, { where: { UserID: userId } });
    // await PreviousGyanSysEmp.update({ Submitted: true }, { where: { UserID: userId } });
    // await PreviousWork.update({ Submitted: true }, { where: { UserID: userId } });
  } catch (error) {
    console.error("Error updating records:", error);
    throw error;
  }
};

const markAccepted = async (userId, body) => {
  try {
    await PersonalDetails.update(
      {
        Accepted: true,
        Rejected: false,
        Submitted: true,
        Remarks: body.Remarks,
        UpdatedDate: new Date(),
      },
      { where: { UserID: userId } }
    );
    const user = await User.findOne({
      where: {
        UserID: userId,
      },
    });
    const email = user.Email;
    var bodyHTML = body.Remarks;
    bodyHTML = bodyHTML.replaceAll("\n", "<br/>");
    await sendEmailNotification(
      email,
      "Documents Verified and Accepted by HR",
      `<b>Dear ${user.FirstName},</b><br/><br/>
      Congratulations! We are pleased to inform you that your submitted documents have been successfully verified. We are excited to proceed with your onboarding journey at GyanSys Infotech. Our team will be in touch soon with further instructions and details about the next steps.<br/><br/>
      If you have any questions or require additional information, please do not hesitate to reach out to us at <b>hr.in@gyansys.com</b>.<br/><br/>
      Welcome to the GyanSys family!<br/><br/>
        
    
    Best regards,<br/>
    HR Team<br/>
    GyanSys Infotech <br/>`
    );
  } catch (error) {
    console.error("Error updating records:", error);
    throw error;
  }
};

const markRejected = async (userId, body) => {
  try {
    await PersonalDetails.update(
      {
        Rejected: true,
        Accepted: false,
        Submitted: false,
        Remarks: body.Remarks,
        UpdatedDate: new Date(),
      },
      { where: { UserID: userId } }
    );
    const user = await User.findOne({
      where: {
        UserID: userId,
      },
    });
    const email = user.Email;
    var bodyHTML = body.Remarks;
    bodyHTML = bodyHTML.replaceAll("\n", "<br/>");

    await sendEmailNotification(
      email,
      "Documents verified and Rejected by HR",

      `<b>Dear ${user.FirstName},</b><br/><br/>

      Thank you for submitting your documents for the onboarding process. After a thorough review, we regret to inform you that the submitted documents do not meet our verification requirements.<br/><br/>
      <b>Reason(s) for Rejection:</b><br/>
     <span style="color:red"> ${bodyHTML}</span>
     
      <br/><br/>
      To proceed with the onboarding process, kindly review and resubmit the required documents within 2 working days. You can upload the updated documents through the onboarding portal (http://192.168.7.187/)
      For any assistance or clarification, please feel free to contact us at <b>hr.in@gyansys.com</b>
      We appreciate your prompt attention to this matter.<br/><br/>
    Best regards,<br/>
    HR Team<br/>
    GyanSys Infotech <br/>`
    );
    return "Rejected and sent email to candidate.";
  } catch (error) {
    console.error("Error updating records:", error);
    return "Error while rejecting the request.";
    // throw error;
  }
};

const sendEmailNotification = async (email, subject, text) => {
  let transporter = nodemailer.createTransport({
    // service: 'gmail',
    // auth: {
    //     user: 'gyansysonboarding@gmail.com',
    //     pass: 'lkggbneaqfoxoirc'
    // }
    service: "gmail",
    auth: {
      user: "gyansysboarding@gmail.com",
      pass: "cjft vmka dqcz xryw",
    },
  });

  let mailOptions = {
    //from: 'gyansysonboarding@gmail.com',
    from: "2041011089.abhishekkumar@gmail.com",
    to: email,
    subject: subject,
    html: text,
  };

  return transporter.sendMail(mailOptions);
};

const getAllAccepted = async () => {
  try {
    const getIdsWithAcceptedTrue = async (model) => {
      const records = await model.findAll({
        attributes: ["UserID"],
        where: { Accepted: true },
      });
      return records.map((record) => record.UserID);
    };
    const AcceptedUserIds = await getIdsWithAcceptedTrue(PersonalDetails);
    if (AcceptedUserIds.length === 0) {
      return [];
    }

    const AcceptedUserDetails = await User.findAll({
      where: {
        UserID: {
          [Op.in]: AcceptedUserIds,
        },
      },
    });

    return AcceptedUserDetails;
  } catch (error) {
    console.error("Error updating records:", error);
    throw error;
  }
};

const getPersonalDetailByID = async () => {
  var result = await executeQuery(`select * from test`);
  return result;
  // .then((result) => {
  //     //res.status(200).send(result);
  //     console.log("-------------------1");
  //     console.log(result);
  //   })
  // .catch((error) => {
  //     console.error("Error executing query:", error);
  //     //res.status(500).send(error);
  // });
};

module.exports = {
  getAll,
  markAsSubmitted,
  markAccepted,
  markRejected,
  getAllAccepted,
  getPersonalDetailByID,
};
