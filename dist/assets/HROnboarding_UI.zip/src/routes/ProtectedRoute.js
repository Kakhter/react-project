import React, { useContext } from "react";
import UserContext from "../components/userpages/context/UserContext";
import { Outlet } from "react-router-dom";
import { Navigate } from "react-router-dom";

const ProtectedRoute = ({ allowedRoles }) => {
  const { user } = useContext(UserContext);
  if (!user || !allowedRoles.includes(user.RoleID)) {

    localStorage.removeItem('user');
    localStorage.removeItem('token');
    return <Navigate to="/" />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
