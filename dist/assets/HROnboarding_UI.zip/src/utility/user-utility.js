import React from "react";
import axios from "axios";
import { jwtDecode } from "jwt-decode";

const userUtility_isGyansysEmp = async () => {
  const token = localStorage.getItem("token");
  const decoded = jwtDecode(token);
  const userID = decoded.UserID;

  const previousGyansysDetails = await axios.get(
    `${process.env.REACT_APP_BASEURL}/previousGyanSysEmps/${userID}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
  return previousGyansysDetails;
};

const userUtility_isSubmitted = async () => {
  const token = localStorage.getItem("token");
  const decoded = jwtDecode(token);
  const userID = decoded.UserID;

  const IsSubmitted = await fetch(
    `${process.env.REACT_APP_BASEURL}/personaldetails/${userID}`,
    {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  const response = await IsSubmitted.json();
  const isSubmitted = response.Submitted;
  console.log(isSubmitted);

  return isSubmitted;
};

const userUtility_isExperienced = async () => {
  const token = localStorage.getItem("token");
  const decoded = jwtDecode(token);
  const userID = decoded.UserID;

  const isExperienced = await fetch(
    `${process.env.REACT_APP_BASEURL}/personaldetails/${userID}`,
    {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  const response = await isExperienced.json();
  const isMonthExperienced = response.totalExperienceMonths;
  const totalExperienceYears = response.totalExperienceYears;

  const totalMonths = totalExperienceYears * 12 + isMonthExperienced;

  console.log(totalMonths > 0);
  return totalMonths > 0;
};

export {
  userUtility_isSubmitted,
  userUtility_isGyansysEmp,
  userUtility_isExperienced,
};
