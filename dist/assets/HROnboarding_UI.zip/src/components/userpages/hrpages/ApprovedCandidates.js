import {
  Card,
  Divider,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Box,
  TextField,
  Button,
} from "@mui/material";
import { ArrowArcLeft } from "@phosphor-icons/react/dist/ssr";
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
 
const ApprovedCandidates = () => {
  const [rows, setRows] = useState([]);
  const [empIds, setEmpIds] = useState({});
  const [gyansysEmails, setGyansysEmails] = useState({});
  const [searchTerm, setSearchTerm] = useState("");
 
  const token = localStorage.getItem("token");
 
  const navigate = useNavigate();
 
  const handleClick = () => {
    navigate("/Overview");
  };
 
  const handleDownload = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_BASEURL}/api/download-candidates`,
        {
          responseType: "blob",
        }
      );
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "candidates_data.xlsx");
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      console.error("Error downloading the file:", err);
    }
  };
 
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${process.env.REACT_APP_BASEURL}/userforms/getacceptedusers`
        );
        console.log(response.data);
        setRows(response.data);
 
        const empId = {};
        const gyansysEmail = {};
 
        response.data.forEach((user) => {
          if (user.EmpID) empId[user.UserID] = user.EmpID;
          if (user.GyansysEmail) gyansysEmail[user.UserID] = user.GyansysEmail;
        });
        setEmpIds(empId);
        setGyansysEmails(gyansysEmail);
      } catch (error) {
        toast.error(error);
      }
    };
    fetchData();
  }, []);
 
  const handleInputChange = (userId, field, value) => {
    if (field === "EmpID") {
      setEmpIds((prev) => ({
        ...prev,
        [userId]: value,
      }));
    } else if (field === "GyansysEmail") {
      setGyansysEmails((prev) => ({
        ...prev,
        [userId]: value,
      }));
    }
  };
 
  const handleAddEmployee = async (userId) => {
    const empId = empIds[userId];
    const gyansysEmail = gyansysEmails[userId];
 
    if (!empId || !gyansysEmail) {
      toast.error("Please enter both Employee ID and Gyansys Email.");
      return;
    }
 
    try {
      // const rp = await axios.get(`${process.env.REACT_APP_BASEURL}/users`, {
      //   headers: {
      //     Authorization: `Bearer ${token}`,
      //   },
      // });
      // console.log(rp);
      const response = await axios.post(
        `${process.env.REACT_APP_BASEURL}/users/updateEmpID`,
        {
          UserID: userId,
          EmpID: empId,
          GyansysEmail: gyansysEmail,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const message =
        response?.data?.message ||
        "Employee ID and Gyansys Email added successfully!";
      toast.success(message);
    } catch (error) {
      const errorMessage =
        error.response?.data?.message ||
        "Failed to add Employee ID and Gyansys Email.";
      toast.error(errorMessage);
    }
  };
 
  const filteredRows = rows.filter((row) =>
    row.Email.toLowerCase().includes(searchTerm.toLowerCase())
  );
 
  return (
    <>
      
      <div style={{display:"flex", justifyContent:"space-between"}}>
        <div>
        <IconButton  onClick={handleClick}>
          <ArrowArcLeft />
        </IconButton>
        </div>
        <div>
        <Box sx={{ padding: "4px" }}>
          <TextField
            label="Search by Email"
            placeholder="Enter personal email to search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </Box>
        </div>
        <div > 
        <Button  sx={{marginTop:2, marginRight:5,bgcolor: "orange"}} variant="contained" onClick={handleDownload}>Download</Button>
        </div>
      </div>
      <Card sx={{ borderRadius: 4, margin: "8px" }}>
        <Box sx={{ overflowX: "auto" }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>FirstName</TableCell>
                <TableCell>MiddleName</TableCell>
                <TableCell>LastName</TableCell>
                <TableCell>Email</TableCell>
                <TableCell>New Employee ID</TableCell>
                <TableCell>Gyansys Email</TableCell>
                <TableCell></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredRows.map((row) => (
                <TableRow key={row.UserID}>
                  <TableCell>{row.FirstName}</TableCell>
                  <TableCell>{row.MiddleName}</TableCell>
                  <TableCell>{row.LastName}</TableCell>
                  <TableCell>{row.Email}</TableCell>
                  <TableCell>
                    <TextField
                    sx={{
                      '& .MuiInputBase-root': {
                        height: 30, width:100 // Adjust the height as needed
                      },
                    }}

                      placeholder="Enter Employee ID"
                      value={empIds[row.UserID] || ""}
                      onChange={(e) =>
                        handleInputChange(row.UserID, "EmpID", e.target.value)
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <TextField
                    sx={{
                      '& .MuiInputBase-root': {
                        height: 30 // Adjust the height as needed
                      },
                    }}
                      placeholder="Enter Gyansys Email"
                      value={gyansysEmails[row.UserID] || ""}
                      onChange={(e) =>
                        handleInputChange(
                          row.UserID,
                          "GyansysEmail",
                          e.target.value
                        )
                      }
                    />
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      onClick={() => handleAddEmployee(row.UserID)}
                    >
                      Update Employee
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
        <Divider />
      </Card>
     
      <ToastContainer />
    </>
  );
};
 
export default ApprovedCandidates;