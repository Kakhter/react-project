import {
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Button,
  Box,
} from "@mui/material";
import { ArrowArcLeft, Butterfly } from "@phosphor-icons/react";
import { userUtility_isSubmitted } from "../../utility/user-utility";
import { toast, ToastContainer } from "react-toastify";

import axios from "axios";
import { jwtDecode } from "jwt-decode";
import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

const UserReview = () => {
  const token = localStorage.getItem("token");

  const decodedToken = jwtDecode(token);
  const UserID = decodedToken.UserID;
  const [data, setData] = useState(null);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState(false);
  const [IsSubmitted, setIsSubmitted] = useState(true);
  const errorFormRef = useRef(false);
  const [docError, setDocError] = useState("");

  ///////////

  const validateRequiredDocument = (work, index) => { 
    // console.log(documents);
    // console.log(documents[index].DocTypeID);
    // console.log(documents[index].PreviousWorkID)
  
    //console.log("Work:", work);
      const foundDocs11 = documents.find(
      doc => doc.DocTypeID === 11 && doc.PreviousWorkID ==work.PreviousWorkID
      );
    const foundDocs12 = documents.find(
      doc => doc.DocTypeID === 12 && doc.PreviousWorkID ==work.PreviousWorkID
      );
    const docError = { Doc11: "", Doc12: "" };

      if(index==0) {
          if (!foundDocs11) {
            
              docError.Doc11 ="Relieving letter need to be submitted as soon as possible.";
          } 
          if (!foundDocs12) {
          
              docError.Doc12 = "Please upload payslips.";
              formValidation("", "");
          } 
      }
      else
      {
          if (!foundDocs11) {
             
              docError.Doc11 = "Please upload relieving letter.";
              formValidation("", "");
          } 
          // if (!foundDocs12) {
           
          //      docError.Doc12 = "Please upload payslips.";
          //     formValidation("", "");
          // }
      }
  //console.log(`Row ${index + 1}:`, work);
     
  //return remarks
  return docError;
      
  }





  const formSubmitted = async () => {
    setIsSubmitted(await userUtility_isSubmitted());
    // console.log(IsSubmitted);
    return IsSubmitted;
  };

  const finalSubmit = async () => {
    const token = localStorage.getItem("token");
    const decoded = jwtDecode(token);
    const userID = decoded.UserID;
    await axios.put(
      // process.env.REACT_APP_BASEURL + `/userforms/markallsubmitted/${userID}`,
      `${process.env.REACT_APP_BASEURL}/userforms/markallsubmitted/${userID}`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    setIsSubmitted(true);
    toast.info("You have submitted this form. Please wait for HR's response.");
  };

  const validateFields = (
    personalDetails,
    previousWorkTran,
    educationTran,
    previousGyanSysEmployeeDetails,
    certificationTran
  ) => {
    const errors = {};

    if (!personalDetails.FirstName) {
      errors.FirstName = "First Name is required";
    }

    if (!personalDetails.LastName) {
      errors.LastName = "Middle Name is required";
    }
    if (!personalDetails.Gender) {
      errors.Gender = "Gender is required";
    }
    if (!personalDetails.BirthCountryName) {
      errors.BirthCountryName = "Birth Country is required";
    }
    if (!personalDetails.BirthStateName) {
      errors.BirthStateName = "Birth State is required";
    }
    if (!personalDetails.BirthDistrictName) {
      errors.BirthDistrictName = "Birth District is required";
    }
    if (!personalDetails.BirthCityName) {
      errors.BirthCityName = "Birth City is required";
    }
    if (!personalDetails.DOB) {
      errors.DOB = "Date of Birth is required";
    }
    if (!personalDetails.ContactNumber) {
      errors.ContactNumber = "Contact Number is required";
    }
    if (!personalDetails.Nationality) {
      errors.Nationality = "Nationality is required";
    }
    if (!personalDetails.CurrentAddress) {
      errors.CurrentAddress = "Current Address is required";
    }
    if (!personalDetails.PermanentAddress) {
      errors.PermanentAddress = "Permanent Address is required";
    }
    if (!personalDetails.BloodGroup) {
      errors.BloodGroup = "Blood Group is required";
    }
    if (!personalDetails.MaritalStatus) {
      errors.MaritalStatus = "Marital Status is required";
    }
    if (!personalDetails.EmergencyContact) {
      errors.EmergencyContact = "Emergency Contact Number is required";
    }
    if (!personalDetails.EmergencyContactPersonName) {
      errors.EmergencyContactPersonName =
        "Emergency Contact Person Name is required";
    }
    if (!personalDetails.RelationshipWithOrg) {
      errors.RelationshipWithOrg = "Relationship with organization is required";
    }
    if (!personalDetails.Relationship) {
      errors.Relationship =
        "Relationship with emergency Contact Person is required";
    }

    if (educationTran) {
      if (!educationTran.InstituteName) {
        errors.InstituteName = "Institute Name is required";
      }
      if (!educationTran.BoardORUniversity) {
        errors.BoardORUniversity = "Board Or University is required";
      }
      if (!educationTran.PassedOn) {
        errors.PassedOn = "Date of Passing is required";
      }
      // } else {
      //   {
      //     errors.InstituteName = "Institute Name is required";
      //     errors.BoardORUniversity = "Board Or University is required";
      //     errors.PassedOn = "Date of Passing is required";
      //   }
    }

    return errors;
  };

  useEffect(() => {
    formSubmitted();
    errorFormRef.current = false;
    const fetchData = async () => {
      const token = localStorage.getItem("token");

      try {
        const response = await axios.get(
          `${process.env.REACT_APP_BASEURL}/users/getUserFormsDetails/${UserID}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        // console.log(response);

        if (
          response.data.formData.personalDetails.FirstName == "" ||
          response.data.formData.personalDetails.LastName == "" ||
          response.data.formData.personalDetails.Gender == "" ||
          response.data.formData.personalDetails.BloodGroup == "" ||
          response.data.formData.personalDetails.DOB == "" ||
          response.data.formData.personalDetails.BirthCityName == "" ||
          response.data.formData.personalDetails.BirthCountryName == "" ||
          response.data.formData.personalDetails.BirthDistrictName == "" ||
          response.data.formData.personalDetails.BirthStateName == "" ||
          response.data.formData.personalDetails.ContactNumber == "" ||
          response.data.formData.personalDetails.EmergencyContact == "" ||
          response.data.formData.personalDetails.MaritalStatus == "" ||
          response.data.formData.personalDetails.EmergencyContactPersonName ==
            "" ||
          response.data.formData.personalDetails.Relationship == "" ||
          response.data.formData.personalDetails.RelationshipWithOrg == "" ||
          (response.data.formData.personalDetails.AadharNo == "" &&
            response.data.formData.personalDetails.PanNo == "" &&
            response.data.formData.personalDetails.PassportNumber == "") ||
          response.data.formData.personalDetails.CurrentAddress == "" ||
          response.data.formData.personalDetails.PermanentAddress == "" ||
          response.data.formData.personalDetails.Nationality == ""
        ) {
          formValidation("", "");
        }

        if (response.data.formData.educationTran.length == 0) {
          formValidation("", "");
        }

        const arr = [];

        if (response.data.formData.documents.length > 0) {
          response.data.formData.documents.map((doc) => {
            arr.push(doc.DocTypeID);

            // formValidation(doc.DocTypeID == 1, "")

            // (formValidation(doc.DocTypeID == 3, "") &&
            //   formValidation(doc.DocTypeID == 4, "") &&
            //   formValidation(doc.DocTypeID == 5, ""));
          });
          if (arr.length >= 2) {
            const isFound = arr.includes(1);
            if (!isFound) {
              setDocError(
                "Personal Photo and One of the Government ID is required"
              );
              formValidation("", "");
            }
          } else {
            setDocError(
              "Personal Photo and One of the Government ID is required"
            );
            formValidation("", "");
          }
        } else {
          setDocError(
            "Personal Photo and One of the Government ID is required"
          );
          formValidation("", "");
        }

        const nationalityID =
          response.data.formData.personalDetails.Nationality;
        //Get Nationality in text not by id
        if (nationalityID) {
          const getNationalityByID = await fetch(
            `${process.env.REACT_APP_BASEURL}/countries/getNationalityByID/${nationalityID}`,
            {
              method: "GET",
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          const nationalityName = await getNationalityByID.json();

          response.data.formData.personalDetails.Nationality = nationalityName;
        }

        //////////////////////////////////////////

        const birthCountryID =
          response.data.formData.personalDetails.BirthCountryID;
        if (birthCountryID) {
          const getbirthCountryByID = await fetch(
            `${process.env.REACT_APP_BASEURL}/countries/${birthCountryID}`,
            {
              method: "GET",
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          const birthCountryName = await getbirthCountryByID.json();

          response.data.formData.personalDetails.BirthCountryID =
            birthCountryName;
        }

        //////state

        const birthStateID =
          response.data.formData.personalDetails.BirthStateID;
        if (birthStateID) {
          const getbirthStateByID = await fetch(
            `${process.env.REACT_APP_BASEURL}/states/${birthStateID}`,
            {
              method: "GET",
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          const birthStateName = await getbirthStateByID.json();

          response.data.formData.personalDetails.BirthStateID = birthStateName;
        }

        ///////////////////////district
        const birthDistrictID =
          response.data.formData.personalDetails.BirthPlaceCityID;

        if (birthDistrictID) {
          const getbirthDistrictByID = await fetch(
            `${process.env.REACT_APP_BASEURL}/cities/${birthDistrictID}`,
            {
              method: "GET",
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          const birthDistrictName = await getbirthDistrictByID.json();

          response.data.formData.personalDetails.BirthPlaceCityID =
            birthDistrictName;
        }

        ////////////////////////city

        const birthCityID = response.data.formData.personalDetails.NewCityID;
        if (birthCityID) {
          const getbirthCityByID = await fetch(
            `${process.env.REACT_APP_BASEURL}/newCity/${birthCityID}`,
            {
              method: "GET",
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

          const birthCityName = await getbirthCityByID.json();

          response.data.formData.personalDetails.NewCityID = birthCityName;
        }

        ////validations
        const validationErrors = validateFields(
          response.data.formData.personalDetails
        );
        setErrors(validationErrors);
        setData(response.data);
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };
    fetchData();
  }, [UserID]);
  //function to handle the accept the form

  const personalDetails = data ? data.formData.personalDetails : [];

  const educationTran = data
    ? data.formData.educationTran.sort((a, b) => a.EduOrder - b.EduOrder)
    : [];


  //const previousWorkTran = data ? data.formData.previousWorkTran : [];
  const previousWorkTran = data
  ? data.formData.previousWorkTran.sort((b, a) => new Date(a.EndDate) - new Date(b.EndDate))
  : [];

  const previousGyanSysEmployeeDetails = data
    ? data.formData.previousGyanSysEmployeeDetails
    : [];

  const documents = data ? data.formData.documents : [];
  const certificationTran = data ? data.formData.certificationTran : [];
  const navigate = useNavigate();

  // const formValidation = (e, e2) => {
  //   if (!e && e2 != "Post Graduate") {
  //     errorFormRef.current = true;
  //   }
  //   // alert("bac", e);
  // };

  const formValidation = (fieldValue, educDescription) => {
    // Skip validation for optional sections
    const optionalSections = [
      "Post Graduate",
      "Other Qualification-1 (If any)",
      "Other Qualification-2 (If any)",
      "Other Qualification-3 (If any)",
    ];

    if (optionalSections.includes(educDescription)) {
      return; // Skip validation for these sections
    }

    // Set errorFormRef.current to true only if the fieldValue is invalid
    if (!fieldValue) {
      errorFormRef.current = true;
    }
  };

  const arrayCount = (e) => {
    if (e.length === 0) {
      //errorFormRef.current = true;
      return true;
    }
    // alert("bac", e);
  };

  const handleClick = () => {
    navigate("/SkillsAndCertificationsPage");
  };

  return (
    <div style={{ width: "90%", margin: "auto" }}>
      <IconButton onClick={handleClick}>
        <ArrowArcLeft />
      </IconButton>
      <Typography variant="h4" gutterBottom sx={{ textAlign: "center" }}>
        User Details
      </Typography>
      {/* {personalDetails.length > 0 &&
        formValidation(personalDetails.FirstName, "")} */}
      {personalDetails && (
        <TableContainer component={Paper} style={{ marginBottom: "20px" }}>
          <Typography
            variant="h6"
            color="textPrimary"
            sx={{ padding: "16px", fontWeight: "bold" }}
          >
            Personal Details:
          </Typography>

          <Table>
            <TableBody>
              <TableRow>
                <TableCell>First Name</TableCell>
                <TableCell>
                  {personalDetails.FirstName}
                  {errors.FirstName && (
                    <span style={{ color: "red" }}>{errors.FirstName}</span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Middle Name</TableCell>
                <TableCell>{personalDetails.MiddleName}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Last Name</TableCell>
                <TableCell>
                  {personalDetails.LastName}
                  {errors.LastName && (
                    <span style={{ color: "red" }}>{errors.LastName}</span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Gender</TableCell>
                <TableCell>
                  {personalDetails.Gender}
                  {errors.Gender && (
                    <span style={{ color: "red" }}>{errors.Gender}</span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Birth Country </TableCell>
                <TableCell>
                  {personalDetails.BirthCountryID &&
                  personalDetails.BirthCountryID.CountryName ? (
                    personalDetails.BirthCountryID.CountryName
                  ) : (
                    <span style={{ color: "red" }}>
                      {errors.BirthCountryName}
                    </span>
                  )}
                  {/* {errors.BirthCountryName && (
                    <span style={{ color: "red" }}>
                      {errors.BirthCountryName}
                    </span>
                  )} */}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Birth State </TableCell>
                <TableCell>
                  {personalDetails.BirthStateID?.StateName || (
                    <span style={{ color: "red" }}>
                      {errors.BirthStateName}
                    </span>
                  )}
                  {/* {errors.BirthStateName && (
                    <span style={{ color: "red" }}>
                      {errors.BirthStateName}
                    </span>
                  )} */}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Birth District </TableCell>
                <TableCell>
                  {personalDetails.BirthPlaceCityID?.CityName || (
                    <span style={{ color: "red" }}>
                      {errors.BirthDistrictName}
                    </span>
                  )}
                  {/* {errors.BirthDistrictName && (
                    <span style={{ color: "red" }}>
                      {errors.BirthDistrictName}
                    </span>
                  )} */}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Birth City </TableCell>
                <TableCell>
                  {personalDetails.NewCityID?.NewCityName || (
                    <span style={{ color: "red" }}>{errors.BirthCityName}</span>
                  )}
                  {/* {errors.BirthCityName && (
                    <span style={{ color: "red" }}>{errors.BirthCityName}</span>
                  )} */}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>Nationality</TableCell>
                <TableCell>
                  {typeof personalDetails.Nationality === "object"
                    ? personalDetails.Nationality?.CountryName || null
                    : personalDetails.Nationality || null}
                  {errors.Nationality && (
                    <span style={{ color: "red" }}>{errors.Nationality}</span>
                  )}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>Current Address</TableCell>
                <TableCell>
                  {personalDetails.CurrentAddress}
                  {errors.CurrentAddress && (
                    <span style={{ color: "red" }}>
                      {errors.CurrentAddress}
                    </span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Permanent Address</TableCell>
                <TableCell>
                  {personalDetails.PermanentAddress}
                  {errors.PermanentAddress && (
                    <span style={{ color: "red" }}>
                      {errors.PermanentAddress}
                    </span>
                  )}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>Date of Birth</TableCell>
                <TableCell>
                  {personalDetails.DOB
                    ? new Date(personalDetails.DOB).toLocaleDateString()
                    : null}
                  {errors.DOB && (
                    <span style={{ color: "red" }}>{errors.DOB}</span>
                  )}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>Blood Group</TableCell>
                <TableCell>
                  {personalDetails.BloodGroup}
                  {errors.BloodGroup && (
                    <span style={{ color: "red" }}>{errors.BloodGroup}</span>
                  )}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>Marital Status</TableCell>
                <TableCell>
                  {personalDetails.MaritalStatus}
                  {errors.MaritalStatus && (
                    <span style={{ color: "red" }}>{errors.MaritalStatus}</span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Contact Number</TableCell>
                <TableCell>
                  {personalDetails.ContactNumber}
                  {errors.ContactNumber && (
                    <span style={{ color: "red" }}>{errors.ContactNumber}</span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>UAN Number</TableCell>
                <TableCell>{personalDetails.UAN}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Employee Relation with Organization</TableCell>
                <TableCell>
                  {personalDetails.RelationshipWithOrg}
                  {errors.RelationshipWithOrg && (
                    <span style={{ color: "red" }}>
                      {errors.RelationshipWithOrg}
                    </span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Emergency Contact Number</TableCell>
                <TableCell>
                  {personalDetails.EmergencyContact}
                  {errors.EmergencyContact && (
                    <span style={{ color: "red" }}>
                      {errors.EmergencyContact}
                    </span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Emergency Contact Person Name</TableCell>
                <TableCell>
                  {personalDetails.EmergencyContactPersonName}
                  {errors.EmergencyContactPersonName && (
                    <span style={{ color: "red" }}>
                      {errors.EmergencyContactPersonName}
                    </span>
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>
                  Relationship With Emergency Contact Person
                </TableCell>
                <TableCell>
                  {personalDetails.Relationship}
                  {errors.Relationship && (
                    <span style={{ color: "red" }}>{errors.Relationship}</span>
                  )}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>Aadhar Number</TableCell>
                <TableCell>{personalDetails.AadharNo}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>PAN Number</TableCell>
                <TableCell>{personalDetails.PanNo}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Passport Number</TableCell>
                <TableCell>{personalDetails.PassportNumber}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Visa Status</TableCell>
                <TableCell>{personalDetails.visaStatus}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Visa End Date</TableCell>
                <TableCell>{personalDetails.visaStatus=="Active"
                            ? new Date(personalDetails.visaEndDate).toLocaleDateString()
                            : null}</TableCell>
              </TableRow>


              <TableRow>
                <TableCell>Remarks</TableCell>
                <TableCell>
                  {!personalDetails.PanNo &&
                  !personalDetails.AadharNo &&
                  !personalDetails.PassportNumber ? (
                    <span style={{ color: "red" }}>
                      Any One Government ID (Aadhaar/PAN/Passport) is required.
                    </span>
                  ) : (
                    ""
                  )}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {educationTran && (
        <TableContainer component={Paper} style={{ marginBottom: "20px" }}>
          <Typography
            variant="h6"
            color="textPrimary"
            sx={{ padding: "16px", fontWeight: "bold" }}
          >
            Education Details:
          </Typography>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>S.NO</TableCell>
                <TableCell>Education Description</TableCell>
                <TableCell>Institute Name</TableCell>
                <TableCell>Board/University</TableCell>
                {/* <TableCell>Degree</TableCell> */}
                <TableCell>Percentage</TableCell>
                <TableCell>CGPA</TableCell>
                <TableCell>Passed On</TableCell>
                <TableCell>Remarks</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {educationTran.map(
                (edu, index) => (
                  formValidation(edu.InstituteName, edu.EducDescription),
                  formValidation(edu.BoardORUniversity, edu.EducDescription),
                  formValidation(edu.PassedOn, edu.EducDescription),
                  formValidation(edu.CountryID, edu.EducDescription),
                  formValidation(edu.StateID, edu.EducDescription),
                  (
                    <TableRow key={index}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>{edu.EducDescription}</TableCell>
                      <TableCell>
                        {edu.InstituteName}
                        {edu.EducDescription != "Post Graduate" &&
                          edu.EducDescription !=
                            "Other Qualification-1 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-2 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-3 (If any)" &&
                          !edu.InstituteName && (
                            <span style={{ color: "red" }}>
                              {"Institute Name is Required"}
                            </span>
                          )}
                      </TableCell>
                      <TableCell>
                        {edu.BoardORUniversity}
                        {edu.EducDescription != "Post Graduate" &&
                          edu.EducDescription !=
                            "Other Qualification-1 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-2 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-3 (If any)" &&
                          !edu.BoardORUniversity && (
                            <span style={{ color: "red" }}>
                              {"Board Or University is Required"}
                            </span>
                          )}
                      </TableCell>
                      {/* <TableCell>{edu.Degree}</TableCell> */}
                      <TableCell>{edu.PercentageMarks}</TableCell>
                      <TableCell>{edu.CGPA}</TableCell>
                      <TableCell>
                        {edu.PassedOn
                          ? new Date(edu.PassedOn).toLocaleDateString()
                          : null}
                        {edu.EducDescription != "Post Graduate" &&
                          edu.EducDescription !=
                            "Other Qualification-1 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-2 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-3 (If any)" &&
                          !edu.PassedOn && (
                            <span style={{ color: "red" }}>
                              {"Passing Date is Required"}
                            </span>
                          )}
                      </TableCell>
                      <TableCell>
                        {edu.EducDescription != "Post Graduate" &&
                          edu.EducDescription !=
                            "Other Qualification-1 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-2 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-3 (If any)" &&
                          !edu.CountryID && (
                            <span style={{ color: "red" }}>
                              {"Country  is Missing"}
                            </span>
                          )}

                        {edu.EducDescription != "Post Graduate" &&
                          edu.EducDescription !=
                            "Other Qualification-1 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-2 (If any)" &&
                          edu.EducDescription !=
                            "Other Qualification-3 (If any)" &&
                          !edu.StateID && (
                            <span style={{ color: "red" }}>
                              {" ,State  is Missing"}
                            </span>
                          )}
                      </TableCell>
                    </TableRow>
                  )
                )
              )}

              <TableCell>
                {arrayCount(educationTran) == true && (
                  <span style={{ color: "red" }}>
                    {"Education details are required"}
                  </span>
                )}
              </TableCell>
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {previousWorkTran && (
        <TableContainer component={Paper} style={{ marginBottom: "20px" }}>
          <Typography
            variant="h6"
            color="textPrimary"
            sx={{ padding: "16px", fontWeight: "bold" }}
          >
            Previous Work Details:
          </Typography>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>S.NO</TableCell>
                <TableCell>Company Name</TableCell>
                <TableCell>Address</TableCell>
                <TableCell>Compensation</TableCell>
                <TableCell>Currency</TableCell>
                <TableCell>Designation</TableCell>
                <TableCell>Employment Type</TableCell>
                <TableCell>HR Name</TableCell>
                <TableCell>HR Email</TableCell>
                <TableCell>Required Document</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
               {previousWorkTran.map((work, index) => 
                (<TableRow key={index}>
                  <TableCell>{index + 1}</TableCell>
                  <TableCell>{work.CompanyName}</TableCell>
                  <TableCell>{work.Address}</TableCell>
                  <TableCell>{work.Compensation}</TableCell>
                  <TableCell>{work.Currency}</TableCell>
                  <TableCell>{work.DesignationName}</TableCell>
                  <TableCell>{work.EmploymentType}</TableCell>
                  <TableCell>{work.HRName}</TableCell>
                  <TableCell>{work.HREmail}</TableCell>
                  {/* Required Document */}
                  <TableCell>
                     {index==0 && (
                      <>
                        {(validateRequiredDocument(work, index).Doc11) && (
                        <span style={{font:"bold", color: "orange" }}>
                          <b>Warning: </b>
                          {validateRequiredDocument(work, index).Doc11}
                        </span>
                        )}
                        <br></br>
                        {(validateRequiredDocument(work, index).Doc12) && (
                        <span style={{ color: "red" }}>
                          <b>Required: </b>
                          {validateRequiredDocument(work, index).Doc12}
                        </span>
                        )}
                    </>
                     )} 

                     {index!=0 && (
                      <>
                      {(validateRequiredDocument(work, index).Doc11) && (
                    <span style={{ color: "red" }}>
                      <b>Required: </b>
                      {validateRequiredDocument(work, index).Doc11}
                    </span>
                      )}

                    <br></br>
                      {(validateRequiredDocument(work, index).Doc12) && (
                      <span style={{ color: "red" }}>
                        <b>Required: </b>
                        {validateRequiredDocument(work, index).Doc12}
                      </span>
                      )}
                    </>
                     )} 

                    </TableCell>
                </TableRow>
                )
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {previousGyanSysEmployeeDetails && (
        <TableContainer component={Paper} style={{ marginBottom: "20px" }}>
          <Typography
            variant="h6"
            color="textPrimary"
            sx={{ padding: "16px", fontWeight: "bold" }}
          >
            Previous GyanSys Employment Details:
          </Typography>
          <Table>
            <TableBody>
              <TableRow>
                <TableCell>Date of Joining</TableCell>
                <TableCell>
                  {previousGyanSysEmployeeDetails.DateOfJoining}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Date of Relieving</TableCell>
                <TableCell>
                  {previousGyanSysEmployeeDetails.DateOfRelieving}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Designation While Relieving</TableCell>
                <TableCell>
                  {previousGyanSysEmployeeDetails.DesignationWhileRelieving}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell>Previous GyanSys Emp ID</TableCell>
                <TableCell>
                  {previousGyanSysEmployeeDetails.PreviousGyanSysEmpID}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {documents && (
        <TableContainer component={Paper} style={{ marginBottom: "20px" }}>
          <Typography
            variant="h6"
            color="textPrimary"
            sx={{ padding: "16px", fontWeight: "normal" }}
          >
            Documents:
            <p style={{ color: "red", fontSize: "14px" }}>{docError}</p>
          </Typography>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>S.NO</TableCell>

                <TableCell>Document Type</TableCell>
                <TableCell>Preview</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {documents.map((document, index) => {
                // formValidation(document.DocTypeID == 1, "") ||
                //   (formValidation(document.DocTypeID == 3, "") &&
                //     formValidation(document.DocTypeID == 4, "") &&
                //     formValidation(document.DocTypeID == 5, ""));
                const blob = new Blob(
                  [new Uint8Array(document.DocScanned.data)],
                  { type: document.mimeType }
                );
                const url = URL.createObjectURL(blob);

                return (
                  <TableRow key={document.DocID}>
                    <TableCell>{index + 1}</TableCell>

                    <TableCell>{document.DocumentTypeMaster.DocType}</TableCell>
                    <TableCell>
                      {document.mimeType.startsWith("image/") ? (
                        <img
                          src={url}
                          alt={`Document ${document.DocID}`}
                          style={{ maxWidth: "200px", maxHeight: "200px" }}
                        />
                      ) : document.mimeType === "application/pdf" ? (
                        <iframe
                          src={url}
                          title={`Document ${document.DocID}`}
                          style={{ width: "200px", height: "200px" }}
                        />
                      ) : (
                        <div>Preview not available</div>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {certificationTran && (
        <TableContainer component={Paper} style={{ marginBottom: "20px" }}>
          <Typography
            variant="h6"
            color="textPrimary"
            sx={{ padding: "16px", fontWeight: "bold" }}
          >
            Certfications and Skills:
          </Typography>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>S.NO.</TableCell>
                <TableCell>Skills</TableCell>
                <TableCell>Certifcate Link</TableCell>
                <TableCell>Certification Name</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {certificationTran.map((certificate, index) => (
                // formValidation(certificate.Skills, ""),
                <TableRow key={index}>
                  <TableCell>{index + 1}</TableCell>
                  <TableCell>
                    {certificate.Skills}
                    {/* {!certificate.Skills && (
                      <span style={{ color: "red" }}>
                        {"Skill  is Required"}
                      </span>
                    )} */}
                  </TableCell>
                  <TableCell>
                    <a
                      href={certificate.CertificateLink}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Link
                    </a>
                  </TableCell>

                  <TableCell>{certificate.CertificateName}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          color: "orange",
        }}
      >
        <Button
          variant="contained"
          onClick={finalSubmit}
          sx={{ width: "130px", height: "40px", fontSize: "1.2rem" }}
          disabled={errorFormRef.current || IsSubmitted}
        >
          Submit
        </Button>
      </Box>
      <ToastContainer />
    </div>
  );
};

export default UserReview;
