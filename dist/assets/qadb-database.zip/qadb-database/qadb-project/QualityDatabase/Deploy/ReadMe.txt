﻿On the server install IBM Client Access for Windows 7.1
When installing uncheck all options except
  - Required programs
  - Data Access -> .Net Data Provider
(See IBM Install.png for screen shot)



References needed to access data from AS400

- COM object
cwbx
IBM iAccess for Windows ActiveX Object Library 1.1
Version 1.1
File Version 13.0.4.0
C:\Program Files (x86)\IBM\Client Access\Shared\cwbx.dll

cwbx.dll is a 32-bit dll. By default the application pools in
IIS 8 are set to run only 64-bit code. To enable this code to run,
  - Go to IIS manager on the server
  - Click on Application Pools in the connections tree to bring up the Application Pools page
  - Find the appliction pool used by your web app, such as DefaultAppPool
  - Right click on the application pool
  - Select Advanced settings
  - Find "Enable 32-Bit Application".
  - Set to true.
  - Click OK.




- Assembly
IBM.Data.DB2.iSeries
IBM DB2 for i .NET Provider 
Version 12.0.0.0
File Version 13.0.6.0
C:\Program Files (x86)\IBM\Client Access\IBM.Data.DB2.iSeries.dll