﻿jQuery(function ($) {
  $('#PriorSS').autoNumeric('init', { vMax: '999.999', aPad: false, wEmpty: 'zero' });
  $('#PriorCS').autoNumeric('init', { vMax: '999.999', aPad: false, wEmpty: 'zero' });
  $('#AfterMountSS').autoNumeric('init', { vMax: '999.999', aPad: false, wEmpty: 'zero' });
  $('#AfterMountCS').autoNumeric('init', { vMax: '999.999', aPad: false, wEmpty: 'zero' });
  $('#AfterTestSS').autoNumeric('init', { vMax: '999.999', aPad: false, wEmpty: 'zero' });
  $('#AfterTestCS').autoNumeric('init', { vMax: '999.999', aPad: false, wEmpty: 'zero' });

  $('#TankSize').autoNumeric('init', { vMax: '999.99', aPad: false, wEmpty: 'zero' });
  $('#GallonsOfFuel').autoNumeric('init', { vMax: '999.99', aPad: false, wEmpty: 'zero' });
  $('#PricePerGallon').autoNumeric('init', { vMax: '999.99', aPad: false, wEmpty: 'zero' });

  $('#FrontSeatCapacity').autoNumeric('init', { vMin: '0', vMax: '99', aPad: false, wEmpty: 'zero' });
  $('#RearSeatCapacity').autoNumeric('init', { vMin: '0', vMax: '99', aPad: false, wEmpty: 'zero' });

  $('#RepairTimeMinutes').autoNumeric('init', { vMin: '0', vMax: '999', aPad: false, wEmpty: 'zero' });

  $('#GallonsPerMinute').autoNumeric('init', { vMin: '0', vMax: '99', aPad: false, wEmpty: 'zero' });
  $('#WaterPressure').autoNumeric('init', { vMin: '0', vMax: '99', aPad: false, wEmpty: 'zero' });

  $('#UboltNumber').autoNumeric('init', { vMin: '0', vMax: '99', aPad: false, wEmpty: 'zero' });
  $('#UboltStreetSide').autoNumeric('init', { vMax: '999.99', aPad: false, wEmpty: 'zero' });
  $('#UboltCurbSide').autoNumeric('init', { vMax: '999.99', aPad: false, wEmpty: 'zero' });

  $('#WeightFrontAxle').autoNumeric('init', { aSep: '', vMin: '0', vMax: '9999999999', aPad: false, wEmpty: 'zero' });
  $('#TotalVehicleWeight').autoNumeric('init', { aSep: '', vMin: '0', vMax: '9999999999', aPad: false, wEmpty: 'zero' });
  $('#WeightRearAxle').autoNumeric('init', { aSep: '', vMin: '0', vMax: '9999999999', aPad: false, wEmpty: 'zero' });

  $('#Gross').autoNumeric('init', { aSep: '', vMin: '0', vMax: '9999999999', aPad: false, wEmpty: 'zero' });
  $('#Tare').autoNumeric('init', { aSep: '', vMin: '0', vMax: '9999999999', aPad: false, wEmpty: 'zero' });
});