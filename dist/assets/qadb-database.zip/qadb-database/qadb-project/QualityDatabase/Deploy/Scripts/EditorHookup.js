﻿/// <reference path="jquery-1.10.2.js" />
/// <reference path="jquery-ui-1.10.3.js" />

$(document).ready(function () {
  $('.date').datepicker({ dateFormat: "mm/dd/yy" });
});
