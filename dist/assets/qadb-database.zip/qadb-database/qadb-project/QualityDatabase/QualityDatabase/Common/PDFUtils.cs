﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace QualityDatabase.Common
{
  public class PDFUtils
  {

    // Merges multiple PDF files into one PDF file
    // PDF files are input as a list of byte arrarys
    // PDF file is output as a memory stream
    public MemoryStream Merge(List<byte[]> pdf)
    {
      /*byte[] mergedPdf = null;*/
      MemoryStream ms2 = null;
      using (MemoryStream ms = new MemoryStream())
      {
        using (Document document = new Document())
        {
          using (PdfCopy copy = new PdfCopy(document, ms))
          {
            document.Open();

            for (  int i = 0; i < pdf.Count; ++i)
            {
              PdfReader reader = new PdfReader(pdf[i]);
              int n = reader.NumberOfPages;
              for (int page = 0; page < n; )
              {
                copy.AddPage(copy.GetImportedPage(reader, ++page));
              }
            }
          }
        }
        /*mergedPdf = ms.ToArray();*/
        ms2 = ms;
      }

      return ms2;
    }

    // returns the existing PDF from the netwok location as a memory stream
    
        public MemoryStream GetExistingPDF(string _bodyNumber)
        {
            string uncPath = GetUNCPath(_bodyNumber.Trim());
                try
            {
                byte[] fileBytes = File.ReadAllBytes(uncPath);
                return new MemoryStream(fileBytes);
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                Console.WriteLine($"Error reading file from UNC path: {ex.Message}");
                return null;
            }
        }


        // Determines if a Weight Sheet PDF file already exists for a body number
        // The routine attempts to get the last modified date for the FTP path/filename
        // if the last modified date if returned it means the file exists
        // if the file does not exist an exception will be thrown trying to get the date

        public bool DoesPDFExist(string _bodyNumber)
        {
            
            string uncPath = GetUNCPath(_bodyNumber.Trim());

            try
            {
                return File.Exists(uncPath);
            }
            catch (Exception ex)
            {
                // Handle any exceptions, log if necessary
                Console.WriteLine($"Error checking file at UNC path: {ex.Message}");
                return false;
            }
        }
      

        // Parse the body number to create the UNC file path
        // path is nas/apps/data/orderinfo/<first letter of body number>/<body number>/weight sheet.pdf
        
        private string GetUNCPath(string _bodyNumber)
        {
            UNCUtils utils = new UNCUtils(_bodyNumber);
            string path = utils.GetUNCPath();

            StringBuilder HTTPPath = new StringBuilder();
            HTTPPath.Append(path.ToString());
            HTTPPath.Append("weight sheet.pdf");

            return HTTPPath.ToString();
        }


        // update a new PDF file to the network location using UNC

        public void Upload(MemoryStream _pdf, string _bodyNumber)
        {
            

            try
            {
                // Test with a local path
                string localPath = @"C:\Temp\TestPdf.pdf"; // Ensure this path is valid and accessible
                // Write to local path for testing
                using (FileStream fileStream = new FileStream(localPath, FileMode.Create, FileAccess.Write))
                {
                    _pdf.Position = 0;
                    _pdf.WriteTo(fileStream);
                }

                // Write the MemoryStream content to a UNC path.
                string uncPath = GetUNCPath(_bodyNumber.Trim());
                using (FileStream fileStream = new FileStream(uncPath, FileMode.Create, FileAccess.Write))
                {
                    _pdf.Position = 0;
                    _pdf.WriteTo(fileStream);
                }
            }
            catch (Exception ex)
            {
                // Log the error as per your original function
                ErrorLogger.Log("PDFUtils", "", "Error writing to UNC path: " + ex.Message);
                throw new Exception("PDFUtils-Upload", ex);
            }
            /*finally
            {
                _pdf.Close();
            }*/
        }



        // Delete a PDF file from the network location using UNC
        public void Delete(string _bodyNumber)
        {
            string uncPath = GetUNCPath(_bodyNumber.Trim());

            try
            {
                // Check if file exists
                if (DoesPDFExist(uncPath))
                {
                    File.Delete(uncPath);
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                Console.WriteLine($"Error deleting file at UNC path: {ex.Message}");
            }
        }
    }
}