﻿
namespace QualityDatabase.Common
{
  public class ValidationError
  {
    public string Key { get; set; }
    public string Message { get; set; }

    public ValidationError()
    {
      Key = "";
      Message = "";
    }
  }

}