﻿using cwbx;       // cwbx.dll  Part of IBM Client Access
using System;

namespace QualityDatabase.Common
{
  public class ValidateLogin
  {
    public bool Expired { get; set; }

    public ValidateLogin()
    {
      Expired = false;
    }

    // Check to see if the username and password is
    // valid on the AS400
    public bool IsUserValid(string _username, string _password)
    {
      //return true;
      AS400System sys = new AS400System();

      // use the ComCleaup object to be sure the
      // com object is properly disposed
      using (var c = new ComCleanupAS400System(sys))
      {
        try
        {
          // set the IP address of the AS400 
          sys.Define(Utils.GetAS400IPAddress());

          // Verify method will cause exception if the
          // the username/password are invalid. Otherwise
          // assume the combination is valid
          sys.VerifyUserIDPassword(_username, _password);
          return true;
        }
        catch (Exception ex)
        {
          if (ex.Message.Contains("CWBSY0003") == true)
            Expired = true;

          return false;
        }
      }
    }
  }
}