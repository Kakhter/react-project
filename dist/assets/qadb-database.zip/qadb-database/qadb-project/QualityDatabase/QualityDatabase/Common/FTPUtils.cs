﻿using System;
using System.Net;
using System.Text;

namespace QualityDatabase.Common
{
  public class FTPUtils
  {
    private string FTPBasePath { get; set; }
    private string FTPLetterFolder { get; set; }
    private string FTPFullFolder { get; set; }

    public FTPUtils(string _bodyNumber)
    {
      // FTPBasePath = "ftp://nas/apps/data/orderinfo/test/";
      // FTPBasePath = "ftp://nas/apps/data/orderinfo/";
      FTPBasePath = "http://supintranet/appdata/applications/Data/OrderInfo/";
      FTPLetterFolder = _bodyNumber.Substring(0, 1);
      FTPFullFolder = _bodyNumber.Trim();
    }

    public string GetFTPPath()
    {
      bool exists = false;

      StringBuilder FTPPath = new StringBuilder();
      FTPPath.Append(FTPBasePath.Trim());
      FTPPath.Append(FTPLetterFolder.Trim());
      FTPPath.Append("/");

      exists = DoesFTPFolderExist(FTPPath.ToString());
      if (exists == false)
      {
        CreateFTPFolder(FTPPath.ToString());
      }

      FTPPath.Append(FTPFullFolder.Trim());
      FTPPath.Append("/");

      exists = DoesFTPFolderExist(FTPPath.ToString());
      if (exists == false)
      {
        CreateFTPFolder(FTPPath.ToString());
      }

      return FTPPath.ToString();
    }


    private bool DoesFTPFolderExist(string _path)
    {
      bool Exists = false;

      System.Net.FtpWebRequest request = (System.Net.FtpWebRequest)System.Net.FtpWebRequest.Create(_path.Trim());
      try
      {
        request.Method = WebRequestMethods.Ftp.ListDirectory;
        using (request.GetResponse())
        {
          Exists = true;
        }
      }
      catch (Exception)
      {
        Exists = false;
      }
      return Exists;
    }

    private bool CreateFTPFolder(string _path)
    {
      bool Exists = true;
      System.Net.FtpWebRequest request = (System.Net.FtpWebRequest)System.Net.FtpWebRequest.Create(_path.Trim());
      try
      {
        request.Method = WebRequestMethods.Ftp.MakeDirectory;
        using (request.GetResponse())
        {
          Exists = true;
        }
      }
      catch (Exception)
      {
        Exists = false;
      }
      return Exists;

    }
  }
}