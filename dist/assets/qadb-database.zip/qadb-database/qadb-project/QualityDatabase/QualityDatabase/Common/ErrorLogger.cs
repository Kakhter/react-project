﻿using NLog;
using System;

namespace QualityDatabase.Common
{
  public class ErrorLogger
  {
    public static void Log(string _source, string _user, string _msg)
    {
      Logger logger = LogManager.GetLogger(_source);
      logger.Error(_user + " - " + _msg);
    }

    public static void Log(string _source, string _user, string _msg, Exception _exception)
    {
      Logger logger = LogManager.GetLogger(_source);
      logger.ErrorException(_user + " - " + _msg, _exception);
    }
  }
}