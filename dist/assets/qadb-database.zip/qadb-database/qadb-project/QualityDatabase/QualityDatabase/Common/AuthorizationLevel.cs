﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Common
{
  public class AuthorizationLevel
  {
    private static string ViewMsg = "ViewOnly";
    private static string EditMsg = "Edit";

    public static string GetLevel(string _source, string _userAuthorization)
    {
      if (_userAuthorization == null)
        return ViewMsg;

      if (_source == null)
        return ViewMsg;

      if (_userAuthorization.Trim() == "V")
        return ViewMsg;

      if (_userAuthorization.Trim() == "S")
        return EditMsg;

      if (_userAuthorization.Trim() == "Q")
        return GetQualityAuthorization(_source);

      if (_userAuthorization.Trim() == "P")
        return GetProductionAuthorization(_source);

      return ViewMsg;

    }

    private static string GetQualityAuthorization(string _source)
    {
      if ((_source.Trim() == "HomeIndex")

        || (_source.Trim() == "FuelEdit")
        || (_source.Trim() == "FuelIndex")

        || (_source.Trim() == "HoldIssuesCreate")
        || (_source.Trim() == "HoldIssuesDelete")
        || (_source.Trim() == "HoldIssuesEdit")
        || (_source.Trim() == "HoldIssuesIndex")

        || (_source.Trim() == "HoldsResolvedEdit")
        || (_source.Trim() == "HoldsResolvedIndex")

        || (_source.Trim() == "LineInspectionCreate")
        || (_source.Trim() == "LineInspectionDelete")
        || (_source.Trim() == "LineInspectionEdit")
        || (_source.Trim() == "LineInspectionIndex")

        || (_source.Trim() == "TireTagEdit")
        || (_source.Trim() == "TireTagIndex")

        || (_source.Trim() == "TorqueCreate")
        || (_source.Trim() == "TorqueDelete")
        || (_source.Trim() == "TorqueEdit")
        || (_source.Trim() == "TorqueIndex")

        || (_source.Trim() == "WaterTestCreate")
        || (_source.Trim() == "WaterTestDelete")
        || (_source.Trim() == "WaterTestEdit")
        || (_source.Trim() == "WaterTestIndex")

        || (_source.Trim() == "WeightSheetIndex")
        || (_source.Trim() == "WeightSheetViewPDF")
        || (_source.Trim() == "WeightSheetCreate")
        || (_source.Trim() == "WeightSheetUniversalCreate")
        || (_source.Trim() == "WeightSheetCaliforniaCreate")

        )
        return EditMsg;
      else
        return ViewMsg;
    }

    private static string GetProductionAuthorization(string _source)
    {
      if ((_source.Trim() == "HomeIndex")

        || (_source.Trim() == "HoldIssuesCreate")
        || (_source.Trim() == "HoldIssuesDelete")
        || (_source.Trim() == "HoldIssuesEdit")
        || (_source.Trim() == "HoldIssuesIndex")

        || (_source.Trim() == "LeakRepairIndex")
        || (_source.Trim() == "LeakRepairEdit")

        || (_source.Trim() == "LineRepairIndex")
        || (_source.Trim() == "LineRepairEdit")
       )
        return EditMsg;
      else
        return ViewMsg;
    }

  }
}