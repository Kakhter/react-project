﻿using cwbx;
using System;
using System.Runtime.InteropServices;

namespace QualityDatabase.Common
{
  // This is a wrapper around the AS400System Com object
  // The purpose of the wrapper is to make sure the com
  // object is disposed of properly
  public class ComCleanupAS400System : IDisposable
  {
    private AS400System obj;

    public ComCleanupAS400System(AS400System obj)
    {
      this.obj = obj;
    }

    public void Dispose()
    {
      if (obj != null)
        Marshal.FinalReleaseComObject(obj);
    }
  }
}