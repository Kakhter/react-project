﻿using System;
using System.Text;
using System.Net;

namespace QualityDatabase.Common
{
    public class HTTPUtils
    {
        private string HTTPBasePath { get; set; }
        private string HTTPLetterFolder { get; set; }
        private string HTTPFullFolder { get; set; }

        public HTTPUtils(string _bodyNumber)
        {
            HTTPBasePath = "http://supintranet/appdata/applications/Data/OrderInfo/";
            HTTPLetterFolder = _bodyNumber.Substring(0, 1);
            HTTPFullFolder = _bodyNumber.Trim();
        }

        public string GetHTTPPath()
        {
            bool exists = false;

            StringBuilder HTTPPath = new StringBuilder();
            HTTPPath.Append(HTTPBasePath.Trim());
            HTTPPath.Append(HTTPLetterFolder.Trim());
            HTTPPath.Append("/");

            exists = DoesHTTPFolderExist(HTTPPath.ToString());
            if (exists == false)
            {
                CreateHTTPFolder(HTTPPath.ToString());
            }

            HTTPPath.Append(HTTPFullFolder.Trim());
            HTTPPath.Append("/");

            exists = DoesHTTPFolderExist(HTTPPath.ToString());
            if (exists == false)
            {
                CreateHTTPFolder(HTTPPath.ToString());
            }

            return HTTPPath.ToString();
        }

        private bool DoesHTTPFolderExist(string _path)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(_path.Trim());
            try
            {
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    return response.StatusCode == HttpStatusCode.OK;
                }
            }
            catch (WebException ex)
            {
                if (ex.Response is HttpWebResponse httpResponse && httpResponse.StatusCode == HttpStatusCode.NotFound)
                {
                    return false;
                }
                throw; // If it's some other exception, better to rethrow or handle it accordingly
            }
        }

        private bool CreateHTTPFolder(string _path)
        {
            // HTTP doesn't have a standardized method for creating directories. 
            // This will heavily depend on your server setup and what it supports.
            // You might need an API endpoint on your server that supports folder creation.
            throw new NotImplementedException("Creating folders via HTTP requires server-specific implementation.");
        }
    }

}
