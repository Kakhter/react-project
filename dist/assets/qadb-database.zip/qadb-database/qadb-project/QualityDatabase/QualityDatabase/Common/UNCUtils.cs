﻿using System;
using System.Text;
using System.Net;
using System.IO;

namespace QualityDatabase.Common
{
    public class UNCUtils
    {
        private string UNCBasePath { get; set; }
        private string UNCLetterFolder { get; set; }
        private string UNCFullFolder { get; set; }

        public UNCUtils(string _bodyNumber)
        {
            UNCBasePath = "\\\\nas\\data\\applications\\Data\\OrderInfo\\";
            UNCLetterFolder = _bodyNumber.Substring(0, 1);
            UNCFullFolder = _bodyNumber.Trim();
        }

        public string GetUNCPath()
        {
            bool exists = false;

            StringBuilder UNCPath = new StringBuilder();
            UNCPath.Append(UNCBasePath.Trim());
            UNCPath.Append(UNCLetterFolder.Trim());
            UNCPath.Append("\\");

            exists = DoesUNCFolderExist(UNCPath.ToString());
            if (exists == false)
            {
                CreateUNCFolder(UNCPath.ToString());
            }

            UNCPath.Append(UNCFullFolder.Trim());
            UNCPath.Append("\\");

            exists = DoesUNCFolderExist(UNCPath.ToString());
            if (exists == false)
            {
                CreateUNCFolder(UNCPath.ToString());
            }

            return UNCPath.ToString();
        }

        public bool DoesUNCFolderExist(string uncFolderPath)
        {
            try
            {
                return Directory.Exists(uncFolderPath);
            }
            catch (Exception ex)
            {
                // Optionally, you can log or handle any exceptions that might arise due to network issues, permissions, etc.
                Console.WriteLine($"Error checking folder at UNC path: {ex.Message}");
                return false;
            }
        }

        private void CreateUNCFolder(string _path)
        {
            
            try
            {
                // Check if directory exists
                if (!DoesUNCFolderExist(_path)) 
                {
                    Directory.CreateDirectory(_path);
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                Console.WriteLine($"Error creating folder at UNC path: {ex.Message}");
            }
        }
    }

}
