﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class ChassisHeightServices
  {
    public List<ChassisHeightIndexModel> GetChassisHeightForIndex(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      ChassisHeightIndexModel model;
      List<ChassisHeightIndexModel> list = new List<ChassisHeightIndexModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QSPCRSS, QSPCRCS, QSMCRSS, QSMCRCS, QSTCRSS, QSTCRCS, QSSR# ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".STF ");
            sql.Append(" where QSSR#=@SerialNumber");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new ChassisHeightIndexModel();
                  model.PriorSS = DBUtils.GetSafeDouble(rdr["QSPCRSS"]);
                  model.PriorCS = DBUtils.GetSafeDouble(rdr["QSPCRCS"]);
                  model.AfterMountSS = DBUtils.GetSafeDouble(rdr["QSMCRSS"]);
                  model.AfterMountCS = DBUtils.GetSafeDouble(rdr["QSMCRCS"]);
                  model.AfterTestSS = DBUtils.GetSafeDouble(rdr["QSTCRSS"]);
                  model.AfterTestCS = DBUtils.GetSafeDouble(rdr["QSTCRCS"]);
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QSSR#"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("ChassisHeightServices", "", "Error in GetChassisHeightForIndex", ex);
        throw new ApplicationException("Get Chassis Height for Index: " + ex.Message, ex);
      }

      if (list.Count == 0)
      {
        model = new ChassisHeightIndexModel();
        model.SerialNumber = _serialNumber;
        list.Add(model);
      }
      return list;
    }

    public ChassisHeightModel GetChassisHeight(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      ChassisHeightModel model = new ChassisHeightModel();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select * ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".STF");
            sql.Append(" where QSSR#=@SerialNumber ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new ChassisHeightModel();
                  model.PriorSS = DBUtils.GetSafeDouble(rdr["QSPCRSS"]);
                  model.PriorCS = DBUtils.GetSafeDouble(rdr["QSPCRCS"]);
                  model.AfterMountSS = DBUtils.GetSafeDouble(rdr["QSMCRSS"]);
                  model.AfterMountCS = DBUtils.GetSafeDouble(rdr["QSMCRCS"]);
                  model.AfterTestSS = DBUtils.GetSafeDouble(rdr["QSTCRSS"]);
                  model.AfterTestCS = DBUtils.GetSafeDouble(rdr["QSTCRCS"]);
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QSSR#"]);
                  model.ChassisRailCreateDate = DBUtils.GetSafeString(rdr["QSCRDATE"]);
                  model.ChassisRailCreateTime = DBUtils.GetSafeString(rdr["QSCRTIME"]);
                  model.ChassisRailCreatedBy = DBUtils.GetSafeString(rdr["QSCRUSER"]).Trim();
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("ChassisHeightServices", "", "Error in GetChassisHeight", ex);
        throw new ApplicationException("Get Chassis Height: " + ex.Message, ex);
      }
      return model;
    }

    public string UpdateChassisHeight(ChassisHeightModel _model)
    {
      string ErrorString = "";
      StringBuilder sql;
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      ChassisHeightModel model = this.GetChassisHeight(_model.SerialNumber);

      _model.ReplaceNulls();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            if (model.SerialNumber.Trim() == "")
            {
              sql = new StringBuilder();
              sql.Append("insert into ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".STF (");
              sql.Append("QSPCRSS, QSPCRCS, QSMCRSS, QSMCRCS, QSTCRSS, QSTCRCS, QSSR#, ");
              sql.Append("QSCRTIME, QSCRDATE, QSCRUSER ");
              sql.Append(") values (");
              sql.Append("@PriorSS, @PriorCS, @AfterMountSS, @AfterMountCS, @AfterTestSS, @AfterTestCS, ");
              sql.Append("@SerialNumber, @CreateTime, @CreateDate, @CreatedBy ");
              sql.Append(")");
              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@PriorSS", _model.PriorSS));
              cmd.Parameters.Add(new iDB2Parameter("@PriorCS", _model.PriorCS));
              cmd.Parameters.Add(new iDB2Parameter("@AfterMountSS", _model.AfterMountSS));
              cmd.Parameters.Add(new iDB2Parameter("@AfterMountCS", _model.AfterMountCS));
              cmd.Parameters.Add(new iDB2Parameter("@AfterTestSS", _model.AfterTestSS));
              cmd.Parameters.Add(new iDB2Parameter("@AfterTestCS", _model.AfterTestCS));
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber));
              cmd.Parameters.Add(new iDB2Parameter("@CreateTime", DBUtils.GetAS400Time(CreateDateTime)));
              cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));
              cmd.Parameters.Add(new iDB2Parameter("@CreatedBy", _model.ChassisRailCreatedBy.Trim()));
            }
            else
            {
              if (model.ChassisRailCreatedBy.Trim() == "")
              {
                sql = new StringBuilder();
                sql.Append("Update ");
                sql.Append(DBUtils.GetSUPxxx010().Trim());
                sql.Append(".STF ");
                sql.Append("Set ");
                sql.Append(" QSPCRSS = @PriorSS, ");
                sql.Append(" QSPCRCS = @PriorCS, ");
                sql.Append(" QSMCRSS = @AfterMountSS, ");
                sql.Append(" QSMCRCS = @AfterMountCS, ");
                sql.Append(" QSTCRSS = @AfterTestSS, ");
                sql.Append(" QSTCRCS = @AfterTestCS, ");
                sql.Append(" QSCRDATE = @CreateDate, ");
                sql.Append(" QSCRTIME = @CreateTime, ");
                sql.Append(" QSCRUSER = @CreatedBy ");
                sql.Append(" where QSSR# = @SerialNumber ");

                cmd.CommandText = sql.ToString();
                cmd.Parameters.Add(new iDB2Parameter("@PriorSS", _model.PriorSS));
                cmd.Parameters.Add(new iDB2Parameter("@PriorCS", _model.PriorCS));
                cmd.Parameters.Add(new iDB2Parameter("@AfterMountSS", _model.AfterMountSS));
                cmd.Parameters.Add(new iDB2Parameter("@AfterMountCS", _model.AfterMountCS));
                cmd.Parameters.Add(new iDB2Parameter("@AfterTestSS", _model.AfterTestSS));
                cmd.Parameters.Add(new iDB2Parameter("@AfterTestCS", _model.AfterTestCS));
                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber));
                cmd.Parameters.Add(new iDB2Parameter("@CreateTime", DBUtils.GetAS400Time(CreateDateTime)));
                cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));
                cmd.Parameters.Add(new iDB2Parameter("@CreatedBy", _model.ChassisRailCreatedBy.Trim()));
              }
              else
              {
                sql = new StringBuilder();
                sql.Append("Update ");
                sql.Append(DBUtils.GetSUPxxx010().Trim());
                sql.Append(".STF ");
                sql.Append("Set ");
                sql.Append(" QSPCRSS = @PriorSS, ");
                sql.Append(" QSPCRCS = @PriorCS, ");
                sql.Append(" QSMCRSS = @AfterMountSS, ");
                sql.Append(" QSMCRCS = @AfterMountCS, ");
                sql.Append(" QSTCRSS = @AfterTestSS, ");
                sql.Append(" QSTCRCS = @AfterTestCS ");
                sql.Append(" where QSSR# = @SerialNumber ");

                cmd.CommandText = sql.ToString();
                cmd.Parameters.Add(new iDB2Parameter("@PriorSS", _model.PriorSS));
                cmd.Parameters.Add(new iDB2Parameter("@PriorCS", _model.PriorCS));
                cmd.Parameters.Add(new iDB2Parameter("@AfterMountSS", _model.AfterMountSS));
                cmd.Parameters.Add(new iDB2Parameter("@AfterMountCS", _model.AfterMountCS));
                cmd.Parameters.Add(new iDB2Parameter("@AfterTestSS", _model.AfterTestSS));
                cmd.Parameters.Add(new iDB2Parameter("@AfterTestCS", _model.AfterTestCS));
                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
              }
            }
            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Update Chassis Height: Record not updated, no exception thrown");
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("ChassisHeightServices", "", "Error in UpdateChassisHeight", ex);
        throw new ApplicationException("Update Chassis Height: " + ex.Message, ex);
      }
      return ErrorString;
    }
  }
}