﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class NotificationServices
  {
    public List<NotificationModel> GetAllNotificationRecords()
    {
      List<NotificationModel> list = new List<NotificationModel>();
      NotificationModel model = null;
      StringBuilder sql = new StringBuilder();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            sql = new StringBuilder();
            sql.Append("select QASEQ, QAMSG ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QANF ");
            sql.Append(" order by QASEQ");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new NotificationModel();
                  model.Sequence = DBUtils.GetSafeString(rdr["QASEQ"]);
                  model.Message = DBUtils.GetSafeString(rdr["QAMSG"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        throw new ApplicationException("Get All Notification Records: " + ex.Message, ex);
      }
      return list;
    }
  }
}