﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace QualityDatabase.Services
{
  public class DivisionService
  {
    public string GetDivision(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();

      object obj;
      decimal OrderNumber = 0;
      string Division = "";

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            sql = new StringBuilder();
            sql.Append("select S1ORD# ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".S1P ");
            sql.Append(" where S1SR#=@SerialNumber");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));


            obj = cmd.ExecuteScalar();
            OrderNumber = DBUtils.GetSafeDecimal(obj);

            sql = new StringBuilder();
            sql.Append("select OHDIV ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".OHP ");
            sql.Append(" where OHORD# = @OrderNumber");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@OrderNumber", OrderNumber));
            obj = cmd.ExecuteScalar();
            Division = DBUtils.GetSafeString(obj);

          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("DivisionServices", "", "Error in GetDivision", ex);
        throw new ApplicationException("Get Division: " + ex.Message, ex);
      }
      return Division;
    }
  }
}