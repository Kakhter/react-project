﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
    public class LineRepairServices
    {
        public List<LineRepairIndexModel> GetLineRepairForIndex(string _serialNumber)
        {
            StringBuilder sql = new StringBuilder();
            LineRepairIndexModel lr = null;
            List<LineRepairIndexModel> list = new List<LineRepairIndexModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT QLSR#, QLDATE, QLDA, QLDI, QLDT, QLDC,  ");
                        sql.Append("       DADESC, DIDESC, DTDESC, DCDESC, ");
                        sql.Append("       QLRA, RADESC, QLRM,  ");
                        sql.Append("       QIRDATE, QIRTIME, QIRUSER, ");
                        sql.Append("       QLIDTE, QLTIME, QLRF");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF ");

                        sql.Append("left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDAF ");
                        sql.Append(" on QLDA = DAID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDTF  ");
                        sql.Append(" on QLDT = DTID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDCF  ");
                        sql.Append(" on QLDC = DCID#");
                        sql.Append(" AND DCTID# = DTID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDIF ");
                        sql.Append(" on QLDI = DIID#");
                        sql.Append(" AND DICID# = DCID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QRAF ");
                        sql.Append(" on QLRA = RAID#");


                        sql.Append(" where QLSR#=@SerialNumber");
                        sql.Append(" order by QLDATE");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

                        //cn.ConnectionString = "Datasource=192.168.30.8; UserId=PRINTER; Password=PRINTER";
                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        // get Serial Number, Model, Order Number, and Warehouse
                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    lr = new LineRepairIndexModel();
                                    lr.InspectionDate = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QLDATE"]));
                                    lr.AreaDesc = DBUtils.GetSafeString(rdr["DADESC"]).Trim();
                                    lr.ItemDesc = DBUtils.GetSafeString(rdr["DIDESC"]).Trim();
                                    lr.TypeDesc = DBUtils.GetSafeString(rdr["DTDESC"]).Trim();
                                    lr.ConditionDesc = DBUtils.GetSafeString(rdr["DCDESC"]).Trim();
                                    lr.RepairAction = DBUtils.GetSafeString(rdr["QLRA"]).Trim();
                                    lr.RepairActionDesc = DBUtils.GetSafeString(rdr["RADESC"]).Trim();
                                    lr.RepairTimeMinutes = DBUtils.GetSafeInteger(rdr["QLRM"]);
                                    lr.SerialNumber = DBUtils.GetSafeString(rdr["QLSR#"]).Trim();
                                    lr.InspectionCreateDate = DBUtils.GetSafeString(rdr["QLIDTE"]);
                                    lr.InspectionCreateTime = DBUtils.GetSafeString(rdr["QLTIME"]);
                                    lr.Rework = DBUtils.GetSafeString(rdr["QLRF"]);
                                    list.Add(lr);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineRepairServices", "", "Error in GetLineRepairForIndex", ex);
                throw new ApplicationException("Get Line Repair for Index: " + ex.Message, ex);
            }
            return list;
        }

        public LineRepairModel GetSingleLineRepair(string _serialNumber, string _createDate, string _createTime)
        {
            StringBuilder sql = new StringBuilder();
            LineRepairModel lr = new LineRepairModel();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select * ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF");
                        sql.Append(" where QLSR#=@SerialNumber ");
                        sql.Append("   and QLIDTE=@CreateDate ");
                        sql.Append("   and QLTIME=@CreateTime ");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    lr = new LineRepairModel();
                                    lr.RepairAction = DBUtils.GetSafeString(rdr["QLRA"]).Trim();
                                    lr.RepairTimeMinutes = DBUtils.GetSafeInteger(rdr["QLRM"]);
                                    lr.RepairCreateDate = DBUtils.GetSafeString(rdr["QIRDATE"]);
                                    lr.RepairCreateTime = DBUtils.GetSafeString(rdr["QIRTIME"]);
                                    lr.RepairCreatedBy = DBUtils.GetSafeString(rdr["QIRUSER"]).Trim();
                                    lr.SerialNumber = DBUtils.GetSafeString(rdr["QLSR#"]).Trim();
                                    lr.InspectionCreateDate = DBUtils.GetSafeString(rdr["QLIDTE"]);
                                    lr.InspectionCreateTime = DBUtils.GetSafeString(rdr["QLTIME"]);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineRepairServices", "", "Error in GetSingleLineRepair", ex);
                throw new ApplicationException("Get Single Line Repair: " + ex.Message, ex);
            }
            return lr;
        }

        public string UpdateLineRepair(LineRepairModel _model)
        {
            LineRepairModel CurrentModel = this.GetSingleLineRepair(_model.SerialNumber, _model.InspectionCreateDate, _model.InspectionCreateTime);
            if (CurrentModel.RepairCreatedBy.Trim() == "")
            {
                DateTime CreateDateTime = DateTime.Now;
                _model.RepairCreateDate = DBUtils.GetAS400Date(CreateDateTime);
                _model.RepairCreateTime = DBUtils.GetAS400Time(CreateDateTime);
            }
            else
            {
                _model.RepairCreateDate = CurrentModel.RepairCreateDate;
                _model.RepairCreateTime = CurrentModel.RepairCreateTime;
                _model.RepairCreatedBy = CurrentModel.RepairCreatedBy;

            }

            StringBuilder sql = new StringBuilder();
            int result = 0;

            _model.ResetNullValues();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("Select count(*) from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF  ");
                        sql.Append(" where QLSR#=@SerialNumber ");
                        sql.Append("   and QLIDTE=@CreateDate ");
                        sql.Append("   and QLTIME=@CreateTime ");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.InspectionCreateDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.InspectionCreateTime));


                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

                        if (result == 1)
                        {
                            sql = new StringBuilder();
                            sql.Append("Update ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLIF  ");
                            sql.Append("Set ");
                            sql.Append(" QLRA = @RepairAction, ");
                            sql.Append(" QLRM = @RepairTimeMinutes, ");
                            sql.Append(" QIRDATE = @RepairCreateDate, ");
                            sql.Append(" QIRTIME = @RepairCreateTime, ");
                            sql.Append(" QIRUSER = @RepairCreatedBy");
                            sql.Append(" where QLSR#=@SerialNumber ");
                            sql.Append("   and QLIDTE=@InspectionCreateDate ");
                            sql.Append("   and QLTIME=@InspectionCreateTime ");

                            cmd.CommandText = sql.ToString();
                            cmd.Parameters.Add(new iDB2Parameter("@RepairAction", _model.RepairAction.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@RepairTimeMinutes", _model.RepairTimeMinutes));
                            cmd.Parameters.Add(new iDB2Parameter("@RepairCreateDate", _model.RepairCreateDate));
                            cmd.Parameters.Add(new iDB2Parameter("@RepairCreateTime", _model.RepairCreateTime));
                            cmd.Parameters.Add(new iDB2Parameter("@RepairCreatedBy", _model.RepairCreatedBy.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@InspectionCreateDate", _model.InspectionCreateDate));
                            cmd.Parameters.Add(new iDB2Parameter("@InspectionCreateTime", _model.InspectionCreateTime));
                            result = cmd.ExecuteNonQuery();
                            if (result == 0)
                                throw new ApplicationException("Update Line Repair: Record not updated, no exception thrown");
                            else
                            {
                                InspectionLogServices inspLog = new InspectionLogServices();
                                inspLog.UpdateLog(_model.SerialNumber, _model.InspectionCreateDate, _model.InspectionCreateTime);
                                return "";
                            }
                        }
                        else
                        {
                            StringBuilder msg = new StringBuilder();
                            if (result > 1)
                                msg.Append("Multiple records found - ");
                            else
                                msg.Append("Update Line Repair: Invalid parameters - ");
                            msg.Append(_model.SerialNumber);
                            msg.Append(", ");
                            msg.Append(_model.InspectionCreateDate);
                            msg.Append(", ");
                            msg.Append(_model.InspectionCreateTime);
                            throw new ApplicationException(msg.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineRepairServices", "", "Error in UpdateLineRepair", ex);
                throw new ApplicationException("Update Line Repair: " + ex.Message, ex);
            }
        }
    }
}