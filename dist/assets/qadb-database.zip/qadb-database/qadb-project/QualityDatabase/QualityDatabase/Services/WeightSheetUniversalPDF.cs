﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using QualityDatabase.Models;
using System.IO;
using System.Text;

namespace QualityDatabase.Services
{
  public class WeightSheetUniversalPDF
  {
    public string imagePath { get; set; }
    public object SerialNumber { get; set; }
    public object PDFVehicleType { get; set; }
    public object PDFWeightFrontAxle { get; set; }
    public object PDFTotalVehicleWeight { get; set; }
    public object PDFWeightRearAxle { get; set; }
    public object PDFRemark { get; set; }
    public string UserName { get; set; }


        /* public System.IO.MemoryStream CreateUniversalPDF()
          {
            System.IO.MemoryStream m = new MemoryStream();

            iTextSharp.text.Document document = new iTextSharp.text.Document();
            iTextSharp.text.pdf.PdfWriter writer = iTextSharp.text.pdf.PdfWriter.GetInstance(document, m);

            WeightSheetServices db = new WeightSheetServices();
            WeightSheetUniversalModel model = new WeightSheetUniversalModel();
            model = db.GetUniversalWeightSheet(SerialNumber, PDFVehicleType, PDFWeightFrontAxle, 
                                               PDFTotalVehicleWeight, PDFWeightRearAxle, PDFRemark,
                                               UserName);


            BaseFont _baseFont = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.WINANSI, BaseFont.NOT_EMBEDDED);
            Font _smallFont = new Font(_baseFont, 8, Font.NORMAL, BaseColor.BLACK);
            Font _smallerFont = new Font(_baseFont, 7, Font.NORMAL, BaseColor.BLACK);
            Font _mediumFont = new Font(_baseFont, 10, Font.NORMAL, BaseColor.BLACK);
            Font _headerFont = new Font(_baseFont, 18, Font.NORMAL, BaseColor.BLACK);
            Font _normalFont = new Font(_baseFont, 12, Font.NORMAL, BaseColor.BLACK);

            document.Open();

          //document.NewPage(); // Explicitly start a new page
          //document.Add(new Paragraph("This is on a new page."));

            PdfPTable table = new PdfPTable(4);
            table.TotalWidth = 500f;
            table.LockedWidth = true;

            float[] widths = new float[] { 1f, 1f, 1f, 1f };
            table.SetWidths(widths);
            table.HorizontalAlignment = Element.ALIGN_CENTER;

            PdfPCell cell;
            var physicalPath = imagePath;
            Image png = Image.GetInstance(physicalPath);

            cell = new PdfPCell(png);
            cell.Colspan = 2;
            cell.Rowspan = 2;
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.PaddingTop = 6;
            cell.PaddingBottom = 6;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("System Form", _smallFont));
            cell.Colspan = 3;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
            cell.PaddingTop = 3;
            cell.PaddingLeft = 5;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Shipping Weight Verification Sheet", _headerFont));
            cell.Colspan = 3;
            cell.DisableBorderSide(Rectangle.TOP_BORDER);
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_TOP;
            cell.PaddingTop = 13;
            cell.PaddingLeft = 5;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("REVISION: A", _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("FORM #: STF 079", _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.DisableBorderSide(Rectangle.RIGHT_BORDER);
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("", _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.DisableBorderSide(Rectangle.LEFT_BORDER);
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingRight = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("DATE EFFECTIVE: 3/4/2013", _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            table.SpacingAfter = 30f;
            document.Add(table);


            table = new PdfPTable(3);
            table.TotalWidth = 500f;
            table.LockedWidth = true;

            widths = new float[] { 1f, 1f, 1f };
            table.SetWidths(widths);
            table.HorizontalAlignment = Element.ALIGN_CENTER;


            cell = new PdfPCell(new Phrase("Date/Time: " + model.CreateDateTime, _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Weighed By: " + model.WeighedBy, _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Weigh Facility:", _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Vehicle Type: " + model.VehicleType, _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Supreme Location: " + model.SupremeLocation, _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Weigh Facility License No.:", _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingLeft = 5;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("(This is for units not weighed at a Wabash facility)", _smallerFont));
            cell.Colspan = 4;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.PaddingRight = 5;
            cell.FixedHeight = 20.0f;
            cell.DisableBorderSide(Rectangle.LEFT_BORDER);
            cell.DisableBorderSide(Rectangle.RIGHT_BORDER);
            cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
            table.AddCell(cell);

            table.SpacingAfter = 30f;
            document.Add(table);


            table = new PdfPTable(2);
            table.TotalWidth = 450f;
            table.LockedWidth = true;

            widths = new float[] { 1f, 1f, };
            table.SetWidths(widths);
            table.HorizontalAlignment = Element.ALIGN_CENTER;


            cell = new PdfPCell(new Phrase("Document Serial:", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.DocumentSerial, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Wabash Body Number:", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.SupremeBodyNumber, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Wabash Model:", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.SupremeModel, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("G.V.W.R. (Gross Vehicle Weight Rating):", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.GVWR, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Weight at Front Axle:", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.WeightFrontAxle, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Total Vehicle Weight:", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.TotalVehicleWeight, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Weight at Rear Axle:", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.WeightRearAxle, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("VIN (must include all 17 digits):", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.VIN, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Customer Name:", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.CustomerName, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Customer Address:", _normalFont));
            cell.Colspan = 1;
            cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.CustomerAddress1, _normalFont));
            cell.Colspan = 1;
            cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("", _normalFont));
            cell.Colspan = 1;
            cell.DisableBorderSide(Rectangle.TOP_BORDER);
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.CustomerAddress2, _normalFont));
            cell.Colspan = 1;
            cell.DisableBorderSide(Rectangle.TOP_BORDER);
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Number of Units:", _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);
            cell = new PdfPCell(new Phrase(model.NumberOfUnits, _normalFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            StringBuilder msg = new StringBuilder();
            msg.Append("Scales on Wabash facilities are regularly calibrated for their accuracy ");
            msg.Append("and the certificates of those calibrations are available at each facility ");
            msg.Append("upon request.");

            cell = new PdfPCell(new Phrase(msg.ToString(), _mediumFont));
            cell.Colspan = 2;
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 40.0f;
            cell.PaddingLeft = 30f;
            cell.PaddingRight = 30f;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Remarks: " + model.Remarks, _normalFont));
            cell.Colspan = 2;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_TOP;
            cell.FixedHeight = 20.0f;
            cell.PaddingLeft = 5;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("Signature: " + model.Signature, _normalFont));
            cell.Colspan = 2;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            cell.PaddingLeft = 5;
            table.AddCell(cell);

            cell = new PdfPCell(new Phrase("License Number: " + model.LicenseNumber, _normalFont));
            cell.Colspan = 2;
            cell.HorizontalAlignment = Element.ALIGN_LEFT;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.FixedHeight = 20.0f;
            cell.PaddingLeft = 5;
            table.AddCell(cell);



            table.SpacingAfter = 180f;
            document.Add(table);

            table = new PdfPTable(1);
            table.TotalWidth = 500f;
            table.LockedWidth = true;

            widths = new float[] { 1f };
            table.SetWidths(widths);
            table.HorizontalAlignment = Element.ALIGN_CENTER;

            StringBuilder foot = new StringBuilder();
            foot.Append("2581 East Kercher Road - P.O. Box 463 - Goshen, Indiana 46528 - (574) 642-4888 - Fax (574) 642-4891 - onewabash.com");
            cell = new PdfPCell(new Phrase(foot.ToString(), _smallFont));
            cell.Colspan = 1;
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
            cell.DisableBorderSide(Rectangle.TOP_BORDER);
            cell.DisableBorderSide(Rectangle.RIGHT_BORDER);
            cell.DisableBorderSide(Rectangle.LEFT_BORDER);
            cell.FixedHeight = 20.0f;
            table.AddCell(cell);

            table.SpacingAfter = 30f;
            document.Add(table);


            //document.Close();
              m.Position = 0;
          // Reset the stream position to the beginning before returning

          return m;
          }*/

        public System.IO.MemoryStream CreateUniversalPDF()
        {
            MemoryStream m = new MemoryStream();

            using (Document document = new Document())
            {
                PdfWriter writer = PdfWriter.GetInstance(document, m);
                writer.CloseStream = false; // Prevent the writer from closing the MemoryStream

                WeightSheetServices db = new WeightSheetServices();
                WeightSheetUniversalModel model = new WeightSheetUniversalModel();
                model = db.GetUniversalWeightSheet(SerialNumber, PDFVehicleType, PDFWeightFrontAxle,
                                                   PDFTotalVehicleWeight, PDFWeightRearAxle, PDFRemark,
                                                   UserName);

                BaseFont _baseFont = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.WINANSI, BaseFont.NOT_EMBEDDED);
                Font _smallFont = new Font(_baseFont, 8, Font.NORMAL, BaseColor.BLACK);
                Font _smallerFont = new Font(_baseFont, 7, Font.NORMAL, BaseColor.BLACK);
                Font _mediumFont = new Font(_baseFont, 10, Font.NORMAL, BaseColor.BLACK);
                Font _headerFont = new Font(_baseFont, 18, Font.NORMAL, BaseColor.BLACK);
                Font _normalFont = new Font(_baseFont, 12, Font.NORMAL, BaseColor.BLACK);

                document.Open();
                // Add content to the document

                PdfPTable table = new PdfPTable(4);
                table.TotalWidth = 500f;
                table.LockedWidth = true;

                float[] widths = new float[] { 1f, 1f, 1f, 1f };
                table.SetWidths(widths);
                table.HorizontalAlignment = Element.ALIGN_CENTER;

                PdfPCell cell;
                var physicalPath = imagePath;
                Image png = Image.GetInstance(physicalPath);

                cell = new PdfPCell(png);
                cell.Colspan = 2;
                cell.Rowspan = 2;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                cell.PaddingTop = 6;
                cell.PaddingBottom = 6;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("System Form", _smallFont));
                cell.Colspan = 3;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
                cell.PaddingTop = 3;
                cell.PaddingLeft = 5;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Shipping Weight Verification Sheet", _headerFont));
                cell.Colspan = 3;
                cell.DisableBorderSide(Rectangle.TOP_BORDER);
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_TOP;
                cell.PaddingTop = 13;
                cell.PaddingLeft = 5;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("REVISION: A", _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("FORM #: STF 079", _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.DisableBorderSide(Rectangle.RIGHT_BORDER);
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("", _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.DisableBorderSide(Rectangle.LEFT_BORDER);
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingRight = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("DATE EFFECTIVE: 3/4/2013", _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                table.SpacingAfter = 30f;
                document.Add(table);

                // 2
                table = new PdfPTable(3);
                table.TotalWidth = 500f;
                table.LockedWidth = true;

                widths = new float[] { 1f, 1f, 1f };
                table.SetWidths(widths);
                table.HorizontalAlignment = Element.ALIGN_CENTER;


                cell = new PdfPCell(new Phrase("Date/Time: " + model.CreateDateTime, _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Weighed By: " + model.WeighedBy, _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Weigh Facility:", _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Vehicle Type: " + model.VehicleType, _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Supreme Location: " + model.SupremeLocation, _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Weigh Facility License No.:", _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingLeft = 5;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("(This is for units not weighed at a Wabash facility)", _smallerFont));
                cell.Colspan = 4;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.PaddingRight = 5;
                cell.FixedHeight = 20.0f;
                cell.DisableBorderSide(Rectangle.LEFT_BORDER);
                cell.DisableBorderSide(Rectangle.RIGHT_BORDER);
                cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
                table.AddCell(cell);

                table.SpacingAfter = 30f;
                document.Add(table);

                // 3
                table = new PdfPTable(2);
                table.TotalWidth = 450f;
                table.LockedWidth = true;

                widths = new float[] { 1f, 1f, };
                table.SetWidths(widths);
                table.HorizontalAlignment = Element.ALIGN_CENTER;


                cell = new PdfPCell(new Phrase("Document Serial:", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.DocumentSerial, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Wabash Body Number:", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.SupremeBodyNumber, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Wabash Model:", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.SupremeModel, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("G.V.W.R. (Gross Vehicle Weight Rating):", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.GVWR, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Weight at Front Axle:", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.WeightFrontAxle, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Total Vehicle Weight:", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.TotalVehicleWeight, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Weight at Rear Axle:", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.WeightRearAxle, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("VIN (must include all 17 digits):", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.VIN, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Customer Name:", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.CustomerName, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Customer Address:", _normalFont));
                cell.Colspan = 1;
                cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.CustomerAddress1, _normalFont));
                cell.Colspan = 1;
                cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("", _normalFont));
                cell.Colspan = 1;
                cell.DisableBorderSide(Rectangle.TOP_BORDER);
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.CustomerAddress2, _normalFont));
                cell.Colspan = 1;
                cell.DisableBorderSide(Rectangle.TOP_BORDER);
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Number of Units:", _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);
                cell = new PdfPCell(new Phrase(model.NumberOfUnits, _normalFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                StringBuilder msg = new StringBuilder();
                msg.Append("Scales on Wabash facilities are regularly calibrated for their accuracy ");
                msg.Append("and the certificates of those calibrations are available at each facility ");
                msg.Append("upon request.");

                cell = new PdfPCell(new Phrase(msg.ToString(), _mediumFont));
                cell.Colspan = 2;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 40.0f;
                cell.PaddingLeft = 30f;
                cell.PaddingRight = 30f;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Remarks: " + model.Remarks, _normalFont));
                cell.Colspan = 2;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_TOP;
                cell.FixedHeight = 20.0f;
                cell.PaddingLeft = 5;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("Signature: " + model.Signature, _normalFont));
                cell.Colspan = 2;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                cell.PaddingLeft = 5;
                table.AddCell(cell);

                cell = new PdfPCell(new Phrase("License Number: " + model.LicenseNumber, _normalFont));
                cell.Colspan = 2;
                cell.HorizontalAlignment = Element.ALIGN_LEFT;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.FixedHeight = 20.0f;
                cell.PaddingLeft = 5;
                table.AddCell(cell);

                table.SpacingAfter = 180f;
                document.Add(table);

                // 4
                table = new PdfPTable(1);
                table.TotalWidth = 500f;
                table.LockedWidth = true;

                widths = new float[] { 1f };
                table.SetWidths(widths);
                table.HorizontalAlignment = Element.ALIGN_CENTER;

                StringBuilder foot = new StringBuilder();
                foot.Append("2581 East Kercher Road - P.O. Box 463 - Goshen, Indiana 46528 - (574) 642-4888 - Fax (574) 642-4891 - onewabash.com");
                cell = new PdfPCell(new Phrase(foot.ToString(), _smallFont));
                cell.Colspan = 1;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                cell.VerticalAlignment = Element.ALIGN_MIDDLE;
                cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);
                cell.DisableBorderSide(Rectangle.TOP_BORDER);
                cell.DisableBorderSide(Rectangle.RIGHT_BORDER);
                cell.DisableBorderSide(Rectangle.LEFT_BORDER);
                cell.FixedHeight = 20.0f;
                table.AddCell(cell);

                table.SpacingAfter = 30f;
                document.Add(table);

                // Close the document
                document.Close();
            }

            m.Position = 0; // Reset the stream position to the beginning

            return m;
        }

    }
}