﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class WaterTestServices
  {
    public string AddWaterTest(WaterTestModel _waterTest)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      _waterTest.ResetNullValues();
      if (_waterTest.DefectArea == "")
        _waterTest.DefectArea = "NL";

      if (_waterTest.DefectItem == "")
        _waterTest.DefectItem = "NL";

      if (_waterTest.DefectType == "")
        _waterTest.DefectType = "NL";

      if (_waterTest.Category == null)
        _waterTest.Category = "";
            

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("insert into ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF (");
            sql.Append("QWSR#, QWDA, QWDI, QWDT, QWWP, QWGM, QWITYP,  ");
            sql.Append("QWIDTE, QWTIME, QWDATE, QWUSER, QWTEXT ");
            sql.Append(") values (");
            sql.Append("@SerialNumber, @Area, @Item, @Type, @Pressure, @GallonsPerMinute,");
            sql.Append("@InspectionType, ");
            sql.Append("@WaterTestCreateDate, @WaterTestCreateTime, ");
            sql.Append("@WaterTestDate, @WaterTestCreatedBy, @Category "); //added by Khalid#2
            sql.Append(")");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _waterTest.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@Area", _waterTest.DefectArea.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@Item", _waterTest.DefectItem.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@Type", _waterTest.DefectType.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@Pressure", _waterTest.WaterPressure));
            cmd.Parameters.Add(new iDB2Parameter("@GallonsPerMinute", _waterTest.GallonsPerMinute));
            cmd.Parameters.Add(new iDB2Parameter("@InspectionType", _waterTest.InspectionType.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", DBUtils.GetAS400Date(CreateDateTime)));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", DBUtils.GetAS400Time(CreateDateTime)));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestDate", DBUtils.GetAS400Date(_waterTest.WaterTestDate)));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreatedBy", _waterTest.WaterTestCreatedBy.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@Category", _waterTest.Category.Trim()));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Record not added, exception no thrown");
            else
            {
              WaterTestLogServices wtLog = new WaterTestLogServices();
              wtLog.UpdateLog(_waterTest.SerialNumber, DBUtils.GetAS400Date(CreateDateTime), DBUtils.GetAS400Time(CreateDateTime));

              return "";
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestServices", "", "Error in AddWaterTest", ex);
        throw new ApplicationException("Add Water Test: " + ex.Message, ex);
      }
    }

    public string UpdateWaterTest(WaterTestModel _waterTest)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      _waterTest.ResetNullValues();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF  ");
            sql.Append(" where QWSR#=@SerialNumber ");
            sql.Append("   and QWIDTE=@WaterTestCreateDate ");
            sql.Append("   and QWTIME=@WaterTestCreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _waterTest.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _waterTest.WaterTestCreateDate));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _waterTest.WaterTestCreateTime));


            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Update ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QWTF  ");
              sql.Append("Set ");
              sql.Append(" QWDA = @Area, ");
              sql.Append(" QWDI = @Item, ");
              sql.Append(" QWDT = @Type, ");
              sql.Append(" QWWP = @Pressure, ");
              sql.Append(" QWGM = @GallonsPerMinute, ");
              sql.Append(" QWITYP = @InspectionType, ");
              sql.Append(" QWDATE = @WaterTestDate, ");
              sql.Append(" QWTEXT = @Category ");  //added by Khalid#2
              sql.Append(" where QWSR#=@SerialNumber ");
              sql.Append("   and QWIDTE=@WaterTestCreateDate ");
              sql.Append("   and QWTIME=@WaterTestCreateTime ");

              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _waterTest.SerialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@Area", _waterTest.DefectArea.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@Item", _waterTest.DefectItem.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@Type", _waterTest.DefectType.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@Pressure", _waterTest.WaterPressure));
              cmd.Parameters.Add(new iDB2Parameter("@GallonsPerMinute", _waterTest.GallonsPerMinute));
              cmd.Parameters.Add(new iDB2Parameter("@InspectionType", _waterTest.InspectionType.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _waterTest.WaterTestCreateDate));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _waterTest.WaterTestCreateTime));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestDate", DBUtils.GetAS400Date(_waterTest.WaterTestDate)));
              cmd.Parameters.Add(new iDB2Parameter("@Category", _waterTest.Category.Trim())); //added by Khalid#2

                            result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Update Water Test: Record not updated, no exception thrown");
              else
              {
                WaterTestLogServices wtLog = new WaterTestLogServices();
                wtLog.UpdateLog(_waterTest.SerialNumber, _waterTest.WaterTestCreateDate, _waterTest.WaterTestCreateTime);
                return "";
              }
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              if (result > 1)
                msg.Append("Multiple records found - ");
              else
                msg.Append("Update Water Test: Invalid parameters - ");
              msg.Append(_waterTest.SerialNumber);
              msg.Append(", ");
              msg.Append(_waterTest.WaterTestCreateDate);
              msg.Append(", ");
              msg.Append(_waterTest.WaterTestCreateTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestServices", "", "Error in UpdateWaterTest", ex);
        throw new ApplicationException("Update Water Test: " + ex.Message, ex);
      }
    }

    public string DeleteWaterTest(WaterTestModel _waterTest)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF  ");
            sql.Append(" where QWSR#=@SerialNumber ");
            sql.Append("   and QWIDTE=@WaterTestCreateDate ");
            sql.Append("   and QWTIME=@WaterTestCreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _waterTest.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _waterTest.WaterTestCreateDate));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _waterTest.WaterTestCreateTime));


            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Delete from ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QWTF  ");
              sql.Append(" where QWSR#=@SerialNumber ");
              sql.Append("   and QWIDTE=@WaterTestCreateDate ");
              sql.Append("   and QWTIME=@WaterTestCreateTime ");

              cmd.Parameters.Clear();
              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _waterTest.SerialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _waterTest.WaterTestCreateDate));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _waterTest.WaterTestCreateTime));

              result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Delete Water Test: Record not deleted, no exception thrown");
              else
              {
                WaterTestLogServices wtLog = new WaterTestLogServices();
                wtLog.UpdateLogWithDelete(_waterTest.SerialNumber, _waterTest.WaterTestCreateDate, _waterTest.WaterTestCreateTime);
                return "";
              }
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              if (result > 1)
                msg.Append("Multiple records found - ");
              else
                msg.Append("Delete Water Test: Invalid parameters - ");
              msg.Append(_waterTest.SerialNumber);
              msg.Append(", ");
              msg.Append(_waterTest.WaterTestCreateDate);
              msg.Append(", ");
              msg.Append(_waterTest.WaterTestCreateTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestServices", "", "Error in DeleteWaterTest", ex);
        throw new ApplicationException("Delete Water Test: " + ex.Message, ex);
      }
    }

    public List<WaterTestIndexModel> GetWaterTestForIndex(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      WaterTestIndexModel wt;
      List<WaterTestIndexModel> wtList = new List<WaterTestIndexModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select DISTINCT QWSR#, QWDATE, QWITYP, QWDA, QWDI, QWDT, QWGM, QWWP,  ");
            sql.Append("       QWIDTE, QWTIME, ");
            sql.Append("       DADESC, DIDESC, DTDESC, ITDESC, QWTEXT "); //QWTEXT filed added by Khalid#2 for "Category" 
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDAF ");
            sql.Append(" on QWDA = DAID#");
            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDTF ");
            sql.Append(" on QWDT = DTID#");
            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDCF ");
            sql.Append(" on DCTID# = DTID#");
            sql.Append(" left outer join ");
            sql.Append(" ( SELECT DIID#, MAX(DIDESC) AS DIDESC FROM ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDIF ");
            sql.Append(" WHERE DISTAT = 'A' GROUP BY DIID#) AS QDIF on QWDI = QDIF.DIID# ");
            sql.Append(" left outer join ");
            
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QITF ");
            sql.Append(" on QWITYP = ITID# ");
            sql.Append(" where QWSR#=@SerialNumber ");
            sql.Append(" AND DTSTAT= 'A' ");
            sql.Append(" order by QWDATE ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

            //cn.ConnectionString = "Datasource=192.168.30.8; UserId=PRINTER; Password=PRINTER";
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            // get Serial Number, Model, Order Number, and Warehouse
            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  wt = new WaterTestIndexModel();
                  wt.WaterTestDate = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QWDATE"]));
                  wt.InspectionType = DBUtils.GetSafeString(rdr["ITDESC"]).Trim();
                  wt.DefectArea = DBUtils.GetSafeString(rdr["QWDA"]).Trim();
                  wt.AreaDesc = DBUtils.GetSafeString(rdr["DADESC"]).Trim();
                  wt.DefectItem = DBUtils.GetSafeString(rdr["QWDI"]).Trim();
                  wt.ItemDesc = DBUtils.GetSafeString(rdr["DIDESC"]).Trim();
                  wt.DefectType = DBUtils.GetSafeString(rdr["QWDT"]).Trim();
                  wt.TypeDesc = DBUtils.GetSafeString(rdr["DTDESC"]).Trim();
                  wt.GallonsPerMinute = DBUtils.GetSafeString(rdr["QWGM"]);
                  wt.WaterPressure = DBUtils.GetSafeString(rdr["QWWP"]);
                  wt.SerialNumber = DBUtils.GetSafeString(rdr["QWSR#"]).Trim();
                  wt.WaterTestCreateDate = DBUtils.GetSafeString(rdr["QWIDTE"]);
                  wt.WaterTestCreateTime = DBUtils.GetSafeString(rdr["QWTIME"]);
                  wt.Category = DBUtils.GetSafeString(rdr["QWTEXT"]).Trim();
                  wtList.Add(wt);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestServices", "", "Error in GetWaterTestForIndex", ex);
        throw new ApplicationException("Get Water Test for Index: " + ex.Message, ex);
      }
      return wtList;
    }

    public WaterTestModel GetSingleWaterTest(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      WaterTestModel wt = new WaterTestModel();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select * ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF");
            sql.Append(" where QWSR#=@SerialNumber ");
            sql.Append("   and QWIDTE=@CreateDate ");
            sql.Append("   and QWTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

            //cn.ConnectionString = "Datasource=192.168.30.8; UserId=PRINTER; Password=PRINTER";
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            // get Serial Number, Model, Order Number, and Warehouse
            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  wt = new WaterTestModel();
                  wt.SerialNumber = DBUtils.GetSafeString(rdr["QWSR#"]).Trim();
                  wt.WaterTestDate = DBUtils.GetSafeDateTime(rdr["QWDATE"]);
                  wt.InspectionType = DBUtils.GetSafeString(rdr["QWITYP"]).Trim();
                  wt.DefectArea = DBUtils.GetSafeString(rdr["QWDA"]).Trim();
                  wt.DefectItem = DBUtils.GetSafeString(rdr["QWDI"]).Trim();
                  wt.DefectType = DBUtils.GetSafeString(rdr["QWDT"]).Trim();
                  wt.WaterPressure = DBUtils.GetSafeString(rdr["QWWP"]);
                  wt.GallonsPerMinute = DBUtils.GetSafeString(rdr["QWGM"]);
                  wt.WaterTestCreateDate = DBUtils.GetSafeString(rdr["QWIDTE"]);
                  wt.WaterTestCreateTime = DBUtils.GetSafeString(rdr["QWTIME"]);
                  wt.WaterTestCreatedBy = DBUtils.GetSafeString(rdr["QWUSER"]).Trim();
                  wt.RepairItem = DBUtils.GetSafeString(rdr["QWRI"]).Trim();
                  wt.RepairAction = DBUtils.GetSafeString(rdr["QWRA"]).Trim();
                  wt.RepairCreateTime = DBUtils.GetSafeString(rdr["QWRTIME"]);
                  wt.RepairCreateDate = DBUtils.GetSafeString(rdr["QWRDATE"]);
                  wt.RepairCreatedBy = DBUtils.GetSafeString(rdr["QWRUSER"]).Trim();
                  wt.Category = DBUtils.GetSafeString(rdr["QWTEXT"]);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestServices", "", "Error in GetSingleWaterTest", ex);
        throw new ApplicationException("Get Single Water Test: " + ex.Message, ex);
      }
      return wt;
    }

    public WaterTestIndexModel GetSingleWaterTestForDelete(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      WaterTestIndexModel model = null;

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QWSR#, QWDATE, QWITYP, QWDA, QWDI, QWDT, QWGM, QWWP,  ");
            sql.Append("       QWIDTE, QWTIME, ");
            sql.Append("       DADESC, DIDESC, DTDESC, ITDESC, QWTEXT ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDAF ");
            sql.Append(" on QWDA = DAID#");
            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDIF ");
            sql.Append(" on QWDI = DIID#");
            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDTF ");
            sql.Append(" on QWDT = DTID#");
            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QITF ");
            sql.Append(" on QWITYP = ITID#");
            sql.Append(" where QWSR#=@SerialNumber");
            sql.Append("   and QWIDTE=@CreateDate ");
            sql.Append("   and QWTIME=@CreateTime ");
            sql.Append(" order by QWDATE");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

            //cn.ConnectionString = "Datasource=192.168.30.8; UserId=PRINTER; Password=PRINTER";
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            // get Serial Number, Model, Order Number, and Warehouse
            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new WaterTestIndexModel();
                  model.WaterTestDate = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QWDATE"]));
                  model.InspectionType = DBUtils.GetSafeString(rdr["ITDESC"]);
                  model.DefectArea = DBUtils.GetSafeString(rdr["QWDA"]);
                  model.AreaDesc = DBUtils.GetSafeString(rdr["DADESC"]);
                  model.DefectItem = DBUtils.GetSafeString(rdr["QWDI"]);
                  model.ItemDesc = DBUtils.GetSafeString(rdr["DIDESC"]);
                  model.DefectType = DBUtils.GetSafeString(rdr["QWDT"]);
                  model.TypeDesc = DBUtils.GetSafeString(rdr["DTDESC"]);
                  model.GallonsPerMinute = DBUtils.GetSafeString(rdr["QWGM"]);
                  model.WaterPressure = DBUtils.GetSafeString(rdr["QWWP"]);
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QWSR#"]);
                  model.WaterTestCreateDate = DBUtils.GetSafeString(rdr["QWIDTE"]);
                  model.WaterTestCreateTime = DBUtils.GetSafeString(rdr["QWTIME"]);
                  model.Category = DBUtils.GetSafeString(rdr["QWTEXT"]); // added by Khalid#2
                                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestServices", "", "Error in GetSingleWaterTestForDelete", ex);
        throw new ApplicationException("Get Single Water Test for Delete: " + ex.Message, ex); ;
      }
      return model;
    }

    public List<WaterTestIndexModel> GetInitialWaterTests(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      WaterTestIndexModel wt;
      List<WaterTestIndexModel> wtList = new List<WaterTestIndexModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QWITYP, QWDA, QWDI, QWDT ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF ");
            sql.Append(" where QWSR#=@SerialNumber ");
            sql.Append(" and QWITYP=@InspectionType ");
            if ((_createDate != "") && (_createTime != ""))
            {
              sql.Append(" and (QWIDTE<>@WaterTestCreateDate ");
              sql.Append(" or QWTIME<>@WaterTestCreateTime) ");
            }

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@InspectionType", "INIT"));
            if ((_createDate != "") && (_createTime != ""))
            {
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _createDate));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _createTime));
            }

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  wt = new WaterTestIndexModel();

                  wt.InspectionType = DBUtils.GetSafeString(rdr["QWITYP"]).Trim();
                  wt.DefectArea = DBUtils.GetSafeString(rdr["QWDA"]).Trim();
                  wt.DefectItem = DBUtils.GetSafeString(rdr["QWDI"]).Trim();
                  wt.DefectType = DBUtils.GetSafeString(rdr["QWDT"]).Trim();
                  wtList.Add(wt);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestServices", "", "Error in GetInitialWaterTests", ex);
        throw new ApplicationException("Get Initial Water Tests: " + ex.Message, ex);
      }
      return wtList;
    }
  }
}