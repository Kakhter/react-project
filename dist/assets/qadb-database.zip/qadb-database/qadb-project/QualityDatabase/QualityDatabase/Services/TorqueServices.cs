﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace QualityDatabase.Services
{
  public class TorqueServices
  {
    public string AddTorque(TorqueModel _torque)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      _torque.ResetNullValues();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("insert into ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QMTF (");
            sql.Append("QMSR#, QMUBN, QMUBS, QMUBC, QMINS,  ");
            sql.Append("QMTIME, QMDATE, QMUSER ");
            sql.Append(") values (");
            sql.Append("@SerialNumber, @UboltNumber, @UboltServer, @UboltCurb, ");
            sql.Append("@Inspector, ");
            sql.Append("@TorqueCreateTime, @TorqueCreateDate, @TorqueCreatedBy ");
            sql.Append(")");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _torque.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@UboltNumber", _torque.UboltNumber));
            cmd.Parameters.Add(new iDB2Parameter("@UboltServer", _torque.UboltStreetSide));
            cmd.Parameters.Add(new iDB2Parameter("@UboltCurb", _torque.UboltCurbSide));
            cmd.Parameters.Add(new iDB2Parameter("@Inspector", _torque.Inspector.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@TorqueCreateDate", DBUtils.GetAS400Date(CreateDateTime)));
            cmd.Parameters.Add(new iDB2Parameter("@TorqueCreateTime", DBUtils.GetAS400Time(CreateDateTime)));
            cmd.Parameters.Add(new iDB2Parameter("@TorqueCreatedBy", _torque.TorqueCreatedBy.Trim()));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Add Torque: Record not added, exception no thrown");
            else
              return "";
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TorqueServices", "", "Error in AddTorque", ex);
        throw new ApplicationException("Add Torque: " + ex.Message, ex);
      }
    }

    public string UpdateTorque(TorqueModel _torque)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      _torque.ResetNullValues();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QMTF  ");
            sql.Append(" where QMSR#=@SerialNumber ");
            sql.Append("   and QMDATE=@CreateDate ");
            sql.Append("   and QMTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _torque.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _torque.TorqueCreateDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _torque.TorqueCreateTime));


            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Update ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QMTF  ");
              sql.Append("Set ");
              sql.Append(" QMUBN = @UBoltNumber, ");
              sql.Append(" QMUBS = @UBoltStreet, ");
              sql.Append(" QMUBC = @UBoltCurb, ");
              sql.Append(" QMINS = @Inspector ");
              sql.Append(" where QMSR#=@SerialNumber ");
              sql.Append("   and QMDATE=@CreateDate ");
              sql.Append("   and QMTIME=@CreateTime ");

              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@UBoltNumber", _torque.UboltNumber));
              cmd.Parameters.Add(new iDB2Parameter("@UBoltStreet", _torque.UboltStreetSide));
              cmd.Parameters.Add(new iDB2Parameter("@UBoltCurb", _torque.UboltCurbSide));
              cmd.Parameters.Add(new iDB2Parameter("@Inspector", _torque.Inspector.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _torque.SerialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _torque.TorqueCreateDate));
              cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _torque.TorqueCreateTime));

              result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Update Torque: Record not updated, no exception thrown");
              else
                return "";
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              if (result > 1)
                msg.Append("Multiple records found - ");
              else
                msg.Append("Update Torque: Invalid parameters - ");
              msg.Append(_torque.SerialNumber);
              msg.Append(", ");
              msg.Append(_torque.TorqueCreateDate);
              msg.Append(", ");
              msg.Append(_torque.TorqueCreateTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TorqueServices", "", "Error in UpdateTorque", ex);
        throw new ApplicationException("Update Torque: " + ex.Message, ex);
      }
    }

    public string DeleteTorque(TorqueModel _torque)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QMTF  ");
            sql.Append(" where QMSR#=@SerialNumber ");
            sql.Append("   and QMDATE=@CreateDate ");
            sql.Append("   and QMTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _torque.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _torque.TorqueCreateDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _torque.TorqueCreateTime));


            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Delete from ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QMTF  ");
              sql.Append(" where QMSR#=@SerialNumber ");
              sql.Append("   and QMDATE=@CreateDate ");
              sql.Append("   and QMTIME=@CreateTime ");

              cmd.Parameters.Clear();
              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _torque.SerialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _torque.TorqueCreateDate));
              cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _torque.TorqueCreateTime));

              result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Delete Torque: Record not deleted, no exception thrown");
              else
              {
                return "";
              }
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              if (result > 1)
                msg.Append("Multiple records found - ");
              else
                msg.Append("Delete Torque: Invalid parameters - ");
              msg.Append(_torque.SerialNumber);
              msg.Append(", ");
              msg.Append(_torque.TorqueCreateDate);
              msg.Append(", ");
              msg.Append(_torque.TorqueCreateTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TorqueServices", "", "Error in DeleteTorque", ex);
        throw new ApplicationException("Delete Torque: " + ex.Message, ex);
      }
    }

    public List<TorqueModel> GetTorqueForIndex(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      TorqueModel model = null;
      List<TorqueModel> list = new List<TorqueModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QMSR#, ");
            sql.Append(" QMUBN, QMUBS, QMUBC, ");
            sql.Append(" QMINS, ");
            sql.Append(" QMTIME, QMDATE, QMUSER, ");
            sql.Append(" IINAME ");
            sql.Append("from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QMTF ");

            sql.Append("left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QIIF ");
            sql.Append(" on QMINS = IIID# ");

            sql.Append(" where QMSR#=@SerialNumber");
            sql.Append(" order by QMDATE, QMTIME");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new TorqueModel();
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QMSR#"]).Trim();
                  model.UboltNumber = DBUtils.GetSafeDouble(rdr["QMUBN"]);
                  model.UboltStreetSide = DBUtils.GetSafeDouble(rdr["QMUBS"]);
                  model.UboltCurbSide = DBUtils.GetSafeDouble(rdr["QMUBC"]);
                  model.Inspector = DBUtils.GetSafeString(rdr["QMINS"]).Trim();
                  model.TorqueCreateDate = DBUtils.GetSafeString(rdr["QMDATE"]);
                  model.TorqueCreateTime = DBUtils.GetSafeString(rdr["QMTIME"]);
                  model.TorqueCreatedBy = DBUtils.GetSafeString(rdr["QMUSER"]).Trim();
                  model.FullName = DBUtils.GetSafeString(rdr["IINAME"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TorqueServices", "", "Error in GetTorqueForIndex", ex);
        throw new ApplicationException("Get Torque for Index: " + ex.Message, ex);
      }
      return list;
    }

    public TorqueModel GetSingleTorque(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      TorqueModel model = new TorqueModel();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            //sql = new StringBuilder();
            //sql.Append("select * ");
            //sql.Append(" from ");
            //sql.Append(DBUtils.GetSUPxxx010().Trim());
            //sql.Append(".QMTF");

            sql = new StringBuilder();
            sql.Append("select QMSR#, ");
            sql.Append(" QMUBN, QMUBS, QMUBC, ");
            sql.Append(" QMINS, ");
            sql.Append(" QMTIME, QMDATE, QMUSER, ");
            sql.Append(" IINAME ");
            sql.Append("from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QMTF ");

            sql.Append("left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QIIF ");
            sql.Append(" on QMINS = IIID# ");

            //sql.Append(" where QMSR#=@SerialNumber");
            //sql.Append(" order by QMDATE, QMTIME");


            sql.Append(" where QMSR#=@SerialNumber ");
            sql.Append("   and QMDATE=@CreateDate ");
            sql.Append("   and QMTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new TorqueModel();
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QMSR#"]).Trim();
                  model.UboltNumber = DBUtils.GetSafeDouble(rdr["QMUBN"]);
                  model.UboltStreetSide = DBUtils.GetSafeDouble(rdr["QMUBS"]);
                  model.UboltCurbSide = DBUtils.GetSafeDouble(rdr["QMUBC"]);
                  model.Inspector = DBUtils.GetSafeString(rdr["QMINS"]).Trim();
                  model.TorqueCreateDate = DBUtils.GetSafeString(rdr["QMDATE"]);
                  model.TorqueCreateTime = DBUtils.GetSafeString(rdr["QMTIME"]);
                  model.TorqueCreatedBy = DBUtils.GetSafeString(rdr["QMUSER"]).Trim();
                  model.FullName = DBUtils.GetSafeString(rdr["IINAME"]).Trim();
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TorqueServices", "", "Error in GetSingleTorque", ex);
        throw new ApplicationException("Get Single Torque: " + ex.Message, ex);
      }
      return model;
    }

  }
}