﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
    public class LineInspectionServices
    {
        public string GetRealizedCommandText(iDB2Command command)
        {
            string realizedCommandText = command.CommandText;

            foreach (iDB2Parameter param in command.Parameters)
            {
                string paramPlaceholder = param.ParameterName;
                string paramValue = param.Value.ToString();

                // Make sure paramValue is properly escaped if needed, especially if it's a string

                realizedCommandText = realizedCommandText.Replace(paramPlaceholder, "'" + paramValue + "'");
            }

            return realizedCommandText;
        }

        public string AddLineInspection(LineInspectionModel _lineInspection)
        {
            StringBuilder sql = new StringBuilder();
            int result = 0;
            DateTime CreateDateTime = DateTime.Now;

            _lineInspection.ResetNullValues();

            if (_lineInspection.DefectArea == "")
                _lineInspection.DefectArea = "ND";

            if (_lineInspection.DefectItem == "")
                _lineInspection.DefectItem = "ND";

            if (_lineInspection.DefectType == "")
                _lineInspection.DefectType = "ND";

            if (_lineInspection.DefectCondition == "")
                _lineInspection.DefectCondition = "ND";

            if (_lineInspection.OfflineOperation == "" || _lineInspection.OfflineOperation == " ")
                _lineInspection.OfflineOperation = "NA";
            if (_lineInspection.ReasonForFailure == "" || _lineInspection.ReasonForFailure == " ")
                _lineInspection.ReasonForFailure = "F";


            try
            {
                using (var cn = new iDB2Connection())
                {
                    cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                    cn.Open();

                    using (var cmd = cn.CreateCommand())
                    {
                        // First insert into QLIF 
                        sql = new StringBuilder();
                        sql.Append("insert into ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF (");
                        sql.Append("QLSR#, QLIL, QLIN, QLIT, QLDA, QLDI, QLDT, QLDC,  ");
                        sql.Append("QLIDTE, QLTIME, QLDATE, QLIUSER");
                        sql.Append(", QLIO, QLRF ");
                        sql.Append(") values (");
                        sql.Append("@SerialNumber, @InspectionLocation, @Inspector, @InspectionType, ");
                        sql.Append("@DefectArea, @DefectItem, @DefectType, @DefectCondition, ");
                        sql.Append("@CreateDate, @CreateTime, ");
                        sql.Append("@InspectionDate, @User ");
                        sql.Append(", @Offline, @ReasonForFailure  ");
                        sql.Append(")");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _lineInspection.SerialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@InspectionLocation", _lineInspection.InspectionLocation.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@Inspector", _lineInspection.Inspector.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@InspectionType", _lineInspection.InspectionType.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectArea", _lineInspection.DefectArea.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectItem", _lineInspection.DefectItem.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectType", _lineInspection.DefectType.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectCondition", _lineInspection.DefectCondition.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", DBUtils.GetAS400Time(CreateDateTime)));
                        cmd.Parameters.Add(new iDB2Parameter("@InspectionDate", DBUtils.GetAS400Date(_lineInspection.InspectionDate)));
                        cmd.Parameters.Add(new iDB2Parameter("@User", _lineInspection.InspectionCreatedBy.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@Offline", _lineInspection.OfflineOperation.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@ReasonForFailure", (_lineInspection.ReasonForFailure.Trim()).Substring(0,1)   ));

                        result = cmd.ExecuteNonQuery();

                        if (result == 0)
                            throw new ApplicationException("Record not added, exception no thrown");
                        // Conditionally insert into QLPF if there is PassFail data.
                        if (!string.IsNullOrWhiteSpace(_lineInspection.PassFail.Trim()))
                        {
                            // Check if record exists
                            sql.Clear();
                            sql.Append("SELECT COUNT(*) FROM ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLPF WHERE QPSR# = @SerialNumber");

                            cmd.CommandText = sql.ToString();
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _lineInspection.SerialNumber.Trim()));

                            int recordCount = Convert.ToInt32(cmd.ExecuteScalar());

                            if (recordCount > 0)
                            {
                                // Record exists, update it
                                sql.Clear();
                                sql.Append("UPDATE ");
                                sql.Append(DBUtils.GetSUPxxx010().Trim());
                                sql.Append(".QLPF SET QPPOF = @PassOrFail, QPDTE = @CreateDate ");
                                sql.Append("WHERE QPSR# = @SerialNumber");

                                cmd.CommandText = sql.ToString();
                                cmd.Parameters.Clear();
                                cmd.Parameters.Add(new iDB2Parameter("@PassOrFail", _lineInspection.PassFail.Trim()));
                                cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));
                                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _lineInspection.SerialNumber.Trim()));

                                result = cmd.ExecuteNonQuery();

                                if (result == 0)
                                    throw new ApplicationException("Record not updated, exception no thrown");
                            }
                            else
                            {
                                // Record does not exist, insert it
                                sql.Clear();
                                sql.Append("INSERT INTO ");
                                sql.Append(DBUtils.GetSUPxxx010().Trim());
                                sql.Append(".QLPF (QPSR#, QPPOF, QPDTE) ");
                                sql.Append("VALUES (@SerialNumber, @PassOrFail, @CreateDate)");

                                cmd.CommandText = sql.ToString();
                                cmd.Parameters.Clear();
                                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _lineInspection.SerialNumber.Trim()));
                                cmd.Parameters.Add(new iDB2Parameter("@PassOrFail", _lineInspection.PassFail.Trim()));
                                cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));

                                result = cmd.ExecuteNonQuery();

                                if (result == 0)
                                    throw new ApplicationException("Record not added, exception no thrown");
                            }
                        }

                        InspectionLogServices inspLog = new InspectionLogServices();
                        inspLog.UpdateLog(_lineInspection.SerialNumber, DBUtils.GetAS400Date(CreateDateTime), DBUtils.GetAS400Time(CreateDateTime), _lineInspection.DefectArea.Trim(), _lineInspection.DefectCondition.Trim(), _lineInspection.DefectType.Trim(), _lineInspection.DefectItem.Trim());

                        return "";

                    }
                }

            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineInspectionServices", "", "Error in AddLineInspection", ex);
                throw new ApplicationException("Add Line Inspection: " + ex.Message, ex);
            }
        }


        public string UpdateLineInspection(LineInspectionModel _model)
        {
            StringBuilder sql = new StringBuilder();
            int result = 0;
            DateTime CreateDateTime = DateTime.Now;

            _model.ResetNullValues();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        // When creating placeholder in SQL, make sure the same name is not used within the scope from another sql.
                        // else add parameter function will fill in the palce for both sql queries. 
                        sql.Append("Select count(*) from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF  ");
                        sql.Append(" where QLSR#=@SerialNumber ");
                        sql.Append("   and QLIDTE=@CreateDate ");
                        sql.Append("   and QLTIME=@CreateTime ");
                        sql.Append("   and QLDT=@origType");
                        sql.Append("   and QLDA=@origArea");
                        sql.Append("   and QLDI=@origItem");
                        sql.Append("   and QLDC=@origCondition");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.InspectionCreateDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.InspectionCreateTime));
                        cmd.Parameters.Add(new iDB2Parameter("@origType", _model.originalDefectType.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@origArea", _model.originalDefectArea.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@origItem", _model.originalDefectItem.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@origCondition", _model.originalDefectCondition.Trim()));

                        string realizedCommandText = GetRealizedCommandText(cmd);
                        Console.WriteLine(realizedCommandText);


                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

                        if (result == 1)
                        {
                            if (_model.OfflineOperation == "" || _model.OfflineOperation == " ")
                                _model.OfflineOperation = "NA";
                            sql = new StringBuilder();
                            sql.Append("Update ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLIF  ");
                            sql.Append("Set ");
                            sql.Append(" QLDATE = @InspectionDate, ");
                            sql.Append(" QLIL = @InspectionLocation, ");
                            sql.Append(" QLIN = @Inspector, ");
                            sql.Append(" QLIT = @InspectionType, ");
                            sql.Append(" QLDA = @Area, ");
                            sql.Append(" QLDI = @Item, ");
                            sql.Append(" QLDT = @Type, ");
                            sql.Append(" QLDC = @Condition,");
                            sql.Append(" QLIO = @Offline ");
                            sql.Append(" where QLSR#=@SerialNumber ");
                            sql.Append("   and QLIDTE=@CreateDate ");
                            sql.Append("   and QLTIME=@CreateTime ");
                            sql.Append("   and QLDT=@origType");
                            sql.Append("   and QLDA=@origArea");
                            sql.Append("   and QLDI=@origItem");
                            sql.Append("   and QLDC=@origCondition");

                            cmd.CommandText = sql.ToString();
                            cmd.Parameters.Add(new iDB2Parameter("@InspectionDate", DBUtils.GetAS400Date(_model.InspectionDate)));
                            cmd.Parameters.Add(new iDB2Parameter("@InspectionLocation", _model.InspectionLocation.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@Inspector", _model.Inspector.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@InspectionType", _model.InspectionType.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@Area", _model.DefectArea.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@Item", _model.DefectItem.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@Type", _model.DefectType.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@Condition", _model.DefectCondition.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@Offline", _model.OfflineOperation.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.InspectionCreateDate));
                            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.InspectionCreateTime));
                            cmd.Parameters.Add(new iDB2Parameter("@origType", _model.originalDefectType.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@origArea", _model.originalDefectArea.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@origItem", _model.originalDefectItem.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@origCondition", _model.originalDefectCondition.Trim()));

                            GetRealizedCommandText(cmd);
                            Console.WriteLine(realizedCommandText);


                            result = cmd.ExecuteNonQuery();
                            if (result == 0)
                                throw new ApplicationException("Update Line Inspection: Record not updated, no exception thrown");
                            else
                            {
                                InspectionLogServices inspLog = new InspectionLogServices();
                                inspLog.UpdateLog(_model.SerialNumber, _model.InspectionCreateDate, _model.InspectionCreateTime, _model.DefectArea, _model.DefectCondition, _model.DefectType, _model.DefectItem);
                                return "";
                            }
                        }
                        else
                        {
                            StringBuilder msg = new StringBuilder();
                            if (result > 1)
                                msg.Append("Multiple records found - ");
                            else
                                msg.Append("Update Line Inspection: Invalid parameters - ");
                            msg.Append(_model.SerialNumber);
                            msg.Append(", ");
                            msg.Append(_model.InspectionCreateDate);
                            msg.Append(", ");
                            msg.Append(_model.InspectionCreateTime);
                            msg.Append(", ");
                            msg.Append(_model.originalDefectArea);
                            msg.Append(", ");
                            msg.Append(_model.originalDefectType);
                            msg.Append(", ");
                            msg.Append(_model.originalDefectCondition);
                            msg.Append(", ");
                            msg.Append(_model.originalDefectItem);
                            throw new ApplicationException(msg.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineInspectionServices", "", "Error in UpdateLineInspection", ex);
                throw new ApplicationException("Update Line Inspection: " + ex.Message, ex);
            }
        }


        public string DeleteLineInspection(LineInspectionModel _model)
        {
            StringBuilder sql = new StringBuilder();
            int result = 0;
            DateTime CreateDateTime = DateTime.Now;

            try
            {
                using (var cn = new iDB2Connection())
                {
                    cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                    cn.Open();

                    using (var cmd = cn.CreateCommand())
                    {
                        // Check if the record exists
                        sql = new StringBuilder();
                        sql.Append("SELECT DISTINCT COUNT(*) FROM ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF ");
                        sql.Append(" WHERE QLSR#=@SerialNumber ");
                        sql.Append(" AND QLIDTE=@CreateDate ");
                        sql.Append(" AND QLTIME=@CreateTime ");
                        sql.Append(" AND QLDT=@DefectType ");
                        sql.Append(" AND QLDC=@DefectCondition ");
                        sql.Append(" AND QLDI=@DefectItem ");
                        sql.Append(" AND QLDA=@DefectArea ");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.InspectionCreateDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.InspectionCreateTime));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectType", _model.DefectType.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectArea", _model.DefectArea.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectItem", _model.DefectItem.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectCondition", _model.DefectCondition.Trim()));

                        result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

                        if (result == 1)
                        {
                            // Check if it is the last entry with QLIL = 'FIN'
                            sql = new StringBuilder();
                            sql.Append("SELECT COUNT(*) FROM ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLIF ");
                            sql.Append(" WHERE QLSR#=@SerialNumber ");
                            sql.Append(" AND QLIL='FIN'");

                            cmd.CommandText = sql.ToString();
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));

                            int countFIN = Convert.ToInt32(cmd.ExecuteScalar());

                            // Delete from QLIF
                            sql = new StringBuilder();
                            sql.Append("DELETE FROM ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLIF ");
                            sql.Append(" WHERE QLSR#=@SerialNumber ");
                            sql.Append(" AND QLIDTE=@CreateDate ");
                            sql.Append(" AND QLTIME=@CreateTime ");
                            sql.Append(" AND QLDT=@DefectType ");
                            sql.Append(" AND QLDC=@DefectCondition ");
                            sql.Append(" AND QLDI=@DefectItem ");
                            sql.Append(" AND QLDA=@DefectArea ");

                            cmd.CommandText = sql.ToString();
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.InspectionCreateDate));
                            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.InspectionCreateTime));
                            cmd.Parameters.Add(new iDB2Parameter("@DefectType", _model.DefectType.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@DefectArea", _model.DefectArea.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@DefectItem", _model.DefectItem.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@DefectCondition", _model.DefectCondition));

                            result = cmd.ExecuteNonQuery();

                            if (result == 0)
                                throw new ApplicationException("Delete Line Inspection: Record not deleted, no exception thrown");

                            if (countFIN == 1)
                            {
                                // If it was the last entry, delete from QLPF
                                sql = new StringBuilder();
                                sql.Append("DELETE FROM ");
                                sql.Append(DBUtils.GetSUPxxx010().Trim());
                                sql.Append(".QLPF ");
                                sql.Append(" WHERE QPSR#=@SerialNumber");

                                cmd.CommandText = sql.ToString();
                                cmd.Parameters.Clear();
                                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));

                                result = cmd.ExecuteNonQuery();

                                if (result == 0)
                                    throw new ApplicationException("Delete Line Inspection: Record not deleted from QLPF, no exception thrown");
                            }

                            InspectionLogServices inspLog = new InspectionLogServices();
                            inspLog.UpdateLogWithDelete(_model.SerialNumber, _model.InspectionCreateDate, _model.InspectionCreateTime);
                            return "";
                        }
                        else
                        {
                            StringBuilder msg = new StringBuilder();
                            if (result > 1)
                                msg.Append("Multiple records found - ");
                            else
                                msg.Append("Delete Line Inspection: Invalid parameters - ");
                            msg.Append(_model.SerialNumber);
                            msg.Append(", ");
                            msg.Append(_model.InspectionCreateDate);
                            msg.Append(", ");
                            msg.Append(_model.InspectionCreateTime);
                            msg.Append(", ");
                            msg.Append(_model.DefectArea);
                            msg.Append(", ");
                            msg.Append(_model.DefectType);
                            msg.Append(", ");
                            msg.Append(_model.DefectCondition);
                            msg.Append(", ");
                            msg.Append(_model.DefectItem);
                            throw new ApplicationException(msg.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineInspectionServices", "", "Error in DeleteLineInspection", ex);
                throw new ApplicationException("Delete Line Inspection: " + ex.Message, ex);
            }
        }

        public List<LineInspectionModel> GetLineInspectionForIndex(string _serialNumber)
        {
            StringBuilder sql = new StringBuilder();
            LineInspectionModel model = null;
            List<LineInspectionModel> list = new List<LineInspectionModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT QLDATE, QLIL, QLIN, QLIT, QLDA, QLDI, QLDT, QLDC, QLIO,  ");
                        sql.Append("       QLSR#, QLIDTE, QLTIME, ");
                        sql.Append(" (SELECT DADESC FROM ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDAF WHERE DAID# = QLDA ORDER BY DASTAT ASC FETCH FIRST 1 ROW ONLY),");
                        sql.Append(" (SELECT DIDESC FROM ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDIF WHERE DIID# = QLDI ORDER BY DISTAT ASC FETCH FIRST 1 ROW ONLY),");
                        sql.Append(" (SELECT DTDESC FROM ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDTF WHERE DTID# = QLDT ORDER BY DTSTAT ASC FETCH FIRST 1 ROW ONLY),");
                        sql.Append(" (SELECT DCDESC FROM ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDCF WHERE DCID# = QLDC ORDER BY DCSTAT ASC FETCH FIRST 1 ROW ONLY),");
                        sql.Append("       SLDESC, IINAME, ITDESC, LODESC, QPPOF, QLRF "); //updated by Khalid#2
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF ");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QSLF ");
                        sql.Append(" on QLIL = SLID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QIIF ");
                        sql.Append(" on QLIN = IIID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QITF ");
                        sql.Append(" on QLIT = ITID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLPF ");
                        sql.Append(" on QLSR# = QPSR#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLOF ");
                        sql.Append(" on QLIO = LOID#");

                        sql.Append(" where QLSR#=@SerialNumber");
                        sql.Append(" order by QLIDTE, QLTIME"); //replaced QLDATE to QLIDTE

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    model = new LineInspectionModel();
                                    //model.InspectionDate = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QLDATE"]));
                                    model.InspectionDate = DBUtils.GetSafeDateTime(rdr["QLDATE"]);
                                    model.InspectionLocation = DBUtils.GetSafeString(rdr["SLDESC"]).Trim();
                                    model.Inspector = DBUtils.GetSafeString(rdr["IINAME"]).Trim();
                                    model.InspectionType = DBUtils.GetSafeString(rdr["ITDESC"]).Trim();
                                    model.DefectArea = DBUtils.GetSafeString(rdr["QLDA"]).Trim();
                                    model.AreaDesc = DBUtils.GetSafeString(rdr["DADESC"]).Trim();
                                    model.DefectItem = DBUtils.GetSafeString(rdr["QLDI"]).Trim();
                                    model.ItemDesc = DBUtils.GetSafeString(rdr["DIDESC"]).Trim();
                                    model.DefectType = DBUtils.GetSafeString(rdr["QLDT"]).Trim();
                                    model.TypeDesc = DBUtils.GetSafeString(rdr["DTDESC"]).Trim();
                                    model.DefectCondition = DBUtils.GetSafeString(rdr["QLDC"]).Trim();
                                    model.ConditionDesc = DBUtils.GetSafeString(rdr["DCDESC"]).Trim();
                                    model.SerialNumber = DBUtils.GetSafeString(rdr["QLSR#"]).Trim();
                                    model.InspectionCreateDate = DBUtils.GetSafeString(rdr["QLIDTE"]);
                                    model.InspectionCreateTime = DBUtils.GetSafeString(rdr["QLTIME"]);
                                    model.OfflineOperation = DBUtils.GetSafeString(rdr["QLIO"]).Trim();
                                    model.OfflineDescription = DBUtils.GetSafeString(rdr["LODESC"]).Trim();
                                    model.PassFail = DBUtils.GetSafeString(rdr["QPPOF"]).Trim();
                                    model.ReasonForFailure = DBUtils.GetSafeString(rdr["QLRF"]).Trim();

                                    list.Add(model);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineInspectionServices", "", "Error in GetLineInspectionForIndex", ex);
                throw new ApplicationException("Line Inspection For Index: " + ex.Message, ex);
            }
            return list;
        }

        public LineInspectionModel GetSingleLineInspection(string _serialNumber, string _createDate, string _createTime, string _defectArea, string _defectType, string _defectCondition, string _defectItem)
        {
            StringBuilder sql = new StringBuilder();
            LineInspectionModel model = new LineInspectionModel();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select * ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF");
                        sql.Append(" where QLSR#=@SerialNumber ");
                        sql.Append("   and QLIDTE=@CreateDate ");
                        sql.Append("   and QLTIME=@CreateTime ");
                        sql.Append("   and QLDT=@DefectType ");
                        sql.Append("   and QLDC=@DefectCondition ");
                        sql.Append("   and QLDI=@DefectItem ");
                        sql.Append("   and QLDA=@DefectArea ");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectType", _defectType));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectCondition", _defectCondition));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectItem", _defectItem));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectArea", _defectArea));


                        //cn.ConnectionString = "Datasource=192.168.30.8; UserId=PRINTER; Password=PRINTER";
                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        // get Serial Number, Model, Order Number, and Warehouse
                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    model = new LineInspectionModel();
                                    model.SerialNumber = DBUtils.GetSafeString(rdr["QLSR#"]).Trim();
                                    model.InspectionLocation = DBUtils.GetSafeString(rdr["QLIL"]).Trim();
                                    model.Inspector = DBUtils.GetSafeString(rdr["QLIN"]).Trim();
                                    model.InspectionType = DBUtils.GetSafeString(rdr["QLIT"]).Trim();
                                    model.DefectArea = DBUtils.GetSafeString(rdr["QLDA"]).Trim();
                                    model.DefectItem = DBUtils.GetSafeString(rdr["QLDI"]).Trim();
                                    model.DefectType = DBUtils.GetSafeString(rdr["QLDT"]).Trim();
                                    model.DefectCondition = DBUtils.GetSafeString(rdr["QLDC"]).Trim();
                                    model.InspectionCreateDate = DBUtils.GetSafeString(rdr["QLIDTE"]);
                                    model.InspectionCreateTime = DBUtils.GetSafeString(rdr["QLTIME"]);
                                    model.InspectionDate = DBUtils.GetSafeDateTime(rdr["QLDATE"]);
                                    model.InspectionCreatedBy = DBUtils.GetSafeString(rdr["QLIUSER"]).Trim();
                                    model.RepairAction = DBUtils.GetSafeString(rdr["QLRA"]).Trim();
                                    model.RepairTimeMinutes = DBUtils.GetSafeInteger(rdr["QLRM"]);
                                    model.RepairCreateTime = DBUtils.GetSafeString(rdr["QIRTIME"]);
                                    model.RepairCreateDate = DBUtils.GetSafeString(rdr["QIRDATE"]);
                                    model.RepairCreatedBy = DBUtils.GetSafeString(rdr["QIRUSER"]).Trim();
                                    model.OfflineOperation = DBUtils.GetSafeString(rdr["QLIO"]).Trim();
                                    model.originalDefectArea = DBUtils.GetSafeString(rdr["QLDA"]).Trim();
                                    model.originalDefectType = DBUtils.GetSafeString(rdr["QLDT"]).Trim();
                                    model.originalDefectCondition = DBUtils.GetSafeString(rdr["QLDC"]).Trim();
                                    model.originalDefectItem = DBUtils.GetSafeString(rdr["QLDI"]).Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineInspectionServices", "", "Error in GetSingleLineExperience", ex);
                throw new ApplicationException("Get Single Line Experience: " + ex.Message, ex);
            }
            return model;
        }

        public LineInspectionModel GetSingleLineInspectionForDelete(string _serialNumber, string _createDate, string _createTime, string _defectArea, string _defectType, string _defectCondition, string _defectItem)
        {
            StringBuilder sql = new StringBuilder();
            LineInspectionModel model = null;

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT QLDATE, QLIL, QLIN, QLIT, QLDA, QLDI, QLDT, QLDC, QLIO,  ");
                        sql.Append("       QLSR#, QLIDTE, QLTIME, ");
                        sql.Append("       SLDESC, IINAME, ITDESC, DADESC, DIDESC, DTDESC, DCDESC, LODESC ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF ");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QSLF ");
                        sql.Append(" on QLIL = SLID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QIIF ");
                        sql.Append(" on QLIN = IIID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QITF ");
                        sql.Append(" on QLIT = ITID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDAF ");
                        sql.Append(" on QLDA = DAID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDIF ");
                        sql.Append(" on QLDI = DIID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDTF ");
                        sql.Append(" on QLDT = DTID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDCF ");
                        sql.Append(" on QLDC = DCID#");

                        sql.Append(" left outer join ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLOF ");
                        sql.Append(" on QLIO = LOID#");

                        sql.Append(" where QLSR#=@SerialNumber");
                        sql.Append("   and QLIDTE=@CreateDate ");
                        sql.Append("   and QLTIME=@CreateTime ");
                        sql.Append("   and QLDT=@DefectType ");
                        sql.Append("   and QLDC=@DefectCondition ");
                        sql.Append("   and QLDI=@DefectItem ");
                        sql.Append("   and QLDA=@DefectArea ");

                        sql.Append(" order by QLDATE");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectType", _defectType.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectCondition", _defectCondition.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectItem", _defectItem.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectArea", _defectArea.Trim()));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    model = new LineInspectionModel();
                                    model.InspectionDate = DBUtils.GetSafeDateTime(rdr["QLDATE"]);
                                    model.InspectionLocation = DBUtils.GetSafeString(rdr["SLDESC"]).Trim();
                                    model.Inspector = DBUtils.GetSafeString(rdr["IINAME"]).Trim();
                                    model.InspectionType = DBUtils.GetSafeString(rdr["ITDESC"]).Trim();
                                    model.DefectArea = DBUtils.GetSafeString(rdr["QLDA"]).Trim();
                                    model.AreaDesc = DBUtils.GetSafeString(rdr["DADESC"]).Trim();
                                    model.DefectItem = DBUtils.GetSafeString(rdr["QLDI"]).Trim();
                                    model.ItemDesc = DBUtils.GetSafeString(rdr["DIDESC"]).Trim();
                                    model.DefectType = DBUtils.GetSafeString(rdr["QLDT"]).Trim();
                                    model.TypeDesc = DBUtils.GetSafeString(rdr["DTDESC"]).Trim();
                                    model.DefectCondition = DBUtils.GetSafeString(rdr["QLDC"]).Trim();
                                    model.ConditionDesc = DBUtils.GetSafeString(rdr["DCDESC"]).Trim();
                                    model.SerialNumber = DBUtils.GetSafeString(rdr["QLSR#"]).Trim();
                                    model.InspectionCreateDate = DBUtils.GetSafeString(rdr["QLIDTE"]);
                                    model.InspectionCreateTime = DBUtils.GetSafeString(rdr["QLTIME"]);
                                    model.OfflineOperation = DBUtils.GetSafeString(rdr["QLIO"]).Trim();
                                    model.OfflineDescription = DBUtils.GetSafeString(rdr["LODESC"]).Trim();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineInspectionServices", "", "Error in GetSingleLineInspectionForDelete", ex);
                throw new ApplicationException("Get Single Line Inspection for Delete: " + ex.Message, ex);
            }
            return model;
        }

        public List<LineInspectionModel> GetInitialLineInspections(string _serialNumber, string _inspectionLocation, string _createDate, string _createTime)
        {
            StringBuilder sql = new StringBuilder();
            LineInspectionModel mdl;
            List<LineInspectionModel> list = new List<LineInspectionModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select QLIL, QLIT, QLDA, QLDI, QLDT, QLDC ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF ");
                        sql.Append(" where QLSR#=@SerialNumber ");
                        sql.Append(" and QLIL=@InspectionLocation ");
                        sql.Append(" and QLIT=@InspectionType ");
                        if ((_createDate != "") && (_createTime != ""))
                        {
                            sql.Append(" and (QLIDTE<>@LineInspectionCreateDate ");
                            sql.Append(" or QLTIME<>@LineInspectionCreateTime) ");
                        }

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@InspectionLocation", _inspectionLocation.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@InspectionType", "INIT"));
                        if ((_createDate != "") && (_createTime != ""))
                        {
                            cmd.Parameters.Add(new iDB2Parameter("@LineInspectionCreateDate", _createDate));
                            cmd.Parameters.Add(new iDB2Parameter("@LineInspectionCreateTime", _createTime));
                        }

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    mdl = new LineInspectionModel();

                                    mdl.InspectionLocation = DBUtils.GetSafeString(rdr["QLIL"]).Trim();
                                    mdl.InspectionType = DBUtils.GetSafeString(rdr["QLIT"]).Trim();
                                    mdl.DefectArea = DBUtils.GetSafeString(rdr["QLDA"]).Trim();
                                    mdl.DefectItem = DBUtils.GetSafeString(rdr["QLDI"]).Trim();
                                    mdl.DefectType = DBUtils.GetSafeString(rdr["QLDT"]).Trim();
                                    mdl.DefectCondition = DBUtils.GetSafeString(rdr["QLDC"]).Trim();
                                    list.Add(mdl);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("LineInspectionServices", "", "Error in GetInitialLineInspections", ex);
                throw new ApplicationException("Get Initial Line Inspections: " + ex.Message, ex);
            }
            return list;
        }
        
        public DateTime? GetLastEntryDateFromQLIF(string _serialNumber)
        {
            DateTime? lastEntryDate = null;
            string connectionString = DBUtils.GetAS400ConnectionString();

            using (var cn = new iDB2Connection())
            {
                cn.ConnectionString = connectionString;
                cn.Open();

                using (var cmd = cn.CreateCommand())
                {
                    StringBuilder sql = new StringBuilder();
                    sql.Append("SELECT MAX(QLDATE) FROM ");
                    sql.Append(DBUtils.GetSUPxxx010().Trim());
                    sql.Append(".QLIF ");
                    sql.Append("WHERE QLSR# = @SerialNumber");

                    cmd.CommandText = sql.ToString();
                    cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                    var result = cmd.ExecuteScalar();

                    if (result != DBNull.Value && result != null)
                    {
                        string dateStr = result.ToString();
                        // Convert the result from decimal (yyyymmdd) to DateTime
                        lastEntryDate = DBUtils.GetSafeDateTime(result);
                        /*if (DateTime.TryParseExact(dateStr, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out DateTime parsedDate))
                        {
                            lastEntryDate = parsedDate;
                        }*/
                    }
                }
            }

            return lastEntryDate;
        }
    }
}