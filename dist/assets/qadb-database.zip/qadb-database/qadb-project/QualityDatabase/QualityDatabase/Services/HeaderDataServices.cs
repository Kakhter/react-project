﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Models;
using System.Text;

namespace QualityDatabase.Services
{
  public class HeaderDataServices
  {
    public HeaderData GetHeaderData(string _serialNumber)
    {
      HeaderData hd = new HeaderData();
      object obj;
      string SerialNumber = "";
      string Model = "";
      decimal OrderNumber = 0;
      string Warehouse = "";
      string SoldToCustomerNumber = "";
      decimal WorkOrderNumber = 0;
      string Month = "";
      string Year = "";
      string Resolved = "";
      StringBuilder sql = new StringBuilder();

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select S1SR#, S1PN, S1ORD#, S1WH ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".S1P ");
          sql.Append(" where S1SR#=@SerialNumber");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          // get Serial Number, Model, Order Number, and Warehouse
          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                SerialNumber = DBUtils.GetSafeString(rdr["S1SR#"]);
                Model = DBUtils.GetSafeString(rdr["S1PN"]);
                OrderNumber = DBUtils.GetSafeDecimal(rdr["S1ORD#"]);
                Warehouse = DBUtils.GetSafeString(rdr["S1WH"]);
              }
            }

            hd.SerialNumber = SerialNumber;
            hd.Model = Model;
            hd.OrderNumber = OrderNumber.ToString();
            hd.Warehouse = Warehouse;
          }

          // get Sold To Customer Number
          sql = new StringBuilder();
          sql.Append("select OHBTKY ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".OHP ");
          sql.Append(" where OHORD# = @OrderNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@OrderNumber", OrderNumber));
          obj = cmd.ExecuteScalar();
          SoldToCustomerNumber = DBUtils.GetSafeString(obj);

          // get Customer Name
          sql = new StringBuilder();
          sql.Append("select CMNAME ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".CM1P ");
          sql.Append(" where C1STKY = @CustomerNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@CustomerNumber", SoldToCustomerNumber));
          obj = cmd.ExecuteScalar();
          hd.CustomerName = DBUtils.GetSafeString(obj);

          // Get Line
          sql = new StringBuilder();
          sql.Append("select S2FF1 ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".S1F ");
          sql.Append(" where S2SR# = @SerialNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", SerialNumber));
          obj = cmd.ExecuteScalar();
          hd.Line = DBUtils.GetSafeString(obj);

          // Get 200 date
          sql = new StringBuilder();
          sql.Append("select ETDATM, ETDATY ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".ET01 ");
          sql.Append(" where ELMO = @WorkOrderNumber and ELOPSQ = '200.00'");

          Month = "";
          Year = "";
          WorkOrderNumber = OrderNumber + (decimal).001;
          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("WorkOrderNumber", WorkOrderNumber));
          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                Month = DBUtils.GetSafeString(rdr["ETDATM"]);
                Year = DBUtils.GetSafeString(rdr["ETDATY"]);
              }
            }
            hd.Date200 = ConvertDate(Month, Year);
          }

          // Get 900 date
          sql = new StringBuilder();
          sql.Append("select ETDATM, ETDATY ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".ET01 ");
          sql.Append(" where ELMO = @WorkOrderNumber and ELOPSQ = '900.00'");

          Month = "";
          Year = "";
          WorkOrderNumber = OrderNumber + (decimal).001;
          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("WorkOrderNumber", WorkOrderNumber));
          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                Month = DBUtils.GetSafeString(rdr["ETDATM"]);
                Year = DBUtils.GetSafeString(rdr["ETDATY"]);
              }
            }
            hd.Date900 = ConvertDate(Month, Year);
          }

          // Get On Hold
          HoldsResolvedServices hrDB = new HoldsResolvedServices();
          if (hrDB.AreAllHoldsResolved(_serialNumber) == true)
            hd.OnHold = "";
          else
            hd.OnHold = "On Hold";
        }
      }
      return hd;
    }



    private string ConvertDate(string _month, string _year)
    {
      if ((_month.Trim() == "") && (_year.Trim() == ""))
      {
        return "";
      }

      string work = "";
      if (_month.Length == 3)
        work = _month.Substring(0, 1) + "/" + _month.Substring(1, 2);
      else
        work = _month.Substring(0, 2) + "/" + _month.Substring(2, 2);


      if (_year.Length == 1)
        _year = "0" + _year;

      work = work + "/20" + _year;

      return work;
    }
  }
}