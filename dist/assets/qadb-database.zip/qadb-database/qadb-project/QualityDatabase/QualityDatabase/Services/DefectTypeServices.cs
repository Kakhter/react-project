﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
    public class DefectTypeServices
    {
        public List<DefectTypeModel> WaterTestTypeList
        {
            get { return GetWaterTestDefectTypes(); }
        }
        private List<DefectTypeModel> GetWaterTestDefectTypes()
        {
            StringBuilder sql = new StringBuilder();
            DefectTypeModel type = null;
            List<DefectTypeModel> list = new List<DefectTypeModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT DTID#, DTDESC ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDTF");
                        sql.Append(" where DTSTAT=@Status");
                        sql.Append("   and DTWAT=@Water");
                        sql.Append(" order by DTID#");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
                        cmd.Parameters.Add(new iDB2Parameter("@Water", "Y"));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    type = new DefectTypeModel();
                                    type.Code = DBUtils.GetSafeString(rdr["DTID#"]).Trim();
                                    type.Description = DBUtils.GetSafeString(rdr["DTDESC"]).Trim();
                                    list.Add(type);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("DefectTypeServices", "", "Error in GetWaterTestDefectType", ex);
                throw new ApplicationException("Get Water Test Defect Type: " + ex.Message, ex);
            }
            return list;
        }


        public List<DefectTypeModel> LineInspectionTypeList
        {
            get { return GetLineInspectionDefectTypes(); }
        }
        private List<DefectTypeModel> GetLineInspectionDefectTypes()
        {
            StringBuilder sql = new StringBuilder();
            DefectTypeModel type = null;
            List<DefectTypeModel> list = new List<DefectTypeModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT DTID#, DTDESC");
                        //sql.Append(" , DTAID#  ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDTF");
                        sql.Append(" where DTSTAT=@Status");
                        sql.Append("   and DTLINE=@Line");
                        sql.Append(" order by DTID#");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
                        cmd.Parameters.Add(new iDB2Parameter("@Line", "Y"));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    type = new DefectTypeModel();
                                    type.Code = DBUtils.GetSafeString(rdr["DTID#"]).Trim();
                                    type.Description = DBUtils.GetSafeString(rdr["DTDESC"]).Trim();
                                    //type.DTAID = DBUtils.GetSafeString(rdr["DTAID#"]).Trim();
                                    list.Add(type);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("DefectTypeServices", "", "Error in GetLineInspectionDefectType", ex);
                throw new ApplicationException("Get Line Inspection Defect Type: " + ex.Message, ex);
            }
            return list;
        }
    }
}