﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class RepairActionServices
  {
    public List<RepairActionModel> RepairActionList
    {
      get { return GetRepairActions(); }
    }
    private List<RepairActionModel> GetRepairActions()
    {
      StringBuilder sql = new StringBuilder();
      RepairActionModel model = null;
      List<RepairActionModel> list = new List<RepairActionModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select RAID#, RADESC ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QRAF");
            sql.Append(" where RASTAT=@Status");
            sql.Append("   and RAWATER=@Water");
            sql.Append(" order by RAID#");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
            cmd.Parameters.Add(new iDB2Parameter("@Water", "Y"));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new RepairActionModel();
                  model.Code = DBUtils.GetSafeString(rdr["RAID#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["RADESC"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("RepairActionServices", "", "Error in GetRepairActions", ex);
        throw new ApplicationException("Get Repair Actions: " + ex.Message, ex);
      }
      return list;
    }
  }
}