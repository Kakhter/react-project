﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class HoldCategoryServices
  {
    public List<HoldCategoryModel> HoldCategoryList
    {
      get { return GetHoldCatagories(); }
    }

    private List<HoldCategoryModel> GetHoldCatagories()
    {
      HoldCategoryModel model = null;
      List<HoldCategoryModel> list = new List<HoldCategoryModel>();

      StringBuilder sql = new StringBuilder();
  
      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select HCID#, HCDESC ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHCF");
            sql.Append(" order by HCID#");

            cmd.CommandText = sql.ToString();

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new HoldCategoryModel();
                  model.Code = DBUtils.GetSafeString(rdr["HCID#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["HCDESC"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("HoldCategoryServices", "", "Error in GetHoldCategories", ex);
        throw new ApplicationException("Get Hold Categories: " + ex.Message, ex);
      }
      return list;
    }
  }
}