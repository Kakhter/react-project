﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class FuelServices
  {
    public List<FuelModel> GetFuelForIndex(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      FuelModel model;
      FuelTypeServices fuelType = new FuelTypeServices();
      List<FuelModel> list = new List<FuelModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QSFUEL, QSGAL, QSFPRC, QSSR# ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".STF ");
            sql.Append(" where QSSR#=@SerialNumber");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new FuelModel();
                  model.FuelType = fuelType.GetFuelTypeDescription(DBUtils.GetSafeString(rdr["QSFUEL"])).Trim();
                  model.GallonsOfFuel = DBUtils.GetSafeDouble(rdr["QSGAL"]);
                  model.PricePerGallon = DBUtils.GetSafeDouble(rdr["QSFPRC"]);
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QSSR#"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("FuelServices", "", "Error in GetFuelForIndex", ex);
        throw new ApplicationException("Get Fuel for Index: " + ex.Message, ex);
      }

      if (list.Count == 0)
      {
        model = new FuelModel();
        model.SerialNumber = _serialNumber;
        list.Add(model);
      }
      return list;
    }

    public FuelModel GetFuel(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      FuelModel model = new FuelModel();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select * ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".STF");
            sql.Append(" where QSSR#=@SerialNumber ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new FuelModel();
                  model.FuelType = DBUtils.GetSafeString(rdr["QSFUEL"]).Trim();
                  model.GallonsOfFuel = DBUtils.GetSafeDouble(rdr["QSGAL"]);
                  model.PricePerGallon = DBUtils.GetSafeDouble(rdr["QSFPRC"]);
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QSSR#"]).Trim();
                  model.FuelCreateDate = DBUtils.GetSafeString(rdr["QSFDATE"]);
                  model.FuelCreateTime = DBUtils.GetSafeString(rdr["QSFTIME"]);
                  model.FuelCreatedBy = DBUtils.GetSafeString(rdr["QSFUSER"]).Trim();
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("FuelServices", "", "Error in GetFuel", ex);
        throw new ApplicationException("Get Fuel: " + ex.Message, ex);
      }
      return model;
    }

    public string UpdateFuel(FuelModel _model)
    {
      string ErrorString = "";
      StringBuilder sql;
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      FuelModel model = this.GetFuel(_model.SerialNumber);

      _model.ReplaceNulls();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            if (model.SerialNumber.Trim() == "")
            {
              sql = new StringBuilder();
              sql.Append("insert into ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".STF (");
              sql.Append("QSFUEL, QSGAL, QSFPRC, QSSR#, ");
              sql.Append("QSFTIME, QSFDATE, QSFUSER ");
              sql.Append(") values (");
              sql.Append("@FuelType, @GallonsOfFuel, @PricePerGallon, ");
              sql.Append("@SerialNumber, @CreateTime, @CreateDate, @CreatedBy ");
              sql.Append(")");
              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@FuelType", _model.FuelType));
              cmd.Parameters.Add(new iDB2Parameter("@GallonsOfFuel", _model.GallonsOfFuel));
              cmd.Parameters.Add(new iDB2Parameter("@PricePerGallon", _model.PricePerGallon));
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@CreateTime", DBUtils.GetAS400Time(CreateDateTime)));
              cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));
              cmd.Parameters.Add(new iDB2Parameter("@CreatedBy", _model.FuelCreatedBy.Trim()));
            }
            else
            {
              if (model.FuelCreatedBy.Trim() == "")
              {
                sql = new StringBuilder();
                sql.Append("Update ");
                sql.Append(DBUtils.GetSUPxxx010().Trim());
                sql.Append(".STF ");
                sql.Append("Set ");
                sql.Append(" QSFUEL = @FuelType, ");
                sql.Append(" QSGAL = @GallonsOfFuel, ");
                sql.Append(" QSFPRC = @PricePerGallon, ");
                sql.Append(" QSFDATE = @CreateDate, ");
                sql.Append(" QSFTIME = @CreateTime, ");
                sql.Append(" QSFUSER = @CreatedBy ");
                sql.Append(" where QSSR# = @SerialNumber ");

                cmd.CommandText = sql.ToString();
                cmd.Parameters.Add(new iDB2Parameter("@FuelType", _model.FuelType));
                cmd.Parameters.Add(new iDB2Parameter("@GallonsOfFuel", _model.GallonsOfFuel));
                cmd.Parameters.Add(new iDB2Parameter("@PricePerGallon", _model.PricePerGallon));
                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
                cmd.Parameters.Add(new iDB2Parameter("@CreateTime", DBUtils.GetAS400Time(CreateDateTime)));
                cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));
                cmd.Parameters.Add(new iDB2Parameter("@CreatedBy", _model.FuelCreatedBy.Trim()));
              }
              else
              {
                sql = new StringBuilder();
                sql.Append("Update ");
                sql.Append(DBUtils.GetSUPxxx010().Trim());
                sql.Append(".STF ");
                sql.Append("Set ");
                sql.Append(" QSFUEL = @FuelType, ");
                sql.Append(" QSGAL = @GallonsOfFuel, ");
                sql.Append(" QSFPRC = @PricePerGallon ");
                sql.Append(" where QSSR# = @SerialNumber ");

                cmd.CommandText = sql.ToString();
                cmd.Parameters.Add(new iDB2Parameter("@FuelType", _model.FuelType));
                cmd.Parameters.Add(new iDB2Parameter("@GallonsOfFuel", _model.GallonsOfFuel));
                cmd.Parameters.Add(new iDB2Parameter("@PricePerGallon", _model.PricePerGallon));
                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
              }
            }
            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Update Fuel: Record not updated, no exception thrown");
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("FuelServices", "", "Error in UpdateFuel", ex);
        throw new ApplicationException("Update Fuel: " + ex.Message, ex);
      }
      return ErrorString;
    }
  }
}