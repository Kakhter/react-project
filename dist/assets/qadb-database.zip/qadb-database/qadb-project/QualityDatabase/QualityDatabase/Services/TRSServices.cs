﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace QualityDatabase.Services
{
  public class TRSServices
  {
    public List<TRSModel> GetTRSRecords(string _order)
    {
      StringBuilder sql = new StringBuilder();
      List<TRSModel> list = new List<TRSModel>();
      TRSModel model = null;

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select M2ON, M2SEQ, ML2LP, M3PN, PMDESC  ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".M2P ");

            sql.Append(" left outer join  ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".M3P ");
            sql.Append(" on M2ON = M3ON and M2SEQ = M3SEQ ");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".PMP ");
            sql.Append(" on M3PN = PMPART ");

            sql.Append(" where M2ON=@M2ON ");
            //sql.Append(" and M2SEQ > 200 and M2SEQ <= 900");
            sql.Append(" order by M2SEQ ");


            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@M2ON", _order.Trim() + ".001"));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();


            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new TRSModel();
                  model.S1ORD = _order.Trim() + ".001";
                  model.M2ON = rdr["M2ON"].ToString();
                  model.M2SEQ = rdr["M2SEQ"].ToString();
                  model.ML2LP = DBUtils.FormatShortDateFromAS400ForDisplay(rdr["ML2LP"].ToString());
                  model.M3PN = rdr["M3PN"].ToString();
                  model.PMDESC = rdr["PMDESC"].ToString();
                  list.Add(model);
                }
              }
            }

            //list = GetCurrentRows(list);
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TRSServices", "", "Error in GetTRSRecords", ex);
        throw new ApplicationException("Get TRS Records: " + ex.Message, ex);
      }
      return list;
    }

    private List<TRSModel> GetCurrentRows(List<TRSModel> _orig)
    {
      List<TRSModel> list = new List<TRSModel>();
      TRSModel prev = new TRSModel();
      TRSModel cur = new TRSModel();
      TRSModel next = new TRSModel();
      bool curFound = false;

      foreach (TRSModel work in _orig)
      {
        if (curFound == true)
        {
          next = work;
          break;
        }
        else
        {
          if (work.ML2LP.Trim() == "")
          {
            curFound = true;
            prev = cur;
            cur = work;
          }
          else
          {
            prev = cur;
            cur = work;
          }
        }
      }

      if (prev.M2ON.Trim() != "")
        list.Add(prev);

      if (cur.M2ON.Trim() != "")
        list.Add(cur);

      if (next.M2ON.Trim() != "")
        list.Add(next);

      return list;
    }
  }
}