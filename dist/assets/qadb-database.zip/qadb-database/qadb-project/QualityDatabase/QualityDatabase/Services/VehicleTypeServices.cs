﻿using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Services
{
  public class VehicleTypeServices
  {
    public List<VehicleTypeModel> VehicleTypeList
    {
      get { return GetVehicleTypes(); }
    }

    private List<VehicleTypeModel> GetVehicleTypes()
    {
      List<VehicleTypeModel> list = new List<VehicleTypeModel>();
      VehicleTypeModel model;

      model = new VehicleTypeModel();
      model.Code = "BUS";
      model.Description = "Bus";
      list.Add(model);

      model = new VehicleTypeModel();
      model.Code = "TRUCK";
      model.Description = "Truck";
      list.Add(model);

      model = new VehicleTypeModel();
      model.Code = "TROLLEY";
      model.Description = "Trolley";
      list.Add(model);

      return list;
    }
  }
}