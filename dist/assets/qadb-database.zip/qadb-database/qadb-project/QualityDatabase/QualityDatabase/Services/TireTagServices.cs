﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;


namespace QualityDatabase.Services
{
  public class TireTagServices
  {
    public List<TireTagModel> GetTireTagsForIndex(string _serialNumber)
    {
      List<TireTagModel> list = new List<TireTagModel>();
      StringBuilder sql = new StringBuilder();
      TireTagModel model;
      FuelTypeServices fuelType = new FuelTypeServices();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QSFUEL, QSTANK, QSFSC, QSRSC, QSSR# ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".STF ");
            sql.Append(" where QSSR#=@SerialNumber");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new TireTagModel();
                  model.FuelType = fuelType.GetFuelTypeDescription(DBUtils.GetSafeString(rdr["QSFUEL"]));
                  model.TankSize = DBUtils.GetSafeDouble(rdr["QSTANK"]);
                  model.FrontSeatCapacity = DBUtils.GetSafeDouble(rdr["QSFSC"]);
                  model.RearSeatCapacity = DBUtils.GetSafeDouble(rdr["QSRSC"]);
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QSSR#"]);
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TireTagServices", "", "Error in GetTireTagsForIndex", ex);
        throw new ApplicationException("Get Tire Tags for Index: " + ex.Message, ex);
      }

      if (list.Count == 0)
      {
        model = new TireTagModel();
        model.SerialNumber = _serialNumber;
        list.Add(model);
      }
      return list;
    }

    public TireTagModel GetTireTag(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      TireTagModel model = new TireTagModel();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select * ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".STF");
            sql.Append(" where QSSR#=@SerialNumber ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new TireTagModel();
                  model.FuelType = DBUtils.GetSafeString(rdr["QSFUEL"]);
                  model.TankSize = DBUtils.GetSafeDouble(rdr["QSTANK"]);
                  model.FrontSeatCapacity = DBUtils.GetSafeDouble(rdr["QSFSC"]);
                  model.RearSeatCapacity = DBUtils.GetSafeDouble(rdr["QSRSC"]);
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QSSR#"]);
                  model.TireCreateDate = DBUtils.GetSafeString(rdr["QSTDATE"]);
                  model.TireCreateTime = DBUtils.GetSafeString(rdr["QSTTIME"]);
                  model.TireCreatedBy = DBUtils.GetSafeString(rdr["QSTUSER"]);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TireTagServices", "", "Error in GetTireTag", ex);
        throw new ApplicationException("Get Tire Tag: " + ex.Message, ex);
      }
      return model;
    }

    public string UpdateTireTag(TireTagModel _model)
    {
      string ErrorString = "";
      StringBuilder sql;
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      TireTagModel model = this.GetTireTag(_model.SerialNumber);

      _model.ReplaceNulls();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            if (model.SerialNumber.Trim() == "")
            {
              sql = new StringBuilder();
              sql.Append("insert into ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".STF (");
              sql.Append("QSFUEL, QSTANK, QSFSC, QSRSC, QSSR#, ");
              sql.Append("QSTTIME, QSTDATE, QSTUSER ");
              sql.Append(") values (");
              sql.Append("@FuelType, @TankSize, @FrontSeatCapacity, @RearSeatCapacity, ");
              sql.Append("@SerialNumber, @CreateTime, @CreateDate, @CreatedBy ");
              sql.Append(")");
              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@FuelType", _model.FuelType));
              cmd.Parameters.Add(new iDB2Parameter("@TankSize", _model.TankSize));
              cmd.Parameters.Add(new iDB2Parameter("@FrontSeatCapacity", _model.FrontSeatCapacity));
              cmd.Parameters.Add(new iDB2Parameter("@RearSeatCapacity", _model.RearSeatCapacity));
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@CreateTime", DBUtils.GetAS400Time(CreateDateTime)));
              cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));
              cmd.Parameters.Add(new iDB2Parameter("@CreatedBy", _model.TireCreatedBy.Trim()));
            }
            else
            {
              if (model.TireCreatedBy.Trim() == "")
              {
                sql = new StringBuilder();
                sql.Append("Update ");
                sql.Append(DBUtils.GetSUPxxx010().Trim());
                sql.Append(".STF ");
                sql.Append("Set ");
                sql.Append("QSFUEL = @FuelType, ");
                sql.Append(" QSTANK = @TankSize, ");
                sql.Append(" QSFSC = @FrontSeatCapacity, ");
                sql.Append(" QSRSC = @RearSeatrCapacity, ");
                sql.Append(" QSTDATE = @CreateDate, ");
                sql.Append(" QSTTIME = @CreateTime, ");
                sql.Append(" QSTUSER = @CreatedBy ");
                sql.Append(" where QSSR# = @SerialNumber ");

                cmd.CommandText = sql.ToString();
                cmd.Parameters.Add(new iDB2Parameter("@FuelType", _model.FuelType));
                cmd.Parameters.Add(new iDB2Parameter("@TankSize", _model.TankSize));
                cmd.Parameters.Add(new iDB2Parameter("@FrontSeatCapacity", _model.FrontSeatCapacity));
                cmd.Parameters.Add(new iDB2Parameter("@RearSeatCapacity", _model.RearSeatCapacity));
                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
                cmd.Parameters.Add(new iDB2Parameter("@CreateTime", DBUtils.GetAS400Time(CreateDateTime)));
                cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(CreateDateTime)));
                cmd.Parameters.Add(new iDB2Parameter("@CreatedBy", _model.TireCreatedBy.Trim()));
              }
              else
              {
                sql = new StringBuilder();
                sql.Append("Update ");
                sql.Append(DBUtils.GetSUPxxx010().Trim());
                sql.Append(".STF ");
                sql.Append("Set ");
                sql.Append(" QSFUEL = @FuelType, ");
                sql.Append(" QSTANK = @TankSize, ");
                sql.Append(" QSFSC = @FrontSeatCapacity, ");
                sql.Append(" QSRSC = @RearSeatrCapacity ");
                sql.Append(" where QSSR# = @SerialNumber ");

                cmd.CommandText = sql.ToString();
                cmd.Parameters.Add(new iDB2Parameter("@FuelType", _model.FuelType));
                cmd.Parameters.Add(new iDB2Parameter("@TankSize", _model.TankSize));
                cmd.Parameters.Add(new iDB2Parameter("@FrontSeatCapacity", _model.FrontSeatCapacity));
                cmd.Parameters.Add(new iDB2Parameter("@RearSeatCapacity", _model.RearSeatCapacity));
                cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
              }
            }
            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Update Tire Tag: Record not updated, no exception thrown");

            sql = new StringBuilder();
            sql.Append("Update ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".S1F ");
            sql.Append("Set ");
            sql.Append(" S2TVW = @VehicleWeight ");
            sql.Append(" where S2SR# = @SerialNumber ");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@VehicleWeight", _model.VehicleWeight));
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Update Tire Tag Vehicle Weight: Record not updated, no exception thrown");
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("TireTagServices", "", "Error in UpdateTireTag", ex);
        throw new ApplicationException("Update Tire Tag: " + ex.Message, ex);
      }
      return ErrorString;
    }
  }
}