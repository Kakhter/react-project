﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using QualityDatabase.Models;
using System.Text;
using IBM.Data.DB2.iSeries;

namespace QualityDatabase.Services
{
  public class GVRWServices
  {
    public GVRWModel GetGVRW(string _serialNumber)
    {
      GVRWModel model = new GVRWModel();
      object obj;
      StringBuilder sql = new StringBuilder();

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

           sql = new StringBuilder();
          sql.Append("select S2FFN1 ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".S1F ");
          sql.Append(" where S2SR# = @SerialNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));
          obj = cmd.ExecuteScalar();
          model.GVRW = DBUtils.GetSafeInteger(obj);
        }
      }
      return model;
    }

  } 
}