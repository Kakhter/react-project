﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class RepairItemServices
  {
    public List<RepairItemModel> RepairItemList
    {
      get { return GetRepairItems(); }
    }

    private List<RepairItemModel> GetRepairItems()
    {
      StringBuilder sql = new StringBuilder();
      RepairItemModel model = null;
      List<RepairItemModel> list = new List<RepairItemModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select RIID#, RIDESC ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QRIF");
            sql.Append(" where RISTAT=@Status");
            sql.Append("   and RIWATER=@Water");
            sql.Append(" order by RIID#");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
            cmd.Parameters.Add(new iDB2Parameter("@Water", "Y"));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new RepairItemModel();
                  model.Code = DBUtils.GetSafeString(rdr["RIID#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["RIDESC"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("RepairItemServices", "", "Error in GetRepairItems", ex);
        throw new ApplicationException("Get Repair Items: " + ex.Message, ex);
      }
      return list;
    }
  }
}