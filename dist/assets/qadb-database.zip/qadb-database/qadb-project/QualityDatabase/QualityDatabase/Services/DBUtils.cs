﻿using QualityDatabase.Common;
using System;
using System.Text;

namespace QualityDatabase.Services
{
  public class DBUtils
  {
    public static string GetSafeString(object obj)
    {
      if (obj == null)
        return "";

      if (obj == DBNull.Value)
        return "";

      return obj.ToString();
    }

    public static decimal GetSafeDecimal(object obj)
    {
      if (obj == null)
        return 0;

      if (obj == DBNull.Value)
        return 0;

      return (decimal)obj;
    }

    public static double GetSafeDouble(object obj)
    {
      if (obj == null)
        return 0;

      if (obj == DBNull.Value)
        return 0;

      double result = 0;
      double.TryParse(GetSafeString(obj),out result);

      return result;
    }

    public static DateTime GetSafeDateTime(object obj)
    {
      decimal dec = 0;
      dec = GetSafeDecimal(obj);
      if (dec == 0)
        return DateTime.MinValue;

      DateTime myDate;
      string strDate = dec.ToString();
      myDate = DateTime.Parse(FormatDateFromAS400ForDisplay(strDate));

      return myDate;
    }

    public static int GetSafeInteger(object obj)
    {
      if (obj == null)
        return 0;

      if (obj == DBNull.Value)
        return 0;
      int result = 0;
      int.TryParse(GetSafeString(obj), out result);

      return result;
    }


    public static string GetAS400Date(DateTime _date)
    {
      string result = "";
      result = _date.ToString("yyyy") + _date.ToString("MM") + _date.ToString("dd");
      return result;
    }

    public static string GetAS400Date(DateTime? _date)
    {
      string result = "";
      DateTime convDate;
      try
      {
        convDate = (DateTime)_date;
        result = convDate.ToString("yyyy") + convDate.ToString("MM") + convDate.ToString("dd");
      }
      catch
      {
        result = "0";
      }
      return result;
    }
    public static string GetAS400Date(string _date)
    {
      string result = "";
      DateTime convDate;
      try
      {
        convDate = DateTime.Parse(_date);
        result = convDate.ToString("yyyy") + convDate.ToString("MM") + convDate.ToString("dd");
      }
      catch
      {
        result = "0";
      }
      return result;
    }

    public static string GetAS400Date(decimal _date)
    {
      string convDate;
      convDate = _date.ToString();
      return GetAS400Date(convDate);
    }

    public static string GetAS400Time(DateTime _time)
    {
      string result = "";
      result = _time.ToString("HH") + _time.ToString("mm") + _time.ToString("ss");
      return result;
    }

    public static string GetAS400Time(string _time)
    {
      string result = "";
      DateTime convTime;
      try
      {
        convTime = DateTime.Parse(_time);
        result = convTime.ToString("HH") + convTime.ToString("mm") + convTime.ToString("ss");
      }
      catch
      {
        result = "0";
      }
      return result;
    }

    public static string FormatDateFromAS400ForDisplay(string _date)
    {
      if (_date.Trim().Length != 8)
      {
        if (_date.Trim() == "0")
          return "";
        else
          return _date;
      }

      string fDate = "";
      fDate = _date.Substring(4, 2) + "/" + _date.Substring(6, 2) + "/" + _date.Substring(0, 4);
      return fDate;
    }

    public static string FormatShortDateFromAS400ForDisplay(string _date)
    {
      if (_date.Trim().Length != 5 && _date.Trim().Length != 6)
      {
        if (_date.Trim() == "0")
          return "";
        else
          return _date;
      }

      if (_date.Trim().Length == 5)
        _date = "0" + _date;

      string fDate = "";
      fDate = _date.Substring(0, 2) + "/" + _date.Substring(2, 2) + "/" + _date.Substring(4, 2);
      return fDate;
    }

    public static string GetAS400ConnectionString()
    {
      StringBuilder ConnectionString = new StringBuilder();
      ConnectionString.Append("Datasource=");
      ConnectionString.Append(Utils.GetAS400IPAddress().ToString());
      ConnectionString.Append("; UserId=PRINTER; Password=PRINTER");

      return ConnectionString.ToString();
    }

    public static string GetFRNxxx010()
    {
      StringBuilder name = new StringBuilder();
      name.Append("FRN");
      name.Append(Properties.Settings.Default.Environment.Trim());
      name.Append("010");

      return name.ToString();
    }

    public static string GetSUPxxx010()
    {
      StringBuilder name = new StringBuilder();
      name.Append("SUP");
      name.Append(Properties.Settings.Default.Environment.Trim());
      name.Append("010");

      return name.ToString();
    }

    public static string GetSupremecmd()
    {
      StringBuilder name = new StringBuilder();
      name.Append("SUPREMECMD");

      return name.ToString();

    }
  }
}