﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace QualityDatabase.Services
{
  public class UserAuthorizationService
  {
    public string GetAuthorizationLevel(string _userName)
    {
      StringBuilder sql = new StringBuilder();
      string level = "V";

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select * ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QAUF");
            sql.Append(" where QAUSER=@UserName ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@UserName", _userName));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  level = DBUtils.GetSafeString(rdr["QAAUTH"]);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("UserAuthorizationServices", "", "Error in GetAuthorizationLevel", ex);
        throw new ApplicationException("Get Authorization Level: " + ex.Message, ex);
      }
      return level;
    }
  }
}