﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using System;
using System.Text;

namespace QualityDatabase.Services
{
    public class InspectionLogServices
    {
        public string UpdateLog(string _serialNumber, string _createDate, string _createTime)
        {
            StringBuilder sql = new StringBuilder();
            int result = 0;
            DateTime CreateDateTime = DateTime.Now;

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("Select count(*) from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF  ");
                        sql.Append(" where QLSR#=@SerialNumber ");
                        sql.Append("   and QLIDTE=@CreateDate ");
                        sql.Append("   and QLTIME=@CreateTime ");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

                        if (result > 0)
                        {
                            sql = new StringBuilder();
                            sql.Append("Insert into ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLILF ");
                            sql.Append("(LLSR#, LLIL, LLIN, LLIT,   ");
                            sql.Append("LLDA, LLDI, LLDT, LLDC,  ");
                            sql.Append("LLIDTE, LLTIME, LLDATE, LLIUSER,  ");
                            sql.Append("LLRA, LLRM,  ");
                            sql.Append("LIRTIME, LIRDATE, LIRUSER, LLIO) ");
                            sql.Append("select QLSR#, QLIL, QLIN, QLIT,   ");
                            sql.Append("QLDA, QLDI, QLDT, QLDC,  ");
                            sql.Append("QLIDTE, QLTIME, QLDATE, QLIUSER,  ");
                            sql.Append("QLRA, QLRM,  ");
                            sql.Append("QIRTIME, QIRDATE, QIRUSER, QLIO ");
                            sql.Append("from ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLIF ");
                            sql.Append("where QLSR#=@SerialNumber ");
                            sql.Append("  and QLIDTE=@CreateDate ");
                            sql.Append("  and QLTIME=@CreateTime  ");

                            cmd.Parameters.Clear();
                            cmd.CommandText = sql.ToString();
                            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
                            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

                            result = cmd.ExecuteNonQuery();
                            if (result == 0)
                                throw new ApplicationException("Line Inspection Log not updated, no exception thrown");
                            else
                                return "";
                        }
                        else
                        {
                            StringBuilder msg = new StringBuilder();
                            msg.Append("Update Line Inspection Log: Invalid parameters - ");
                            msg.Append(_serialNumber);
                            msg.Append(", ");
                            msg.Append(_createDate);
                            msg.Append(", ");
                            msg.Append(_createTime);
                            throw new ApplicationException(msg.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("InspectionLogServices", "", "Error in UpdateLog", ex);
                throw new ApplicationException("Update Line Inspection Log: " + ex.Message, ex);
            }
        }

        public string UpdateLog(string _serialNumber, string _createDate, string _createTime, string _defectArea, string _defectCondtition, string _defectType, string _defectItem)
        {
            StringBuilder sql = new StringBuilder();
            int result = 0;
            DateTime CreateDateTime = DateTime.Now;

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {

                        sql = new StringBuilder();
                        sql.Append("Select count(*) from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLIF  ");
                        sql.Append(" where QLSR#=@SerialNumber ");
                        sql.Append("   and QLIDTE=@CreateDate ");
                        sql.Append("   and QLTIME=@CreateTime ");
                        sql.Append("   and QLDA=@DefectArea ");
                        sql.Append("   and QLDI=@DefectItem ");
                        sql.Append("   and QLDT=@DefectType ");
                        sql.Append("   and QLDC=@DefectCondition ");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectArea", _defectArea));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectItem", _defectItem));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectType", _defectType));
                        cmd.Parameters.Add(new iDB2Parameter("@DefectCondition", _defectCondtition));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

                        if (result == 1)
                        {
                            sql = new StringBuilder();
                            sql.Append("Insert into ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLILF ");
                            sql.Append("(LLSR#, LLIL, LLIN, LLIT,   ");
                            sql.Append("LLDA, LLDI, LLDT, LLDC,  ");
                            sql.Append("LLIDTE, LLTIME, LLDATE, LLIUSER,  ");
                            sql.Append("LLRA, LLRM,  ");
                            sql.Append("LIRTIME, LIRDATE, LIRUSER, LLIO, LLRF) ");

                            sql.Append("select QLSR#, QLIL, QLIN, QLIT,   ");
                            sql.Append("QLDA, QLDI, QLDT, QLDC,  ");
                            sql.Append("QLIDTE, QLTIME, QLDATE, QLIUSER,  ");
                            sql.Append("QLRA, QLRM,  ");
                            sql.Append("QIRTIME, QIRDATE, QIRUSER, QLIO, QLRF ");
                            sql.Append("from ");
                            sql.Append(DBUtils.GetSUPxxx010().Trim());
                            sql.Append(".QLIF ");
                            sql.Append("where QLSR#=@SerialNumber ");
                            sql.Append("  and QLIDTE=@CreateDate ");
                            sql.Append("  and QLTIME=@CreateTime  ");
                            sql.Append("   and QLDA=@DefectArea ");
                            sql.Append("   and QLDI=@DefectItem ");
                            sql.Append("   and QLDT=@DefectType ");
                            sql.Append("   and QLDC=@DefectCondition ");

                            cmd.Parameters.Clear();
                            cmd.CommandText = sql.ToString();
                            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
                            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));
                            cmd.Parameters.Add(new iDB2Parameter("@DefectArea", _defectArea));
                            cmd.Parameters.Add(new iDB2Parameter("@DefectItem", _defectItem));
                            cmd.Parameters.Add(new iDB2Parameter("@DefectType", _defectType));
                            cmd.Parameters.Add(new iDB2Parameter("@DefectCondition", _defectCondtition));

                            result = cmd.ExecuteNonQuery();
                            if (result == 0)
                                throw new ApplicationException("Line Inspection Log not updated, no exception thrown");
                            else
                                return "";
                        }
                        else
                        {
                            StringBuilder msg = new StringBuilder();
                            msg.Append("Update Line Inspection Log: Invalid parameters - ");
                            msg.Append(_serialNumber);
                            msg.Append(", ");
                            msg.Append(_createDate);
                            msg.Append(", ");
                            msg.Append(_createTime);
                            msg.Append(", ");
                            msg.Append(_defectArea);
                            msg.Append(", ");
                            msg.Append(_defectItem);
                            msg.Append(", ");
                            msg.Append(_defectType);
                            msg.Append(", ");
                            msg.Append(_defectCondtition);
                            throw new ApplicationException(msg.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("InspectionLogServices", "", "Error in UpdateLog", ex);
                throw new ApplicationException("Update Line Inspection Log: " + ex.Message, ex);
            }
        }

        public string UpdateLogWithDelete(string _serialNumber, string _createDate, string _createTime)
        {
            StringBuilder sql = new StringBuilder();
            int result = 0;
            DateTime CreateDateTime = DateTime.Now;

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        sql = new StringBuilder();
                        sql.Append("Insert into ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QLILF ");
                        sql.Append("(LLSR#, LLIDTE, LLTIME)   ");
                        sql.Append("values ");
                        sql.Append("(@SerialNumber, @CreateDate, @CreateTime)");


                        cmd.Parameters.Clear();
                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
                        cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

                        result = cmd.ExecuteNonQuery();
                        if (result == 0)
                            throw new ApplicationException("Line Inspection Log not updated, no exception thrown");
                        else
                            return "";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("InspectionLogServices", "", "Error in UpdateLogWithDelete", ex);
                throw new ApplicationException("Update Line Inspection Log with Delete: " + ex.Message, ex);
            }
        }

    }
}