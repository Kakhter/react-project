﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Models;
using System.Text;

namespace QualityDatabase.Services
{
  public class VehicleWeightServices
  {
    //public VehicleWeightModel GetVehicleWeight(string _serialNumber)
    //{
    //  VehicleWeightModel model = new VehicleWeightModel();
    //  model.VehicleWeight = 2000;
    //  return model;
    //}

    public VehicleWeightModel GetVehicleWeight(string _serialNumber)
    {
      VehicleWeightModel model = new VehicleWeightModel();
      object obj;
      StringBuilder sql = new StringBuilder();

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          sql = new StringBuilder();
          sql.Append("select S2TVW ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".S1F ");
          sql.Append(" where S2SR# = @SerialNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));
          obj = cmd.ExecuteScalar();
          model.VehicleWeight = DBUtils.GetSafeInteger(obj);
        }
      }
      return model;
    }
  }
}