﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;


namespace QualityDatabase.Services
{
  public class LeakRepairServices
  {
    public List<LeakRepairIndexModel> GetLeakRepairForIndex(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      LeakRepairIndexModel lr = null;
      List<LeakRepairIndexModel> list = new List<LeakRepairIndexModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select DISTINCT  QWSR#, MAX(QWDATE) AS QWDATE, MAX(QWDA) AS QWDA, MAX(QWDI) AS QWDI, MAX(QWDT) AS QWDT, ");
            sql.Append(" QWIDTE, QWTIME, ");
            sql.Append(" MAX(DADESC) AS DADESC, MAX(UPPER(RTRIM(DIDESC))) AS DIDESC, MAX(DTDESC) AS DTDESC, ");
            sql.Append(" MAX(QWRDATE) AS QWRDATE, MAX(QWRUSER) AS QWRUSER, MAX(QWRA) AS QWRA, MAX(QWRI) AS QWRI, ");
            sql.Append(" MAX(RADESC) AS RADESC, MAX(RIDESC) AS RIDESC ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF ");

            sql.Append("left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDAF ");
            sql.Append(" on QWDA = DAID#");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDIF ");
            sql.Append(" on QWDI = DIID#");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QDTF  ");
            sql.Append(" on QWDT = DTID#");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QRAF ");
            sql.Append(" on QWRA = RAID#");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QRIF ");
            sql.Append(" on QWRI = RIID#");

            sql.Append(" where QWSR#=@SerialNumber");
            sql.Append(" GROUP BY QWTIME,QWIDTE,QWSR# ORDER BY QWIDTE ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

            //cn.ConnectionString = "Datasource=192.168.30.8; UserId=PRINTER; Password=PRINTER";
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            // get Serial Number, Model, Order Number, and Warehouse
            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  lr = new LeakRepairIndexModel();
                  lr.InspectionDate = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QWDATE"]));
                  lr.AreaDesc = DBUtils.GetSafeString(rdr["DADESC"]).Trim();
                  lr.ItemDesc = DBUtils.GetSafeString(rdr["DIDESC"]).Trim();
                  lr.TypeDesc = DBUtils.GetSafeString(rdr["DTDESC"]).Trim();
                  lr.RepairDate = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QWRDATE"]));
                  lr.RepairAction = DBUtils.GetSafeString(rdr["QWRA"]).Trim();
                  lr.RepairActionDesc = DBUtils.GetSafeString(rdr["RADESC"]).Trim();
                  lr.RepairItem = DBUtils.GetSafeString(rdr["QWRI"]).Trim();
                  lr.RepairItemDesc = DBUtils.GetSafeString(rdr["RIDESC"]).Trim();
                  lr.SerialNumber = DBUtils.GetSafeString(rdr["QWSR#"]).Trim();
                  lr.CreateDate = DBUtils.GetSafeString(rdr["QWIDTE"]);
                  lr.CreateTime = DBUtils.GetSafeString(rdr["QWTIME"]);
                  list.Add(lr);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("LeakRepairServices", "", "Error in GetLeakRepairForIndex", ex);
        throw new ApplicationException("Get Leak Repair for Index: " + ex.Message, ex);
      }
      return list;
    }

    public LeakRepairModel GetSingleLeakRepair(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      LeakRepairModel lr = new LeakRepairModel();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select * ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF");
            sql.Append(" where QWSR#=@SerialNumber ");
            sql.Append("   and QWIDTE=@CreateDate ");
            sql.Append("   and QWTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

            //cn.ConnectionString = "Datasource=192.168.30.8; UserId=PRINTER; Password=PRINTER";
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            // get Serial Number, Model, Order Number, and Warehouse
            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  lr = new LeakRepairModel();
                  lr.RepairDate = DBUtils.GetSafeDateTime(rdr["QWRDATE"]);
                  lr.RepairItem = DBUtils.GetSafeString(rdr["QWRI"]).Trim();
                  lr.RepairAction = DBUtils.GetSafeString(rdr["QWRA"]).Trim();
                  lr.LeakRepairCreateTime = DBUtils.GetSafeString(rdr["QWRTIME"]);
                  lr.LeakRepairCreateDate = DBUtils.GetSafeString(rdr["QWRDTE"]);
                  lr.LeakRepairCreatedBy = DBUtils.GetSafeString(rdr["QWRUSER"]).Trim();
                  lr.SerialNumber = DBUtils.GetSafeString(rdr["QWSR#"]).Trim();
                  lr.WaterTestCreateDate = DBUtils.GetSafeString(rdr["QWIDTE"]);
                  lr.WaterTestCreateTime = DBUtils.GetSafeString(rdr["QWTIME"]);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("LeakRepairServices", "", "Error in GetSingleLeakRepair", ex);
        throw new ApplicationException("Get Single Leak Repair: " + ex.Message, ex);
      }
      return lr;
    }

    public string UpdateLeakRepair(LeakRepairModel _model)
    {
      LeakRepairModel CurrentModel = this.GetSingleLeakRepair(_model.SerialNumber, _model.WaterTestCreateDate, _model.WaterTestCreateTime);
      if (CurrentModel.LeakRepairCreatedBy.Trim() == "")
      {
        DateTime CreateDateTime = DateTime.Now;
        _model.LeakRepairCreateDate = DBUtils.GetAS400Date(CreateDateTime);
        _model.LeakRepairCreateTime = DBUtils.GetAS400Time(CreateDateTime);
      }
      else
      {
        _model.LeakRepairCreateDate = CurrentModel.LeakRepairCreateDate;
        _model.LeakRepairCreateTime = CurrentModel.LeakRepairCreateTime;
        _model.LeakRepairCreatedBy = CurrentModel.LeakRepairCreatedBy;

      }

      StringBuilder sql = new StringBuilder();
      int result = 0;

      _model.ResetNullValues();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF  ");
            sql.Append(" where QWSR#=@SerialNumber ");
            sql.Append("   and QWIDTE=@WaterTestCreateDate ");
            sql.Append("   and QWTIME=@WaterTestCreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _model.WaterTestCreateDate));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _model.WaterTestCreateTime));


            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Update ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QWTF  ");
              sql.Append("Set ");
              sql.Append(" QWRA = @RepairAction, ");
              sql.Append(" QWRI = @RepairItem, ");
              sql.Append(" QWRDATE = @RepairDate, ");
              sql.Append(" QWRDTE = @LeakRepairCreateDate, ");
              sql.Append(" QWRTIME = @LeakRepairCreateTime, ");
              sql.Append(" QWRUSER = @LeakRepairCreatedBy");
              sql.Append(" where QWSR#=@SerialNumber ");
              sql.Append("   and QWIDTE=@WaterTestCreateDate ");
              sql.Append("   and QWTIME=@WaterTestCreateTime ");

              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@RepairAction", _model.RepairAction.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@RepairItem", _model.RepairItem.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@RepairDate", DBUtils.GetAS400Date(_model.RepairDate)));
              cmd.Parameters.Add(new iDB2Parameter("@LeakRepairCreateDate", _model.LeakRepairCreateDate));
              cmd.Parameters.Add(new iDB2Parameter("@LeakRepairCreateTime", _model.LeakRepairCreateTime));
              cmd.Parameters.Add(new iDB2Parameter("@LeakRepairCreatedBy", _model.LeakRepairCreatedBy.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _model.WaterTestCreateDate));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _model.WaterTestCreateTime));
              result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Update Leak Repair: Record not updated, no exception thrown");
              else
              {
                WaterTestLogServices wtLog = new WaterTestLogServices();
                wtLog.UpdateLog(_model.SerialNumber, _model.WaterTestCreateDate, _model.WaterTestCreateTime);
                return "";
              }
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              if (result > 1)
                msg.Append("Multiple records found - ");
              else
                msg.Append("Update Leak Repair: Invalid parameters - ");
              msg.Append(_model.SerialNumber);
              msg.Append(", ");
              msg.Append(_model.WaterTestCreateDate);
              msg.Append(", ");
              msg.Append(_model.WaterTestCreateTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("LeakRepairServices", "", "Error in UpdateLeakRepair", ex);
        throw new ApplicationException("Update Leak Repair: " + ex.Message, ex);
      }
    }
  }
}