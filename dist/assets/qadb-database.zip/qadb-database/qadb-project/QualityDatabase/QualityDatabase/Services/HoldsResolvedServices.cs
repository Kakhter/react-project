﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace QualityDatabase.Services
{
  public class HoldsResolvedServices
  {
    public string UpdateHoldsResolved(HoldsResolvedModel _model)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      if (_model.ResolvedBy.Trim() != "")
      {
        HoldsResolvedModel currentModel = GetSingleHoldsResolved(_model.SerialNumber, _model.HoldCreateDate, _model.HoldCreateTime);
            if (currentModel.ResolvedBy.Trim() == "")
            {
              _model.ResolutionDate = DBUtils.GetAS400Date(CreateDateTime);
              _model.ResolutionTime = DBUtils.GetAS400Time(CreateDateTime);
              _model.ResolvedBy = _model.ResolvedBy;
            }
            else if (currentModel.ResolvedBy.Trim().ToUpper() != _model.ResolvedBy.Trim().ToUpper())
            {
              _model.ResolutionDate = DBUtils.GetAS400Date(CreateDateTime);
              _model.ResolutionTime = DBUtils.GetAS400Time(CreateDateTime);
              _model.ResolvedBy = _model.ResolvedBy;
            }
            else // added new logig 
            {
                _model.ResolutionDate = DBUtils.GetAS400Date(CreateDateTime);
                _model.ResolutionTime = DBUtils.GetAS400Time(CreateDateTime);
            }
      }
      else
      {
        _model.ResolutionDate = "0";
        _model.ResolutionTime = "0";
        _model.ResolvedBy = "";
      }

      _model.ResetNullValues();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHIF  ");
            sql.Append(" where QHSR#=@SerialNumber ");
            sql.Append("   and QHDATE=@CreateDate ");
            sql.Append("   and QHTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.HoldCreateDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.HoldCreateTime));


            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Update ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QHIF  ");
              sql.Append("Set ");
              sql.Append(" QHRATE = @ResolutionDate, ");
              sql.Append(" QHRTIME = @ResolutionTime, ");
              sql.Append(" QHRUSER = @ResolvedBy, ");
              sql.Append(" QHRHRS = @ReworkHours ");
              sql.Append(" where QHSR#=@SerialNumber ");
              sql.Append("   and QHDATE=@CreateDate ");
              sql.Append("   and QHTIME=@CreateTime ");

              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@ResolutionDate", _model.ResolutionDate));
              cmd.Parameters.Add(new iDB2Parameter("@ResolutionTime", _model.ResolutionTime));
              cmd.Parameters.Add(new iDB2Parameter("@ResolvedBy", _model.ResolvedBy.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@ReworkHours", _model.ReworkHours));
              result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Update Holds Resolved: Record not updated, no exception thrown");
              else
              {
                //InspectionLogServices inspLog = new InspectionLogServices();
                //inspLog.UpdateLog(_model.SerialNumber, _model.InspectionCreateDate, _model.InspectionCreateTime);
                return "";
              }
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              if (result > 1)
                msg.Append("Multiple records found - ");
              else
                msg.Append("Update Holds Resolved: Invalid parameters - ");
              msg.Append(_model.SerialNumber);
              msg.Append(", ");
              msg.Append(_model.HoldCreateDate);
              msg.Append(", ");
              msg.Append(_model.HoldCreateTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("LineInspectionServices", "", "Error in UpdateLineInspection", ex);
        throw new ApplicationException("Update Line Inspection: " + ex.Message, ex);
      }
    }

    public List<HoldsResolvedModel> GetHoldsResolvedForIndex(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      HoldsResolvedModel model = null;
      List<HoldsResolvedModel> list = new List<HoldsResolvedModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QHSR#, QHDESC, QHTIME, QHDATE, QHUSER, QHCAT, ");
            sql.Append("HCDESC, QHRTIME, QHRATE, QHRUSER, QHRHRS ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHIF ");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHCF ");
            sql.Append(" on QHCAT = HCID#");

            sql.Append(" where QHSR#=@SerialNumber");
            sql.Append(" order by QHDATE, QHTIME ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new HoldsResolvedModel();
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QHSR#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["QHDESC"]).Trim();
                  model.HoldCreateDate = DBUtils.GetSafeString(rdr["QHDATE"]);
                  model.HoldCreateDateDisplay = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QHDATE"]));
                  model.HoldCreateTime = DBUtils.GetSafeString(rdr["QHTIME"]);
                  model.HoldCreatedBy = DBUtils.GetSafeString(rdr["QHUSER"]).Trim();
                  model.Category = DBUtils.GetSafeString(rdr["QHCAT"]).Trim();
                  model.CategoryDescription = DBUtils.GetSafeString(rdr["HCDESC"]).Trim();
                  model.ResolutionDate = DBUtils.GetSafeString(rdr["QHRATE"]);
                  model.ResolutionDateDisplay = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QHRATE"]));
                  model.ResolutionTime = DBUtils.GetSafeString(rdr["QHRTIME"]);
                  model.ResolvedBy = DBUtils.GetSafeString(rdr["QHRUSER"]).Trim();
                  model.ReworkHours = DBUtils.GetSafeDecimal(rdr["QHRHRS"]);
                  //if (model.ResolvedBy.Trim() == "")
                  //  model.Resolved = "";
                  //else
                  //  model.Resolved = "Resolved";
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("HoldsResolvedServices", "", "Error in GetHoldsResolvedForIndex", ex);
        throw new ApplicationException("Get Holds Resolved for Index: " + ex.Message, ex);
      }
      return list;
    }

    public HoldsResolvedModel GetSingleHoldsResolved(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      HoldsResolvedModel model = new HoldsResolvedModel();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QHSR#, QHDESC, QHTIME, QHDATE, QHUSER, QHCAT, ");
            sql.Append("HCDESC, QHRTIME, QHRATE, QHRUSER, QHRHRS ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHIF ");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHCF ");
            sql.Append(" on QHCAT = HCID#");

            sql.Append(" where QHSR#=@SerialNumber ");
            sql.Append("   and QHDATE=@CreateDate ");
            sql.Append("   and QHTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new HoldsResolvedModel();
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QHSR#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["QHDESC"]).Trim();
                  model.HoldCreateDate = DBUtils.GetSafeString(rdr["QHDATE"]);
                  model.HoldCreateTime = DBUtils.GetSafeString(rdr["QHTIME"]);
                  model.HoldCreatedBy = DBUtils.GetSafeString(rdr["QHUSER"]).Trim();
                  model.Category = DBUtils.GetSafeString(rdr["QHCAT"]).Trim();
                  model.CategoryDescription = DBUtils.GetSafeString(rdr["HCDESC"]).Trim();
                  model.ResolutionDate = DBUtils.GetSafeString(rdr["QHRATE"]);
                  model.ResolutionTime = DBUtils.GetSafeString(rdr["QHRTIME"]);
                  model.ResolvedBy = DBUtils.GetSafeString(rdr["QHRUSER"]).Trim();
                  model.ReworkHours = DBUtils.GetSafeDecimal(rdr["QHRHRS"]);
                //if (model.ResolvedBy.Trim() == "")
                //  model.Resolved = "NO";
                //else
                //  model.Resolved = "YES";
            }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("HoldsResolvedServices", "", "Error in GetSingleHoldsResolved", ex);
        throw new ApplicationException("Get Single Holds Resolved: " + ex.Message, ex);
      }
      return model;
    }

    public Boolean AreAllHoldsResolved(string _SerialNumber)
    {
      StringBuilder sql;
      Boolean Resolved = true;

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select QHRUSER ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".QHIF ");
          sql.Append(" where QHSR# = @SerialNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _SerialNumber.Trim()));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                if (DBUtils.GetSafeString(rdr["QHRUSER"]).Trim() == "")
                  Resolved = false;
              }
            }
          }
        }
      }
      return Resolved;
    }
  }
}