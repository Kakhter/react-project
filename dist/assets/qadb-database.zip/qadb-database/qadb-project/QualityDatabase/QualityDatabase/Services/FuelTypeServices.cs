﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class FuelTypeServices
  {
    public List<FuelTypeModel> FuelTypeList
    {
      get { return GetFuelTypes(); }
    }

    private List<FuelTypeModel> GetFuelTypes()
    {
      StringBuilder sql = new StringBuilder();
      FuelTypeModel model = null;
      List<FuelTypeModel> list = new List<FuelTypeModel>();

   
      model = new FuelTypeModel();
      model.Code = "DSL";
      model.Description = "Diesel";
      list.Add(model);

      model = new FuelTypeModel();
      model.Code = "GAS";
      model.Description = "Gas";
      list.Add(model);

      model = new FuelTypeModel();
      model.Code = "PRO";
      model.Description = "Propane";
      list.Add(model);

      return list;
    }

    public string GetFuelTypeDescription(string _fuelTypeCode)
    {
      if (_fuelTypeCode.Trim() == "DSL")
        return "Diesel";
      else if (_fuelTypeCode.Trim() == "GAS")
        return "Gas";
      else if (_fuelTypeCode.Trim() == "PRO")
        return "Propane";
      else
        return "";
    }
  }
}