﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class HoldIssuesServices
  {
    public string AddHoldIssue(HoldIssuesModel _model)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      _model.ResetNullValues();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("insert into ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHIF (");
            sql.Append("QHSR#, QHDESC, QHTIME, QHDATE, QHUSER, QHCAT,  ");
            sql.Append("QHRTIME, QHRATE, QHRUSER, QHILOC ");
            sql.Append(") values (");
            sql.Append("@SerialNumber, @Description, @HoldTime, @HoldDate, @HoldUser, @Category, ");
            sql.Append("@ResolutionTime, @ResolutionDate, @ResolvedBy, @Hold ");
            sql.Append(")");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@Description", _model.Description.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@HoldUser", _model.HoldCreatedBy.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@HoldDate", DBUtils.GetAS400Date(CreateDateTime)));
            cmd.Parameters.Add(new iDB2Parameter("@HoldTime", DBUtils.GetAS400Time(CreateDateTime)));
            cmd.Parameters.Add(new iDB2Parameter("@Category", _model.Category.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@ResolutionTime", "0"));
            cmd.Parameters.Add(new iDB2Parameter("@ResolutionDate", "0"));
            cmd.Parameters.Add(new iDB2Parameter("@ResolvedBy", ""));
            cmd.Parameters.Add(new iDB2Parameter("@Hold", _model.Hold.Trim()));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Record not added, exception no thrown");
            else
            {
              //InspectionLogServices inspLog = new InspectionLogServices();
              //inspLog.UpdateLog(_model.SerialNumber, DBUtils.GetAS400Date(CreateDateTime), DBUtils.GetAS400Time(CreateDateTime));

              return "";
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("HoldIssuesServices", _model.HoldCreatedBy, "Error in AddHoldIssue with " + _model.SerialNumber, ex);
        throw new ApplicationException("Add Hold Issue: " + ex.Message, ex);
      }
    }

    public string UpdateHoldIssue(HoldIssuesModel _model)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      _model.ResetNullValues();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHIF  ");
            sql.Append(" where QHSR#=@SerialNumber ");
            sql.Append("   and QHDATE=@CreateDate ");
            sql.Append("   and QHTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.HoldCreateDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.HoldCreateTime));


            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Update ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QHIF  ");
              sql.Append("Set ");
              sql.Append(" QHCAT = @Category, ");
              sql.Append(" QHDESC = @Description, "); 
              sql.Append(" QHILOC = @Hold ");
              sql.Append(" where QHSR#=@SerialNumber ");
              sql.Append("   and QHDATE=@CreateDate ");
              sql.Append("   and QHTIME=@CreateTime ");
              

              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@Category", _model.Category.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@Description", _model.Description.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@Hold", _model.Hold.Trim()));
              result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Update Hold Issue: Record not updated, no exception thrown");
              else
              {
                //InspectionLogServices inspLog = new InspectionLogServices();
                //inspLog.UpdateLog(_model.SerialNumber, _model.InspectionCreateDate, _model.InspectionCreateTime);
                return "";
              }
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              if (result > 1)
                msg.Append("Multiple records found - ");
              else
                msg.Append("Update Hold Issue: Invalid parameters - ");
              msg.Append(_model.SerialNumber);
              msg.Append(", ");
              msg.Append(_model.HoldCreateDate);
              msg.Append(", ");
              msg.Append(_model.HoldCreateTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("LineInspectionServices", "", "Error in UpdateLineInspection", ex);
        throw new ApplicationException("Update Line Inspection: " + ex.Message, ex);
      }
    }

    public string DeleteHoldIssue(HoldIssuesModel _model)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHIF  ");
            sql.Append(" where QHSR#=@SerialNumber ");
            sql.Append("   and QHDATE=@CreateDate ");
            sql.Append("   and QHTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.HoldCreateDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.HoldCreateTime));


            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Delete from ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QHIF  ");
              sql.Append(" where QHSR#=@SerialNumber ");
              sql.Append("   and QHDATE=@CreateDate ");
              sql.Append("   and QHTIME=@CreateTime ");

              cmd.Parameters.Clear();
              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _model.SerialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _model.HoldCreateDate));
              cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _model.HoldCreateTime));

              result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Delete Hold Issue: Record not deleted, no exception thrown");
              else
              {
                //InspectionLogServices inspLog = new InspectionLogServices();
                //inspLog.UpdateLogWithDelete(_model.SerialNumber, _model.InspectionCreateDate, _model.InspectionCreateTime);
                return "";
              }
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              if (result > 1)
                msg.Append("Multiple records found - ");
              else
                msg.Append("Delete Hold Issue: Invalid parameters - ");
              msg.Append(_model.SerialNumber);
              msg.Append(", ");
              msg.Append(_model.HoldCreateDate);
              msg.Append(", ");
              msg.Append(_model.HoldCreateTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("HoldIssuesServices", "", "Error in DeleteHoldIssue", ex);
        throw new ApplicationException("Delete Hold Issue: " + ex.Message, ex);
      }
    }

    public List<HoldIssuesModel> GetHoldForIndex(string _serialNumber)
    {
      StringBuilder sql = new StringBuilder();
      HoldIssuesModel model = null;
      List<HoldIssuesModel> list = new List<HoldIssuesModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QHSR#, QHDESC, QHTIME, QHDATE, QHUSER, QHCAT, ");
            sql.Append("HCDESC, QHRTIME, QHRATE, QHRUSER, QHILOC ");  //QHILOC added for Hold field ###@@
                        sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHIF ");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHCF ");
            sql.Append(" on QHCAT = HCID#");

            sql.Append(" where QHSR#=@SerialNumber");
            sql.Append(" order by QHDATE, QHTIME ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new HoldIssuesModel();
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QHSR#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["QHDESC"]).Trim();
                  model.HoldCreateDate = DBUtils.GetSafeString(rdr["QHDATE"]);
                  model.HoldCreateDateDisplay = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QHDATE"]));
                  model.HoldCreateTime = DBUtils.GetSafeString(rdr["QHTIME"]);
                  model.HoldCreatedBy = DBUtils.GetSafeString(rdr["QHUSER"]).Trim();
                  model.Category = DBUtils.GetSafeString(rdr["QHCAT"]).Trim();
                  model.CategoryDescription = DBUtils.GetSafeString(rdr["HCDESC"]).Trim();
                  model.ResolutionDate = DBUtils.GetSafeString(rdr["QHRATE"]);
                  model.ResolutionDateDisplay = DBUtils.FormatDateFromAS400ForDisplay(DBUtils.GetSafeString(rdr["QHRATE"]));
                  model.ResolutionTime = DBUtils.GetSafeString(rdr["QHRTIME"]);
                  model.ResolvedBy = DBUtils.GetSafeString(rdr["QHRUSER"]).Trim();
                  if (DBUtils.GetSafeString(rdr["QHRUSER"]).Trim() == "")
                    model.Resolved = "";
                  else
                    model.Resolved = "Resolved";
                  model.Hold = DBUtils.GetSafeString(rdr["QHILOC"]).Trim(); //QHILOC added for Hold field ###@@
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("HoldServices", "", "Error in GetHoldForIndex", ex);
        throw new ApplicationException("Get Hold for Index: " + ex.Message, ex);
      }
      return list;
    }

    public HoldIssuesModel GetSingleHoldIssue(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      HoldIssuesModel model = new HoldIssuesModel();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select QHSR#, QHDESC, QHTIME, QHDATE, QHUSER, QHCAT, HCDESC, QHILOC "); //added QHILOC for Hold added by ###@@
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHIF ");

            sql.Append(" left outer join ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QHCF ");
            sql.Append(" on QHCAT = HCID#");

            sql.Append(" where QHSR#=@SerialNumber ");
            sql.Append("   and QHDATE=@CreateDate ");
            sql.Append("   and QHTIME=@CreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@CreateDate", _createDate));
            cmd.Parameters.Add(new iDB2Parameter("@CreateTime", _createTime));

            //cn.ConnectionString = "Datasource=192.168.30.8; UserId=PRINTER; Password=PRINTER";
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            // get Serial Number, Model, Order Number, and Warehouse
            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new HoldIssuesModel();
                  model.SerialNumber = DBUtils.GetSafeString(rdr["QHSR#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["QHDESC"]).Trim();
                  model.HoldCreateDate = DBUtils.GetSafeString(rdr["QHDATE"]);
                  model.HoldCreateTime = DBUtils.GetSafeString(rdr["QHTIME"]);
                  model.HoldCreatedBy = DBUtils.GetSafeString(rdr["QHUSER"]).Trim();
                  model.Category = DBUtils.GetSafeString(rdr["QHCAT"]).Trim();
                  model.CategoryDescription = DBUtils.GetSafeString(rdr["HCDESC"]).Trim();
                  model.Hold = DBUtils.GetSafeString(rdr["QHILOC"]).Trim(); 
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("HoldIssuesServices", "", "Error in GetSingleHoldIssue", ex);
        throw new ApplicationException("Get Single Hold Issue: " + ex.Message, ex);
      }
      return model;
    }

  }
}