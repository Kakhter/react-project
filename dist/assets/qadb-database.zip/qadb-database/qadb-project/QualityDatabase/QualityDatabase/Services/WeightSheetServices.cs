﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;


namespace QualityDatabase.Services
{
  public class WeightSheetServices
  {
    public List<WeightSheetIndexModel> GetWeightSheetListForIndex(string _bodyNumber)
    {
      List<WeightSheetIndexModel> list = new List<WeightSheetIndexModel>();
      DateTime pdfDateTime;

      pdfDateTime = GetPDFDateTime(_bodyNumber);
      if (pdfDateTime > DateTime.MinValue)
      {

        WeightSheetIndexModel model = new WeightSheetIndexModel();
        model.PDFFileName = "weight sheet.pdf";
        model.PDFDateTime = pdfDateTime;
        list.Add(model);
      }

      return list;
    }


        //private DateTime GetPDFDateTime(string _bodyNumber)
        //{
        //  DateTime pdfDateTime = DateTime.MinValue;

        //  System.Net.FtpWebRequest request = (System.Net.FtpWebRequest)System.Net.FtpWebRequest.Create(GetFTPPath(_bodyNumber.Trim()));

        //  request.Method = WebRequestMethods.Ftp.GetDateTimestamp;
        //  try
        //  {
        //    FtpWebResponse resp = (FtpWebResponse)request.GetResponse();
        //    pdfDateTime = resp.LastModified;
        //  }
        //  catch (WebException ex)
        //  {
        //    pdfDateTime = DateTime.MinValue;
        //  }

        //  return pdfDateTime;
        //}

        private DateTime GetPDFDateTime(string _bodyNumber)
        {
            DateTime pdfDateTime = DateTime.MinValue;
            string uncPath = GetUNCPath(_bodyNumber.Trim()); // Assuming you have a GetUNCPath method to get the UNC path

            try
            {
                FileInfo fileInfo = new FileInfo(uncPath);
                if (fileInfo.Exists)
                {
                    pdfDateTime = fileInfo.LastWriteTime; // Or LastWriteTimeUtc for UTC time
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions, log if necessary
                Console.WriteLine($"Error retrieving file date-time from UNC path: {ex.Message}");
            }

            return pdfDateTime;
        }


        private string GetUNCPath(string _bodyNumber)
        {
            UNCUtils utils = new UNCUtils(_bodyNumber);
            string path = utils.GetUNCPath();

            StringBuilder HTTPPath = new StringBuilder();
            HTTPPath.Append(path.ToString());
            HTTPPath.Append("weight sheet.pdf");

            return HTTPPath.ToString();
        }



        public WeightSheetUniversalModel GetUniversalWeightSheet(object _bodyNumber,
                                                             object _vehicleType,
                                                             object _weightFrontAxle,
                                                             object _totalVehicleWeight,
                                                             object _weightRearAxle,
                                                             object _remarks,
                                                             string _userName)
    {
      string SerialNumber;
      if (_bodyNumber == null)
        SerialNumber = "";
      else
        SerialNumber = _bodyNumber.ToString();

      WeightSheetUniversalModel work = new WeightSheetUniversalModel();
      work = GetUniversalData(SerialNumber, _userName);

      WeightSheetUniversalModel model = new WeightSheetUniversalModel();

      WeightSheetFileServices db = new WeightSheetFileServices();

      model.CreateDateTime = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
      if (_vehicleType == null)
        model.VehicleType = "";
      else
        model.VehicleType = _vehicleType.ToString();
      model.WeighedBy = "WABASH NATIONAL, L.P.";
      model.SupremeLocation = work.SupremeLocation;

      model.SupremeBodyNumber = SerialNumber;
      model.SupremeModel = work.SupremeModel;
      model.GVWR = work.GVWR;
      if (_weightFrontAxle == null)
        model.WeightFrontAxle = "";
      else
        model.WeightFrontAxle = _weightFrontAxle.ToString();
      if (_totalVehicleWeight == null)
        model.TotalVehicleWeight = "";
      else
        model.TotalVehicleWeight = _totalVehicleWeight.ToString();
      if (_weightRearAxle == null)
        model.WeightRearAxle = "";
      else
        model.WeightRearAxle = _weightRearAxle.ToString();
      model.VIN = work.VIN;
      model.CustomerName = work.CustomerName.Trim();
      model.CustomerAddress1 = work.CustomerAddress1.Trim();
      model.CustomerAddress2 = work.CustomerAddress2.Trim();
      model.NumberOfUnits = "1";
      if (_remarks == null)
        model.Remarks = "";
      else
        model.Remarks = _remarks.ToString();

      model.DocumentSerial = db.GetNextDocumentNumber(work.Division, model.SupremeBodyNumber, model.Remarks);

      model.Signature = work.Signature;
      model.LicenseNumber = work.LicenseNumber;
      model.Division = work.Division;
      return model;
    }

    public string GetVIN(string _serialNumber)
    {
      string vin = "";
      StringBuilder sql;

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select S1VIN# ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".S1P ");
          sql.Append(" where S1SR#=@SerialNumber");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          // get vin number
          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                vin = DBUtils.GetSafeString(rdr["S1VIN#"]);
              }
            }
          }
        }
      }


      return vin;
    }

    private WeightSheetUniversalModel GetUniversalData(string _serialNumber, string _user)
    {
      WeightSheetUniversalModel model = new WeightSheetUniversalModel();
      StringBuilder sql = new StringBuilder();
      object obj;
      string SerialNumber = "";
      string supremeModel = "";
      decimal OrderNumber = 0;
      string Vin = "";
      string Division = "";
      string OverrideShip = "";
      string ShipTo = "";

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select S1SR#, S1PN, S1ORD#, S1VIN# ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".S1P ");
          sql.Append(" where S1SR#=@SerialNumber");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          // get Serial Number, Model, Order Number, and Warehouse
          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                SerialNumber = DBUtils.GetSafeString(rdr["S1SR#"]);
                supremeModel = DBUtils.GetSafeString(rdr["S1PN"]);
                OrderNumber = DBUtils.GetSafeDecimal(rdr["S1ORD#"]);
                Vin = DBUtils.GetSafeString(rdr["S1VIN#"]);
              }
              model.SupremeModel = supremeModel;
              model.VIN = Vin;
            }
          }

          // get Sold To Customer Number
          sql = new StringBuilder();
          sql.Append("select OHDIV, OHOVSW, OHSTKY ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".OHP ");
          sql.Append(" where OHORD# = @OrderNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@OrderNumber", OrderNumber));
          //obj = cmd.ExecuteScalar();
          //Division = DBUtils.GetSafeString(obj);

          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                Division = DBUtils.GetSafeString(rdr["OHDIV"]);
                OverrideShip = DBUtils.GetSafeString(rdr["OHOVSW"]);
                ShipTo = DBUtils.GetSafeString(rdr["OHSTKY"]);
              }
              model.Division = Division;
            }
          }

          // Supreme Location
          sql = new StringBuilder();
          sql.Append("select NFDESC ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".NFP ");
          sql.Append(" where NFTYP = @Type ");
          sql.Append("   and NFNUMB = @Div");
          sql.Append("   and NFSUFX = @Suffix");
          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@Type", "DV"));
          cmd.Parameters.Add(new iDB2Parameter("@Div", Division));
          cmd.Parameters.Add(new iDB2Parameter("@Suffix", "3"));
          obj = cmd.ExecuteScalar();
          model.SupremeLocation = DBUtils.GetSafeString(obj);

          if (OverrideShip == "O")
          {
            sql = new StringBuilder();
            sql.Append("select ODNAME, ODADR2, ODADR5 ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".O2P ");
            sql.Append(" where O2ORD# = @OrderNumber");
            sql.Append("   and O2ITEM = @Item");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@OrderNumber", OrderNumber));
            cmd.Parameters.Add(new iDB2Parameter("@Item", ".01"));
            //obj = cmd.ExecuteScalar();
            //Division = DBUtils.GetSafeString(obj);

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model.CustomerName = DBUtils.GetSafeString(rdr["ODNAME"]);
                  model.CustomerAddress1 = DBUtils.GetSafeString(rdr["ODADR2"]).Trim();
                  string work = DBUtils.GetSafeString(rdr["ODADR5"]);
                  StringBuilder str = new StringBuilder();
                  str.Append(work.Substring(0, 18).Trim());
                  str.Append(", ");
                  str.Append(work.Substring(18, 2).Trim());
                  str.Append(" ");
                  str.Append(work.Substring(20, 10).Trim());
                  model.CustomerAddress2 = str.ToString();
                }
              }
            }
          }
          else
          {
            sql = new StringBuilder();
            sql.Append("select CMNAME, CMLNE3, CMCITY, CMST, CMZIP ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".CM1P ");
            sql.Append(" where C1STKY  = @ShipToCustomer");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@ShipToCustomer", ShipTo));

            //obj = cmd.ExecuteScalar();
            //Division = DBUtils.GetSafeString(obj);

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model.CustomerName = DBUtils.GetSafeString(rdr["CMNAME"]);
                  model.CustomerAddress1 = DBUtils.GetSafeString(rdr["CMLNE3"]).Trim();
                  StringBuilder str = new StringBuilder();
                  str.Append(DBUtils.GetSafeString(rdr["CMCITY"]).Trim());
                  str.Append(", ");
                  str.Append(DBUtils.GetSafeString(rdr["CMST"]).Trim());
                  str.Append(" ");
                  str.Append(DBUtils.GetSafeString(rdr["CMZIP"]).Trim());
                  model.CustomerAddress2 = str.ToString();
                }
              }
            }

          }

          // Signature
          sql = new StringBuilder();
          sql.Append("select USNAME ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSupremecmd().Trim());
          sql.Append(".USRINFF ");
          sql.Append(" where USUSER = @User");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@User", _user));
          obj = cmd.ExecuteScalar();
          model.Signature = DBUtils.GetSafeString(obj);

          // License
          sql = new StringBuilder();
          sql.Append("select QALIC ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".QAUF");
          sql.Append(" where QAUSER=@UserName ");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@UserName", _user));
          obj = cmd.ExecuteScalar();
          model.LicenseNumber = DBUtils.GetSafeString(obj);

          // GVWR
          sql = new StringBuilder();
          sql.Append("select S2FFN1 ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".S1F ");
          sql.Append(" where S2SR# = @SerialNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", SerialNumber));
          obj = cmd.ExecuteScalar();
          model.GVWR = DBUtils.GetSafeString(obj);
        }
      }
      return model;
    }

    public string GetVehicleType(string _serialNumber)
    {
      object obj;
      string supremeModel = "";
      decimal OrderNumber = 0;
      string Division = "";
      string PartDesc = "";
      StringBuilder sql;

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select S1PN, S1ORD# ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".S1P ");
          sql.Append(" where S1SR#=@SerialNumber");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          // get Serial Number, Model, Order Number, and Warehouse
          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                supremeModel = DBUtils.GetSafeString(rdr["S1PN"]);
                OrderNumber = DBUtils.GetSafeDecimal(rdr["S1ORD#"]);
              }
            }
          }

          // get Sold To Customer Number
          sql = new StringBuilder();
          sql.Append("select OHDIV ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".OHP ");
          sql.Append(" where OHORD# = @OrderNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@OrderNumber", OrderNumber));
          obj = cmd.ExecuteScalar();
          Division = DBUtils.GetSafeString(obj);

          if (Division == "12")
          {
            sql = new StringBuilder();
            sql.Append("select PMDESC ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".PMP ");
            sql.Append(" where PMPART = @Model");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@Model", supremeModel));
            obj = cmd.ExecuteScalar();
            PartDesc = DBUtils.GetSafeString(obj);

            if (PartDesc.ToUpper().Contains("TROLLEY"))
              return "TROLLEY";
            else
              return "BUS";
          }
          else
          {
            return "TRUCK";
          }

        }
      }
    }

    public string GetDivision(string _serialNumber)
    {
      object obj;
      decimal OrderNumber = 0;
      string Division = "";
      StringBuilder sql;

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select S1ORD# ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".S1P ");
          sql.Append(" where S1SR#=@SerialNumber");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          obj = cmd.ExecuteScalar();
          OrderNumber = DBUtils.GetSafeDecimal(obj);

          sql = new StringBuilder();
          sql.Append("select OHDIV ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".OHP ");
          sql.Append(" where OHORD# = @OrderNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@OrderNumber", OrderNumber));
          obj = cmd.ExecuteScalar();
          Division = DBUtils.GetSafeString(obj);
        }
      }
      return Division;
    }



    public WeightSheetCaliforniaModel GetCaliforniaWeightSheet(object _bodyNumber,
                                                            object _vehicleType,
                                                            object _gross,
                                                            object _tare,
                                                            object _remarks,
                                                            string _userName)
    {
      string SerialNumber;
      if (_bodyNumber == null)
        SerialNumber = "";
      else
        SerialNumber = _bodyNumber.ToString();

      WeightSheetCaliforniaModel work = new WeightSheetCaliforniaModel();
      work = GetCaliforniaData(SerialNumber, _userName);

      WeightSheetCaliforniaModel model = new WeightSheetCaliforniaModel();

      WeightSheetFileServices db = new WeightSheetFileServices();



      model.CreateDateTime = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
      if (_vehicleType == null)
        model.VehicleType = "";
      else
        model.VehicleType = _vehicleType.ToString();
      model.WeighedBy = "WABASH NATIONAL, L.P.";
      model.SupremeLocation = work.SupremeLocation;

      model.SupremeBodyNumber = SerialNumber;
      model.Commodity = work.Commodity;
      model.GVWR = work.GVWR;
      if (_gross == null)
        model.Gross = "0";
      else
        model.Gross = _gross.ToString();
      if (_tare == null)
        model.Tare = "";
      else
        model.Tare = _tare.ToString();
      model.VIN = work.VIN;
      model.CustomerName = work.CustomerName.Trim();
      model.CustomerAddress1 = work.CustomerAddress1.Trim();
      model.CustomerAddress2 = work.CustomerAddress2.Trim();
      model.NumberOfUnits = "1";
      if (_remarks == null)
        model.Remarks = "";
      else
        model.Remarks = _remarks.ToString();


      model.DocumentSerial = db.GetNextDocumentNumber(work.Division, model.SupremeBodyNumber, model.Remarks);

      // 11/11/2013 TD
      // changed per Mark Elion
      //model.Weighmaster = "Ron Sloban";
      //model.DeputyWeighmaster = work.DeputyWeighmaster;

      model.Weighmaster = "Supreme Truck Bodies of California";
      model.DeputyWeighmaster = "Ron Sloban";

      model.Division = work.Division;
      return model;
    }

    private WeightSheetCaliforniaModel GetCaliforniaData(string _serialNumber, string _user)
    {
      WeightSheetCaliforniaModel model = new WeightSheetCaliforniaModel();
      StringBuilder sql = new StringBuilder();
      object obj;
      string SerialNumber = "";
      string Commodity = "";
      decimal OrderNumber = 0;
      string Vin = "";
      string Division = "";
      string OverrideShip = "";
      string ShipTo = "";

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select S1SR#, S1PN, S1ORD#, S1VIN# ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".S1P ");
          sql.Append(" where S1SR#=@SerialNumber");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          // get Serial Number, Model, Order Number, and Warehouse
          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                SerialNumber = DBUtils.GetSafeString(rdr["S1SR#"]);
                Commodity = DBUtils.GetSafeString(rdr["S1PN"]);
                OrderNumber = DBUtils.GetSafeDecimal(rdr["S1ORD#"]);
                Vin = DBUtils.GetSafeString(rdr["S1VIN#"]);
              }
              model.Commodity = Commodity;
              model.VIN = Vin;
            }
          }

          // get Sold To Customer Number
          sql = new StringBuilder();
          sql.Append("select OHDIV, OHOVSW, OHSTKY ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".OHP ");
          sql.Append(" where OHORD# = @OrderNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@OrderNumber", OrderNumber));
          //obj = cmd.ExecuteScalar();
          //Division = DBUtils.GetSafeString(obj);

          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                Division = DBUtils.GetSafeString(rdr["OHDIV"]);
                OverrideShip = DBUtils.GetSafeString(rdr["OHOVSW"]);
                ShipTo = DBUtils.GetSafeString(rdr["OHSTKY"]);
              }
              model.Division = Division;
            }
          }

          // Supreme Location
          sql = new StringBuilder();
          sql.Append("select NFDESC ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetFRNxxx010().Trim());
          sql.Append(".NFP ");
          sql.Append(" where NFTYP = @Type ");
          sql.Append("   and NFNUMB = @Div");
          sql.Append("   and NFSUFX = @Suffix");
          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@Type", "DV"));
          cmd.Parameters.Add(new iDB2Parameter("@Div", Division));
          cmd.Parameters.Add(new iDB2Parameter("@Suffix", "3"));
          obj = cmd.ExecuteScalar();
          model.SupremeLocation = DBUtils.GetSafeString(obj);

          if (OverrideShip == "O")
          {
            sql = new StringBuilder();
            sql.Append("select ODNAME, ODADR2, ODADR5 ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".O2P ");
            sql.Append(" where O2ORD# = @OrderNumber");
            sql.Append("   and O2ITEM = @Item");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@OrderNumber", OrderNumber));
            cmd.Parameters.Add(new iDB2Parameter("@Item", ".01"));
            //obj = cmd.ExecuteScalar();
            //Division = DBUtils.GetSafeString(obj);

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model.CustomerName = DBUtils.GetSafeString(rdr["ODNAME"]);
                  model.CustomerAddress1 = DBUtils.GetSafeString(rdr["ODADR2"]).Trim();
                  string work = DBUtils.GetSafeString(rdr["ODADR5"]);
                  StringBuilder str = new StringBuilder();
                  str.Append(work.Substring(0, 18).Trim());
                  str.Append(", ");
                  str.Append(work.Substring(18, 2).Trim());
                  str.Append(" ");
                  str.Append(work.Substring(20, 10).Trim());
                  model.CustomerAddress2 = str.ToString();
                }
              }
            }
          }
          else
          {
            sql = new StringBuilder();
            sql.Append("select CMNAME, CMLNE3, CMCITY, CMST, CMZIP ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetFRNxxx010().Trim());
            sql.Append(".CM1P ");
            sql.Append(" where C1STKY  = @ShipToCustomer");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@ShipToCustomer", ShipTo));

            //obj = cmd.ExecuteScalar();
            //Division = DBUtils.GetSafeString(obj);

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model.CustomerName = DBUtils.GetSafeString(rdr["CMNAME"]);
                  model.CustomerAddress1 = DBUtils.GetSafeString(rdr["CMLNE3"]).Trim();
                  StringBuilder str = new StringBuilder();
                  str.Append(DBUtils.GetSafeString(rdr["CMCITY"]).Trim());
                  str.Append(", ");
                  str.Append(DBUtils.GetSafeString(rdr["CMST"]).Trim());
                  str.Append(" ");
                  str.Append(DBUtils.GetSafeString(rdr["CMZIP"]).Trim());
                  model.CustomerAddress2 = str.ToString();
                }
              }
            }

          }

          // Signature
          sql = new StringBuilder();
          sql.Append("select USNAME ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSupremecmd().Trim());
          sql.Append(".USRINFF ");
          sql.Append(" where USUSER = @User");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@User", _user));
          obj = cmd.ExecuteScalar();
          model.DeputyWeighmaster = DBUtils.GetSafeString(obj);


          // GVWR
          sql = new StringBuilder();
          sql.Append("select S2FFN1 ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".S1F ");
          sql.Append(" where S2SR# = @SerialNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", SerialNumber));
          obj = cmd.ExecuteScalar();
          model.GVWR = DBUtils.GetSafeString(obj);
        }
      }
      return model;
    }

  }
}