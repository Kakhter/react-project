﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class InspectionLocationService
  {
    public List<InspectionLocationModel> InspectionLocationList
    {
      get { return GetLineInspectionLocations(); }
    }

    private List<InspectionLocationModel> GetLineInspectionLocations()
    {
      StringBuilder sql = new StringBuilder();
      InspectionLocationModel model = null;
      List<InspectionLocationModel> list = new List<InspectionLocationModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select  SLID#, SLDESC ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QSLF");
            sql.Append(" where SLSTAT=@Status");
            sql.Append("   and SLLine=@Line");
            sql.Append(" order by SLID#");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
            cmd.Parameters.Add(new iDB2Parameter("@Line", "Y"));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new InspectionLocationModel();
                  model.Code = DBUtils.GetSafeString(rdr["SLID#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["SLDESC"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("InspectionLocationServices", "", "Error in GetLineInspectionLocations", ex);
        throw new ApplicationException("Get Line Inspection Locations: " + ex.Message, ex); ;
      }
      return list;
    }
  }
}