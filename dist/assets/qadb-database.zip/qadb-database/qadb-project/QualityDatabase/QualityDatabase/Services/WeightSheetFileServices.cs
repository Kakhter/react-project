﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace QualityDatabase.Services
{
  public class WeightSheetFileServices
  {

    public string GetNextDocumentNumber(string _division,
                                        string _serialNumber,
                                        string _remark)
    {
      StringBuilder sql;
      decimal MaxDocNumber = 0;
      string NextDocNumber = "";
      int result = 0;

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select MAX(WSDOC#) as maxdoc ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".WSF ");
          sql.Append(" where WSDOC# > @LowBounds");
          sql.Append("   and WSDOC# < @HighBounds");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@LowBounds", GetLowerValue(_division)));
          cmd.Parameters.Add(new iDB2Parameter("@HighBounds", GetHigherValue(_division)));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          // get Serial Number, Model, Order Number, and Warehouse
          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                MaxDocNumber = DBUtils.GetSafeDecimal(rdr["maxdoc"]);
              }
            }
          }
          if (MaxDocNumber == 0)
          {
            NextDocNumber = _division.Trim() + "000001";
          }
          else
          {
            NextDocNumber = (MaxDocNumber + 1).ToString().Trim();
          }
          sql = new StringBuilder();
          sql.Append("insert into ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".WSF (");
          sql.Append("WSDOC#, WSSR#, WSREM, WSDATE  ");
          sql.Append(") values (");
          sql.Append("@DocNumber, @SerialNumber, @Remarks, @CreateDate");
          sql.Append(")");

          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@DocNumber", NextDocNumber.Trim()));
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
          cmd.Parameters.Add(new iDB2Parameter("@Remarks", _remark.Trim()));
          cmd.Parameters.Add(new iDB2Parameter("@CreateDate", DBUtils.GetAS400Date(DateTime.Now)));

          result = cmd.ExecuteNonQuery();
          if (result == 0)
            throw new ApplicationException("Record not added, exception no thrown");
          else
            return NextDocNumber;
        }
      }
    }

    public string GetLowerValue(string _value)
    {
      return _value.Trim() + "000000";
    }

    public string GetHigherValue(string _value)
    {
      string result = "";
      int number = 0;
      if (Int32.TryParse(_value, out number))
      {
        number = number + 1;
        result = number.ToString().Trim() + "000000";
      }
      return result;
    }


  }
}