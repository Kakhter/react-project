﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
    public class DefectItemServices
    {
        public List<DefectItemModel> WaterTestItemList
        {
            get { return GetWaterTestDefectItems(); }
        }

        private List<DefectItemModel> GetWaterTestDefectItems()
        {
            StringBuilder sql = new StringBuilder();
            DefectItemModel item = null;
            List<DefectItemModel> list = new List<DefectItemModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DiID#, DiDESC ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDiF");
                        sql.Append(" where DISTAT=@Status");
                        sql.Append("   and DIWAT=@Water");
                        sql.Append(" order by DIID#");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
                        cmd.Parameters.Add(new iDB2Parameter("@Water", "Y"));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    item = new DefectItemModel();
                                    item.Code = DBUtils.GetSafeString(rdr["DIID#"]).Trim();
                                    item.Description = DBUtils.GetSafeString(rdr["DIDESC"]).Trim();
                                    list.Add(item);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("DefectItemServices", "", "Error in GetWaterTestDefectItems", ex);
                throw new ApplicationException("Get Water Test Defect Items: " + ex.Message, ex);
            }
            return list;
        }

        public List<DefectItemModel> LineInspectionItemList
        {
            get { return GetLineInspectionDefectItems(); }
        }

        private List<DefectItemModel> GetLineInspectionDefectItems()
        {
            StringBuilder sql = new StringBuilder();
            DefectItemModel item = null;
            List<DefectItemModel> list = new List<DefectItemModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT DiID#, DiDESC, DICID# ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDiF");
                        sql.Append(" where DISTAT=@Status");
                        sql.Append("   and DILINE=@Line");
                        sql.Append(" order by DIID#");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
                        cmd.Parameters.Add(new iDB2Parameter("@Line", "Y"));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    item = new DefectItemModel();
                                    item.Code = DBUtils.GetSafeString(rdr["DIID#"]).Trim();
                                    item.Description = DBUtils.GetSafeString(rdr["DIDESC"]).Trim();
                                    item.DICID = DBUtils.GetSafeString(rdr["DICID#"]).Trim();
                                    list.Add(item);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("DefectItemServices", "", "Error in GetLineInspectionDefectItems", ex);
                throw new ApplicationException("Get Line Inspection Defect Items: " + ex.Message, ex);
            }
            return list;
        }

    }
}