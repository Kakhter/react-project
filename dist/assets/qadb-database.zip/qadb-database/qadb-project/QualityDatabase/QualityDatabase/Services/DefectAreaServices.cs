﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
    public class DefectAreaServices
    {
        public List<DefectAreaModel> WaterTestAreaList
        {
            get { return GetWaterTestDefectAreas(); }
        }

        private List<DefectAreaModel> GetWaterTestDefectAreas()
        {
            StringBuilder sql = new StringBuilder();
            DefectAreaModel area = null;
            List<DefectAreaModel> list = new List<DefectAreaModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT DAID#, DADESC");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDAF");
                        sql.Append(" where DASTAT=@Status");
                        sql.Append("   and DAWATER=@Water");
                        sql.Append(" order by DAID#");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
                        cmd.Parameters.Add(new iDB2Parameter("@Water", "Y"));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    area = new DefectAreaModel();
                                    area.Code = DBUtils.GetSafeString(rdr["DAID#"]).Trim();
                                    area.Description = DBUtils.GetSafeString(rdr["DADESC"]).Trim();
                                    list.Add(area);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("DefectAreaServices", "", "Error in GetWaterTestDefectAreas", ex);
                throw new ApplicationException("Get Water Test Defect Areas: " + ex.Message, ex);
            }
            return list;
        }

        public List<DefectAreaModel> LineInspectionAreaList
        {
            get { return GetLineInspectionDefectAreas(); }
        }

        private List<DefectAreaModel> GetLineInspectionDefectAreas()
        {
            StringBuilder sql = new StringBuilder();
            DefectAreaModel area = null;
            List<DefectAreaModel> list = new List<DefectAreaModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT DAID#, DADESC ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QDAF");
                        sql.Append(" where DASTAT=@Status");
                        sql.Append("   and DALINE=@Line");
                        sql.Append(" order by DAID#");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
                        cmd.Parameters.Add(new iDB2Parameter("@Line", "Y"));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    area = new DefectAreaModel();
                                    area.Code = DBUtils.GetSafeString(rdr["DAID#"]).Trim();
                                    area.Description = DBUtils.GetSafeString(rdr["DADESC"]).Trim();
                                    list.Add(area);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("DefectAreaServices", "", "Error in GetLineInspectionDefectAreas", ex);
                throw new ApplicationException("Get Line Inspection Defect Areas: " + ex.Message, ex);
            }
            return list;
        }

    }
}