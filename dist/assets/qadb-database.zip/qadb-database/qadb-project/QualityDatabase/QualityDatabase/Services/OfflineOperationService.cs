﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class OfflineOperationService
  {
    public List<OfflineOperationModel> OfflineOperationList
    {
      get { return GetOfflineOperations(); }
    }

    private List<OfflineOperationModel> GetOfflineOperations()
    {
      StringBuilder sql = new StringBuilder();
      OfflineOperationModel model = null;
      List<OfflineOperationModel> list = new List<OfflineOperationModel>();

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("select LOID#, LODESC ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QLOF");
            sql.Append(" where LOSTAT=@Status");
            sql.Append(" order by LOID#");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new OfflineOperationModel();
                  model.Code = DBUtils.GetSafeString(rdr["LOID#"]).Trim();
                  model.Description = DBUtils.GetSafeString(rdr["LODESC"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("OfflineOperationServices", "", "Error in GetOfflineOperations", ex);
        throw new ApplicationException("Get Offline Operations: " + ex.Message, ex);
      }
      return list;
    }
  }
}