﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using System;
using System.Text;

namespace QualityDatabase.Services
{
  public class WaterTestLogServices
  {
    // This function is used to update the log when creating or updating 
    // a water test record
    public string UpdateLog(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            sql = new StringBuilder();
            sql.Append("Select count(*) from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTF  ");
            sql.Append(" where QWSR#=@SerialNumber ");
            sql.Append("   and QWIDTE=@WaterTestCreateDate ");
            sql.Append("   and QWTIME=@WaterTestCreateTime ");

            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _createDate));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _createTime));

            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            result = DBUtils.GetSafeInteger(cmd.ExecuteScalar());

            if (result == 1)
            {
              sql = new StringBuilder();
              sql.Append("Insert into ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QWTLF ");
              sql.Append("(LWSR#, LWDA, LWDI, LWDT,  ");
              sql.Append("LWWP, LWGM, LWITYP, LWIDTE,  ");
              sql.Append("LWTIME, LWDATE, LWUSER, LWRI,  ");
              sql.Append("LWRA, LWRDTE, LWRTIME, LWRDATE,  ");
              sql.Append("LWRUSER, LWTEXT) "); //added by Khalid#2
              sql.Append("select QWSR#, QWDA, QWDI, QWDT,  ");
              sql.Append("QWWP, QWGM, QWITYP, QWIDTE,  ");
              sql.Append("QWTIME, QWDATE, QWUSER, QWRI,  ");
              sql.Append("QWRA, QWRDTE, QWRTIME, QWRDATE,  ");
              sql.Append("QWRUSER, QWTEXT "); //added by Khalid#2
              sql.Append("from ");
              sql.Append(DBUtils.GetSUPxxx010().Trim());
              sql.Append(".QWTF ");
              sql.Append("where QWSR#=@SerialNumber ");
              sql.Append("  and QWIDTE=@CreateDate ");
              sql.Append("  and QWTIME=@CreateTime  ");

              cmd.Parameters.Clear();
              cmd.CommandText = sql.ToString();
              cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _createDate));
              cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _createTime));

              result = cmd.ExecuteNonQuery();
              if (result == 0)
                throw new ApplicationException("Water Test Log not updated, no exception thrown");
              else
                return "";
            }
            else
            {
              StringBuilder msg = new StringBuilder();
              msg.Append("Update Water Test Log: Invalid parameters - ");
              msg.Append(_serialNumber);
              msg.Append(", ");
              msg.Append(_createDate);
              msg.Append(", ");
              msg.Append(_createTime);
              throw new ApplicationException(msg.ToString());
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestLogServices", "", "Error in UpdateLog", ex);
        throw new ApplicationException("Update Water Test Log: " + ex.Message, ex);
      }
    }

    // This function is used to update the log when deleting 
    // a water test record
    public string UpdateLogWithDelete(string _serialNumber, string _createDate, string _createTime)
    {
      StringBuilder sql = new StringBuilder();
      int result = 0;
      DateTime CreateDateTime = DateTime.Now;

      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            // All fields are blank except serial number and create date and time
            // This indicates that the record was deleted.
            sql = new StringBuilder();
            sql.Append("Insert into ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QWTLF ");
            sql.Append("(LWSR#, LWIDTE, LWTIME) ");
            sql.Append("values ");
            sql.Append("(@SerialNumber, @WaterTestCreateDate, @WaterTestCreateTime)");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber.Trim()));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateDate", _createDate));
            cmd.Parameters.Add(new iDB2Parameter("@WaterTestCreateTime", _createTime));

            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Water Test Log not updated, no exception thrown");
            else
              return "";
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WaterTestLogServices", "", "Error in UpdateLogWithDelete", ex);
        throw new ApplicationException("Update Water Test Log with Delete: " + ex.Message, ex);
      }
    }

  }
}