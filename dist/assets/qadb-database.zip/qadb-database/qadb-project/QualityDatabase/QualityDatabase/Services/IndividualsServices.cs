﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace QualityDatabase.Services
{
  public class IndividualsServices
  {
    public string Division { get; set; }
 
    public IndividualsServices(string _division)
    {
      Division = _division;
    }

    public List<IndividualsModel> IndividualsList
    {
      get { return GetActiveIndividuals(); }
    }

    private List<IndividualsModel> GetActiveIndividuals()
    {
      StringBuilder sql = new StringBuilder();
      IndividualsModel model = null;
      List<IndividualsModel> list = new List<IndividualsModel>();


      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            sql = new StringBuilder();
            sql.Append("select IIID#, IINAME ");
            sql.Append(" from ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".QIIF");
            sql.Append(" where IISTAT=@Status ");
            sql.Append("   and IIBUILD = @Division ");
            sql.Append(" order by IINAME");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
            cmd.Parameters.Add(new iDB2Parameter("@Division", Division));

            using (var rdr = cmd.ExecuteReader())
            {
              if (rdr.HasRows == true)
              {
                while (rdr.Read())
                {
                  model = new IndividualsModel();
                  model.NameID = DBUtils.GetSafeString(rdr["IIID#"]).Trim();
                  model.Name = DBUtils.GetSafeString(rdr["IINAME"]).Trim();
                  list.Add(model);
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("IndividualsServices", "", "Error in GetActiveIndividuals", ex);
        throw new ApplicationException("Get Active Individuals: " + ex.Message, ex);
      }
      return list;
    }


    
  }
}