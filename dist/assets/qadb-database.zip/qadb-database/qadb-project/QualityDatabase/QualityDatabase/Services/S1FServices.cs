﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Text;

namespace QualityDatabase.Services
{
  public class S1FServices
  {
    public S1FModel GetS1FData(string _serialNumber)
    {
      StringBuilder sql;
      S1FModel model = new S1FModel();

      using (var cn = new iDB2Connection())
      {
        using (var cmd = cn.CreateCommand())
        {
          sql = new StringBuilder();
          sql.Append("select S2WFA, S2TVW, S2WRA ");
          sql.Append(" from ");
          sql.Append(DBUtils.GetSUPxxx010().Trim());
          sql.Append(".S1F ");
          sql.Append(" where S2SR# = @SerialNumber");

          cmd.Parameters.Clear();
          cmd.CommandText = sql.ToString();
          cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

          cn.ConnectionString = DBUtils.GetAS400ConnectionString();
          cn.Open();

          using (var rdr = cmd.ExecuteReader())
          {
            if (rdr.HasRows == true)
            {
              while (rdr.Read())
              {
                model.WeightFrontAxle = DBUtils.GetSafeString(rdr["S2WFA"]);
                model.WeightRearAxle = DBUtils.GetSafeString(rdr["S2WRA"]);
                model.VehicleWeight = DBUtils.GetSafeString(rdr["S2TVW"]);
              }
            }
          }

        }
      }
      return model;
    }

    public void Update(string _serialNumber, S1FModel _model)
    {
      StringBuilder sql;
      int result = 0;
      try
      {
        using (var cn = new iDB2Connection())
        {
          using (var cmd = cn.CreateCommand())
          {
            cn.ConnectionString = DBUtils.GetAS400ConnectionString();
            cn.Open();

            sql = new StringBuilder();
            sql.Append("Update ");
            sql.Append(DBUtils.GetSUPxxx010().Trim());
            sql.Append(".S1F ");
            sql.Append(" set ");
            sql.Append(" S2WFA = @WeightFrontAxle, ");
            sql.Append(" S2WRA = @WeightRearAxle, ");
            sql.Append(" S2TVW = @VehicleWeight ");
            sql.Append(" where S2SR# = @SerialNumber");

            cmd.Parameters.Clear();
            cmd.CommandText = sql.ToString();
            cmd.Parameters.Add(new iDB2Parameter("@WeightFrontAxle", _model.WeightFrontAxle));
            cmd.Parameters.Add(new iDB2Parameter("@WeightRearAxle", _model.WeightRearAxle));
            cmd.Parameters.Add(new iDB2Parameter("@VehicleWeight", _model.VehicleWeight));
            cmd.Parameters.Add(new iDB2Parameter("@SerialNumber", _serialNumber));

            result = cmd.ExecuteNonQuery();
            if (result == 0)
              throw new ApplicationException("Update S1F: Record not updated, no exception thrown");
          }
        }
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("S1FServices", "", "Error in Update", ex);
        throw new ApplicationException("Update S1F: " + ex.Message, ex);
      }

    }
  }
}