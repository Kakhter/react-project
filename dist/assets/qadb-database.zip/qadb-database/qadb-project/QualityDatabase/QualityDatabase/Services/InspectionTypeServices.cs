﻿using IBM.Data.DB2.iSeries;
using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Text;


namespace QualityDatabase.Services
{
    public class InspectionTypeServices
    {
        public List<InspectionTypeModel> WaterTestInspectionTypeList
        {
            get { return GetWaterTestInspectionTypes(); }
        }

        private List<InspectionTypeModel> GetWaterTestInspectionTypes()
        {
            StringBuilder sql = new StringBuilder();
            InspectionTypeModel type = null;
            List<InspectionTypeModel> list = new List<InspectionTypeModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select ITID#, ITDESC ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QITF");
                        sql.Append(" where ITSTAT=@Status");
                        sql.Append("   and ITWATER=@Water");
                        sql.Append(" order by ITID#");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
                        cmd.Parameters.Add(new iDB2Parameter("@Water", "Y"));
                        cmd.Parameters.Add(new iDB2Parameter("@INIT", "INIT"));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    type = new InspectionTypeModel();
                                    type.Code = DBUtils.GetSafeString(rdr["ITID#"]).Trim();
                                    type.Description = DBUtils.GetSafeString(rdr["ITDESC"]).Trim();
                                    list.Add(type);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("InspectionTypeServices", "", "Error in GetWaterTestInspectionType", ex);
                throw new ApplicationException("Get Water Test Inspection Types: " + ex.Message, ex);
            }
            return list;
        }

        public List<InspectionTypeModel> LineInspectionInspectionTypeList
        {
            get { return GetLineInspectionInspectionTypes(); }
        }

        private List<InspectionTypeModel> GetLineInspectionInspectionTypes()
        {
            StringBuilder sql = new StringBuilder();
            InspectionTypeModel type = null;
            List<InspectionTypeModel> list = new List<InspectionTypeModel>();

            try
            {
                using (var cn = new iDB2Connection())
                {
                    using (var cmd = cn.CreateCommand())
                    {
                        sql = new StringBuilder();
                        sql.Append("select DISTINCT ITID#, ITDESC ");
                        sql.Append(" from ");
                        sql.Append(DBUtils.GetSUPxxx010().Trim());
                        sql.Append(".QITF");
                        sql.Append(" where ITSTAT=@Status");
                        sql.Append("   and ITLINE=@Line and ITID# = @ITID");
                        sql.Append(" order by ITID#");

                        cmd.CommandText = sql.ToString();
                        cmd.Parameters.Add(new iDB2Parameter("@Status", "A"));
                        cmd.Parameters.Add(new iDB2Parameter("@Line", "Y"));
                        //This filter was added per user request from testing on qadb udpate with Jared and Colven.
                        cmd.Parameters.Add(new iDB2Parameter("@ITID", "INIT"));

                        cn.ConnectionString = DBUtils.GetAS400ConnectionString();
                        cn.Open();

                        using (var rdr = cmd.ExecuteReader())
                        {
                            if (rdr.HasRows == true)
                            {
                                while (rdr.Read())
                                {
                                    type = new InspectionTypeModel();
                                    type.Code = DBUtils.GetSafeString(rdr["ITID#"]).Trim();
                                    type.Description = DBUtils.GetSafeString(rdr["ITDESC"]).Trim();
                                    list.Add(type);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.Log("InspectionTypeServices", "", "Error in GetLineInspectionInspectionTypes", ex);
                throw new ApplicationException("Get Line Inspection Inspection Types: " + ex.Message, ex);
            }
            return list;
        }
    }
}