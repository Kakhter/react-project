﻿using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class TireTagModel
  {
    [DisplayFormat(DataFormatString = "{0:#####}")]
    [Display(Name = "GVRW")]
    public int GVRW { get; set; }

    [DisplayFormat(DataFormatString = "{0:#####}")]
    [Display(Name = "Vehicle Weight")]
    public int VehicleWeight { get; set; }

    [Display(Name = "Fuel Type")]
    public string FuelType { get; set; }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Tank Size")]
    public double TankSize { get; set; }

    [DisplayFormat(DataFormatString = "{0:##}")]
    [Display(Name = "Front Seat Capacity")]
    public double FrontSeatCapacity { get; set; }

    [DisplayFormat(DataFormatString = "{0:##}")]
    [Display(Name = "Rear Seat Capacity")]
    public double RearSeatCapacity { get; set; }

    [DisplayFormat(DataFormatString = "{0:#####}")]
    [Display(Name = "Vehicle Capacity lbs")]
    public int VehicleCapacitylbs { get; set; }

    [DisplayFormat(DataFormatString = "{0:#####}")]
    [Display(Name = "Vehicle Capacity kg")]
    public int VehicleCapacitykg { get; set; }

    public string SerialNumber { get; set; }
    public string TireCreateDate { get; set; }
    public string TireCreateTime { get; set; }
    public string TireCreatedBy { get; set; }

    public TireTagModel()
    {
      GVRW = 0;
      VehicleWeight = 0;
      FuelType = "";
      TankSize = 0;
      FrontSeatCapacity = 0;
      RearSeatCapacity = 0;
      VehicleCapacitylbs = 0;
      VehicleCapacitykg = 0;
      SerialNumber = "";
      TireCreateDate = "";
      TireCreateTime = "";
      TireCreatedBy = "";

    }
    public void ReplaceNulls()
    {

      if (FuelType == null)
        FuelType = "";

      if (SerialNumber == null)
        SerialNumber = "";

      if (TireCreateDate == null)
        TireCreateDate = "";

      if (TireCreateTime == null)
        TireCreateTime = "";

      if (TireCreatedBy == null)
        TireCreatedBy = "";
    }

  }
}