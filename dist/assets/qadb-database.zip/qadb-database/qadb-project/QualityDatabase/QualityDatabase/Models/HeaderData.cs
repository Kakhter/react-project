﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class HeaderData
  {
    [Display(Name = "Serial Number:")]
    public string SerialNumber { get; set; }

    [Display(Name = "Model:")]
    public string Model { get; set; }

    [Display(Name = "Order Number")]
    public string OrderNumber { get; set; }

    [Display(Name = "Customer")]
    public string CustomerName { get; set; }

    [Display(Name = "Warehouse")]
    public string Warehouse { get; set; }

    [Display(Name = "Line Built On")]
    public string Line { get; set; }

    [Display(Name = "200 Date")]
    public string Date200 { get; set; }

    [Display(Name = "900 Date")]
    public string Date900 { get; set; }

    [Display(Name = "On Hold")]
    public string OnHold { get; set; }

    public HeaderData()
    {
      SerialNumber = "";
      Model = "";
      OrderNumber = "";
      CustomerName = "";
      Warehouse = "";
      Line = "";
      Date200 = "";
      Date900 = "";
      OnHold = "";
    }
  }
}