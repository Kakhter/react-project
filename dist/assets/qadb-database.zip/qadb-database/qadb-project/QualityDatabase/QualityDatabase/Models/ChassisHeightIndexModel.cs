﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class ChassisHeightIndexModel
  {
    [DisplayFormat(DataFormatString = "{0:##.###}")]
    public double PriorSS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    public double PriorCS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    public double AfterMountSS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    public double AfterMountCS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    public double AfterTestSS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    public double AfterTestCS { get; set; }


    public string SerialNumber { get; set; }

    public ChassisHeightIndexModel()
    {
      PriorSS = 0;
      PriorCS = 0;
      AfterMountSS = 0;
      AfterMountCS = 0;
      AfterTestSS = 0;
      AfterTestCS = 0;
    }
  }
}