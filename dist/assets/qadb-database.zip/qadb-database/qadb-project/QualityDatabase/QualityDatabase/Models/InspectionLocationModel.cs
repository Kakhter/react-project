﻿namespace QualityDatabase.Models
{
  public class InspectionLocationModel
  {
    public string Code { get; set; }
    public string Description { get; set; }

    public InspectionLocationModel()
    {
      Code = "";
      Description = "";
    }
  }
}