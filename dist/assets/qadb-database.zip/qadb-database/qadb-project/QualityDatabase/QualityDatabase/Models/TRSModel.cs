﻿using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class TRSModel
  {
    public string S1ORD { get; set; }
    public string M2ON { get; set; }

    [Display(Name = "Operation")]
    public string M2SEQ { get; set; }

    [Display(Name = "Report Date")]
    public string ML2LP { get; set; }
    public string M3PN { get; set; }

    [Display(Name = "Desc")]
    public string PMDESC { get; set; }

    public TRSModel()
    {
      S1ORD = "";
      M2ON = "";
      M2SEQ = "";
      ML2LP = "";
      M3PN = "";
      PMDESC = "";
    }
  }
}