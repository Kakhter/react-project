﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class GVRWModel
  {
    [DisplayFormat(DataFormatString = "{0:#####}")]
    [Display(Name = "GVRW")]
    public int GVRW { get; set; }

    public GVRWModel()
    {
      GVRW = 0;
    }
  }
}