﻿namespace QualityDatabase.Models
{
    public class DefectAreaModel
    {
        public string Code { get; set; }
        public string Description { get; set; }

        public DefectAreaModel()
        {
            Code = "";
            Description = "";
        }
    }
}