﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace QualityDatabase.Models
{
    public class LineInspectionBatchModel
    {
        public List<LineInspectionModel> LineInspectionBatch { get; set; }
    }
    public class LineInspectionModel
    {
        [Display(Name = "Date")]
        [DataType(DataType.Date)]
        public DateTime InspectionDate { get; set; }

        [Display(Name = "Quality Station")]
        public string InspectionLocation { get; set; }

        [Display(Name = "Inspector")]
        public string Inspector { get; set; }

        [Display(Name = "Sequence")]
        public string InspectionType { get; set; }

        [Display(Name = "Area")]
        public string DefectArea { get; set; }

        [Display(Name = "Area Desc")]
        public string AreaDesc { get; set; }

        [Display(Name = "Item")]
        public string DefectItem { get; set; }

        [Display(Name = "Item Desc")]
        public string ItemDesc { get; set; }

        [Display(Name = "Type")]
        public string DefectType { get; set; }

        [Display(Name = "Type Desc")]
        public string TypeDesc { get; set; }

        [Display(Name = "Condition")]
        public string DefectCondition { get; set; }

        [Display(Name = "Condition Desc")]
        public string ConditionDesc { get; set; }

        [Display(Name = "Serial #")]
        public string SerialNumber { get; set; }

        [Display(Name = "Inspection Create Date")]
        public string InspectionCreateDate { get; set; }

        [Display(Name = "Inspection Create Time")]
        public string InspectionCreateTime { get; set; }

        [Display(Name = "Inspection Created By")]
        public string InspectionCreatedBy { get; set; }

        [Display(Name = "Repair Action")]
        public string RepairAction { get; set; }

        [Display(Name = "Repair Time in Minutes")]
        public int RepairTimeMinutes { get; set; }

        [Display(Name = "Repair Create Date")]
        public string RepairCreateDate { get; set; }

        [Display(Name = "Repair Create Time")]
        public string RepairCreateTime { get; set; }

        [Display(Name = "Repair Created By")]
        public string RepairCreatedBy { get; set; }

        [Display(Name = "Offline Operation")]
        public string OfflineOperation { get; set; }

        [Display(Name = "Offline Description")]
        public string OfflineDescription { get; set; }
        
        [Display(Name = "Pass Fail")]
        public string PassFail { get; set; }
        public string originalDefectArea { get; set; }
        public string originalDefectType { get; set; }
        public string originalDefectCondition { get; set; }
        public string originalDefectItem { get; set; }
        public string ReasonForFailure { get; set; }
        public LineInspectionModel()
        {
            InspectionLocation = "";
            Inspector = "";
            InspectionType = "";
            DefectArea = "";
            DefectItem = "";
            DefectType = "";
            DefectCondition = "";
            SerialNumber = "";
            InspectionCreateDate = "";
            InspectionCreateTime = "";
            InspectionCreatedBy = "";
            RepairAction = "";
            RepairTimeMinutes = 0;
            RepairCreateTime = "";
            RepairCreateDate = "";
            RepairCreatedBy = "";
            OfflineOperation = "";
            OfflineDescription = "";
            PassFail = "";
            originalDefectArea = "";
            originalDefectType = "";
            originalDefectCondition = "";
            originalDefectItem = "";
            ReasonForFailure = "";

        }

        public void ResetNullValues()
        {
            if (InspectionLocation == null)
                InspectionLocation = "";

            if (Inspector == null)
                Inspector = "";

            if (InspectionType == null)
                InspectionType = "";

            if (DefectArea == null)
                DefectArea = "";

            if (DefectItem == null)
                DefectItem = "";

            if (DefectType == null)
                DefectType = "";

            if (DefectCondition == null)
                DefectCondition = "";

            if (originalDefectArea == null)
                originalDefectArea = "";

            if (originalDefectItem == null)
                originalDefectItem = "";

            if (originalDefectType == null)
                originalDefectType = "";

            if (originalDefectCondition == null)
                originalDefectCondition = "";

            if (SerialNumber == null)
                SerialNumber = "";

            if (InspectionCreateDate == null)
                InspectionCreateDate = "";

            if (InspectionCreateTime == null)
                InspectionCreateTime = "";

            if (InspectionCreatedBy == null)
                InspectionCreatedBy = "";

            if (RepairAction == null)
                RepairAction = "";

            if (RepairCreateTime == null)
                RepairCreateTime = "";

            if (RepairCreateDate == null)
                RepairCreateDate = "";

            if (RepairCreatedBy == null)
                RepairCreatedBy = "";

            if (OfflineOperation == null)
                OfflineOperation = "";

            if (PassFail == null)
                PassFail = "";
        }

    }

}