﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class FuelModel
  {
    [Display(Name = "Fuel Type")]
    public string FuelType { get; set; }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Gallons of Fuel")]
    public double GallonsOfFuel { get; set; }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Price per Gallon")]
    public double PricePerGallon { get; set; }

    public string SerialNumber { get; set; }
    public string FuelCreateDate { get; set; }
    public string FuelCreateTime { get; set; }
    public string FuelCreatedBy { get; set; }

    public FuelModel()
    {
      FuelType = "";
      GallonsOfFuel = 0;
      PricePerGallon = 0;
      SerialNumber = "";
      FuelCreateDate = "";
      FuelCreateTime = "";
      FuelCreatedBy = "";
    }

    public void ReplaceNulls()
    {

      if (FuelType == null)
        FuelType = "";

      if (SerialNumber == null)
        SerialNumber = "";

      if (FuelCreateDate == null)
        FuelCreateDate = "";

      if (FuelCreateTime == null)
        FuelCreateTime = "";

      if (FuelCreatedBy == null)
        FuelCreatedBy = "";
    }
  }
}