﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class LineRepairModel
  {
    [Display(Name = "Repair Action")]
    public string RepairAction { get; set; }

    [Display(Name = "Repair Action Desc")]
    public string RepairActionDesc { get; set; }

    [Display(Name = "Repair Time in Minutes")]
    public int RepairTimeMinutes { get; set; }

    [Display(Name = "Repair Create Date")]
    public string RepairCreateDate { get; set; }

    [Display(Name = "Repair Create Time")]
    public string RepairCreateTime { get; set; }

    [Display(Name = "Repair Created By")]
    public string RepairCreatedBy { get; set; }

    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Inspection Create Date")]
    public string InspectionCreateDate { get; set; }

    [Display(Name = "Inspection Create Time")]
    public string InspectionCreateTime { get; set; }

    public LineRepairModel()
    {
      RepairAction = "";
      RepairTimeMinutes = 0;
      RepairCreateDate = "";
      RepairCreateTime = "";
      RepairCreatedBy = "";
      SerialNumber = "";
      InspectionCreateDate = "";
      InspectionCreateTime = "";
    }

    public void ResetNullValues()
    {
      if (RepairAction == null)
        RepairAction = "";

      if (RepairCreateDate == null)
        RepairCreateDate = "";

      if (RepairCreateTime == null)
        RepairCreateTime = "";

      if (RepairCreatedBy == null)
        RepairCreatedBy = "";

      if (SerialNumber == null)
        SerialNumber = "";

      if (InspectionCreateDate == null)
        InspectionCreateDate = "";

      if (InspectionCreateTime == null)
        InspectionCreateTime = "";
    }
  }
}