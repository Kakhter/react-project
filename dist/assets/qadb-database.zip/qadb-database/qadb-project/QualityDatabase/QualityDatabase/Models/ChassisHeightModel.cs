﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class ChassisHeightModel
  {
    public double PriorSS { get; set; }
    public double PriorCS { get; set; }
    public double AfterMountSS { get; set; }
    public double AfterMountCS { get; set; }
    public double AfterTestSS { get; set; }
    public double AfterTestCS { get; set; }
    public string SerialNumber { get; set; }
    public string ChassisRailCreateDate { get; set; }
    public string ChassisRailCreateTime { get; set; }
    public string ChassisRailCreatedBy { get; set; }

    public ChassisHeightModel()
    {
      PriorSS = 0;
      PriorCS = 0;
      AfterMountSS = 0;
      AfterMountCS = 0;
      AfterTestSS = 0;
      AfterTestCS = 0;
      SerialNumber = "";
      ChassisRailCreateDate = "";
      ChassisRailCreateTime = "";
      ChassisRailCreatedBy = "";
    }

    public void ReplaceNulls()
    {
      if (SerialNumber == null)
        SerialNumber = "";

      if (ChassisRailCreateDate == null)
        ChassisRailCreateDate = "";

      if (ChassisRailCreateTime == null)
        ChassisRailCreateTime = "";

      if (ChassisRailCreatedBy == null)
        ChassisRailCreatedBy = "";

    }
  }
}