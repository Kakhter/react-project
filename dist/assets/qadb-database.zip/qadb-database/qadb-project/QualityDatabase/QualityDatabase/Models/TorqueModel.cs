﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class TorqueModel
  {
    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [DisplayFormat(DataFormatString = "{0:##}")]
    [Display(Name = "Ubolt Number")]
    public double UboltNumber { get; set; }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Ubolt Street Side")]
    public double UboltStreetSide { get; set; }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Ubolt Curb Side")]
    public double UboltCurbSide { get; set; }

    [Display(Name = "Inspector")]
    public string Inspector { get; set; }

    [Display(Name = "Torque Create Date")]
    public string TorqueCreateDate { get; set; }

    [Display(Name = "Torque Create Time")]
    public string TorqueCreateTime { get; set; }

    [Display(Name = "Torque Created By")]
    public string TorqueCreatedBy { get; set; }

    public string FullName { get; set; }

    public TorqueModel()
    {
      SerialNumber = "";
      UboltNumber = 0;
      UboltStreetSide = 0;
      UboltCurbSide = 0;
      Inspector = "";
      TorqueCreateDate = "";
      TorqueCreateTime = "";
      TorqueCreatedBy = "";
      FullName = "";
    }

    public void ResetNullValues()
    {
      if (SerialNumber == null)
        SerialNumber = "";

      if (Inspector == null)
        Inspector = "";

      if (TorqueCreateDate == null)
        TorqueCreateDate = "";

      if (TorqueCreateTime == null)
        TorqueCreateTime = "";

      if (TorqueCreatedBy == null)
        TorqueCreatedBy = "";
    }
  }
}