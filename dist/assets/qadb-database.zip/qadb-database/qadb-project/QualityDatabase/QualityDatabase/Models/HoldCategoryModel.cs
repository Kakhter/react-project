﻿namespace QualityDatabase.Models
{
  public class HoldCategoryModel
  {
    public string Code { get; set; }
    public string Description { get; set; }

    public HoldCategoryModel()
    {
      Code = "";
      Description = "";
    }
  }
}