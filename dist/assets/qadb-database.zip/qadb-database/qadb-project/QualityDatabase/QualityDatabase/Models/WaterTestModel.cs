﻿using System;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class WaterTestModel
  {
    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Area")]
    public string DefectArea { get; set; }

    [Display(Name = "Item")]
    public string DefectItem { get; set; }

    [Display(Name = "Type")]
    public string DefectType { get; set; }

    [Display(Name = "Pressure")]
    public string WaterPressure { get; set; }

    [Display(Name = "Gal/Min")]
    public string GallonsPerMinute { get; set; }

    [Display(Name = "Sequence")]
    public string InspectionType { get; set; }

    [Display(Name = "Water Test Create Date")]
    public string WaterTestCreateDate { get; set; }

    [Display(Name = "Water Test Create Time")]
    public string WaterTestCreateTime { get; set; }

    [Display(Name = "Water Test Date")]
    [DataType(DataType.Date)]
    public DateTime WaterTestDate { get; set; }

    [Display(Name = "Water Test Created By")]
    public string WaterTestCreatedBy { get; set; }

    [Display(Name = "Repair Item")]
    public string RepairItem { get; set; }

    [Display(Name = "Repair Action")]
    public string RepairAction { get; set; }

    [Display(Name = "Repair Create Time")]
    public string RepairCreateTime { get; set; }

    [Display(Name = "Repair Create Date")]
    public string RepairCreateDate { get; set; }

    [Display(Name = "Repair Date")]
    public string RepairDate { get; set; }

    [Display(Name = "Repair Created By")]
    public string RepairCreatedBy { get; set; }

    [Display(Name = "Category")]
    public string Category { get; set; } //added by Khalid#2


        public WaterTestModel()
    {
      SerialNumber = "";
      DefectArea = "";
      DefectItem = "";
      DefectType = "";
      WaterPressure = "";
      GallonsPerMinute = "";
      InspectionType = "";
      WaterTestCreateTime = "";
      WaterTestCreateDate = "";
      WaterTestDate = DateTime.Today;
      WaterTestCreatedBy = "";
      RepairItem = "";
      RepairAction = "";
      RepairCreateTime = "";
      RepairCreateDate = "";
      RepairDate = "";
      RepairCreatedBy = "";
      Category = ""; //added by Khalid#2
    }

    public void ResetNullValues()
    {
      if (SerialNumber == null)
        SerialNumber = "";

      if (DefectArea == null)
        DefectArea = "";

      if (DefectItem == null)
        DefectItem = "";

      if (DefectType == null)
        DefectType = "";

      if (WaterPressure == null)
        WaterPressure = "0";

      if (GallonsPerMinute == null)
        GallonsPerMinute = "0";

      if (InspectionType == null)
        InspectionType = "";

      if (WaterTestCreateTime == null)
        WaterTestCreateTime = "";

      if (WaterTestCreateDate == null)
        WaterTestCreateDate = "";

      if (WaterTestCreatedBy == null)
        WaterTestCreatedBy = "";

      if (RepairItem == null)
        RepairItem = "";

      if (RepairAction == null)
        RepairAction = "";

      if (RepairCreateTime == null)
        RepairCreateTime = "";

      if (RepairCreateDate == null)
        RepairCreateDate = "";

      if (RepairDate == null)
        RepairDate = "";

      if (RepairCreatedBy == null)
        RepairCreatedBy = "";
      
      if (Category == null)
          Category = "";
    }
  }
}