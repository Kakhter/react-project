﻿namespace QualityDatabase.Models
{
  public class RepairActionModel
  {
    public string Code { get; set; }
    public string Description { get; set; }

    public RepairActionModel()
    {
      Code = "";
      Description = "";
    }
  }
}