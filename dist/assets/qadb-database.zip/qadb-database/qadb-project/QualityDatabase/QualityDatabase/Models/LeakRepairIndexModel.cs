﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class LeakRepairIndexModel
  {
    [Display(Name = "Date")]
    public string InspectionDate { get; set; }

    [Display(Name = "Area Desc")]
    public string AreaDesc { get; set; }

    [Display(Name = "Item Desc")]
    public string ItemDesc { get; set; }

    [Display(Name = "Type Desc")]
    public string TypeDesc { get; set; }

    [Display(Name = "Repair Date")]
    public string RepairDate { get; set; }

    [Display(Name = "Action")]
    public string RepairAction { get; set; }

    [Display(Name = "Action Desc")]
    public string RepairActionDesc { get; set; }

    [Display(Name = "Item")]
    public string RepairItem { get; set; }

    [Display(Name = "Item Desc")]
    public string RepairItemDesc { get; set; }

    [Display(Name = "Serial Number")]
    public string SerialNumber { get; set; }

    [Display(Name = "Create Date")]
    public string CreateDate { get; set; }
   
    [Display(Name = "Create Time")]
    public string CreateTime { get; set; }
  }
}