﻿namespace QualityDatabase.Models
{
  public class DefectTypeModel
  {
    public string Code { get; set; }
    public string Description { get; set; }
    public string DTAID { get; set; }
    public DefectTypeModel()
    {
      Code = "";
      Description = "";
      DTAID = "";
    }
  }
}