﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class WeightSheetUniversalModel
  {
    public string CreateDateTime { get; set; }
    public string VehicleType { get; set; }
    public string WeighedBy { get; set; }
    public string SupremeLocation { get; set; }
    public string DocumentSerial { get; set; }
    public string SupremeBodyNumber { get; set; }
    public string SupremeModel { get; set; }
    public string GVWR { get; set; }
    public string WeightFrontAxle { get; set; }
    public string TotalVehicleWeight { get; set; }
    public string WeightRearAxle { get; set; }
    public string VIN { get; set; }
    public string CustomerName { get; set; }
    public string CustomerAddress1 { get; set; }
    public string CustomerAddress2 { get; set; }
    public string NumberOfUnits { get; set; }
    public string Remarks { get; set; }
    public string Signature { get; set; }
    public string LicenseNumber { get; set; }
    public string Division { get; set; }

    public WeightSheetUniversalModel()
    {
      CreateDateTime = "";
      VehicleType = "";
      WeighedBy = "";
      SupremeLocation = "";
      DocumentSerial = "";
      SupremeBodyNumber = "";
      SupremeModel = "";
      GVWR = "";
      WeightFrontAxle = "";
      TotalVehicleWeight = "";
      WeightRearAxle = "";
      VIN = "";
      CustomerName = "";
      CustomerAddress1 = "";
      CustomerAddress2 = "";
      NumberOfUnits = "";
      Remarks = "";
      Signature = "";
      LicenseNumber = "";
      Division = "";
    }
  }
}