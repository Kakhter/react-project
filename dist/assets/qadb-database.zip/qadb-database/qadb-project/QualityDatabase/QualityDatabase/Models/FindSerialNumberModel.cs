﻿using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class FindSerialNumberModel
  {
    [Display(Name= "Find Unit S/N")]
    [StringLength(8, ErrorMessage = "The Serial Number cannot be more than 8 characters. ")]
    [Required(ErrorMessage = "The Serial Number is required.")]
    public string SerialNumber { get; set; }

    public FindSerialNumberModel()
    {
      SerialNumber = "";
    }
  }
}