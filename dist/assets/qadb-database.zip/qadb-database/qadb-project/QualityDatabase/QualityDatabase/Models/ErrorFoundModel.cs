﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class ErrorFoundModel
  {
    [Display(Name = "Error Description")]
    public string ErrorDescription { get; set; }

    [Display(Name = "From Module")]
    public string FromModule { get; set; }

    [Display(Name = "Error Stack")]
    public string ErrorStack { get; set; }

    public ErrorFoundModel()
    {
      ErrorDescription = "";
      FromModule = "";
      ErrorStack = "";
    }
  }
}