﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class WeightSheetCaliforniaModel
  {
    public string CreateDateTime { get; set; }
    public string VehicleType { get; set; }
    public string WeighedBy { get; set; }
    public string SupremeLocation { get; set; }
    public string DocumentSerial { get; set; }
    public string SupremeBodyNumber { get; set; }
    public string Commodity { get; set; }
    public string GVWR { get; set; }
    public string Gross { get; set; }
    public string Tare { get; set; }
    public string Net { get; set; }
    public string VIN { get; set; }
    public string CustomerName { get; set; }
    public string CustomerAddress1 { get; set; }
    public string CustomerAddress2 { get; set; }
    public string NumberOfUnits { get; set; }
    public string Remarks { get; set; }
    public string Weighmaster { get; set; }
    public string DeputyWeighmaster { get; set; }
    public string Division { get; set; }

    public WeightSheetCaliforniaModel()
    {
      CreateDateTime = "";
      VehicleType = "";
      WeighedBy = "";
      SupremeLocation = "";
      DocumentSerial = "";
      SupremeBodyNumber = "";
      Commodity = "";
      GVWR = "";
      Gross = "";
      Tare = "";
      Net = "";
      VIN = "";
      CustomerName = "";
      CustomerAddress1 = "";
      CustomerAddress2 = "";
      NumberOfUnits = "";
      Remarks = "";
      Weighmaster = "";
      DeputyWeighmaster = "";
      Division = "";
    }

    public string CalcNet()
    {
      Int64 iGross;
      Int64 iTare;
      Int64 iNet;

      if (Int64.TryParse(Gross, out iGross) == false)
        return "";

      if (Int64.TryParse(Tare, out iTare) == false)
        return "";

      iNet = iGross - iTare;
      return iNet.ToString();

    }
  }
}