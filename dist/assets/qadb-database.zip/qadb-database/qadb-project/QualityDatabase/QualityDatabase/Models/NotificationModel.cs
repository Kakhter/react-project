﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class NotificationModel
  {
    [Display(Name = "Sequence")]
    public string Sequence { get; set; }

    [Display(Name = "Message")]
    public string Message { get; set; }

    public NotificationModel()
    {
      Sequence = "";
      Message = "";
    }
  }
}