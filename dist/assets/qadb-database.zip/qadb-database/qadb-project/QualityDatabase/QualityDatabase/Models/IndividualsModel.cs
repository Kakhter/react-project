﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class IndividualsModel
  {
    public string NameID { get; set; }
    public string Name { get; set; }
    public string Function { get; set; }
    public string Building { get; set; }
    public string Shift { get; set; }
    public string Status { get; set; }

    public IndividualsModel()
    {
      NameID = "";
      Name = "";
      Function = "";
      Building = "";
      Shift = "";
      Status = "";
    }

  }
}