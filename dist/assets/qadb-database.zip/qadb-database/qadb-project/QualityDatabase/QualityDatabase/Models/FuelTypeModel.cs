﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class FuelTypeModel
  {
     public string Code { get; set; }
    public string Description { get; set; }

    public FuelTypeModel()
    {
      Code = "";
      Description = "";
    }
  }
}