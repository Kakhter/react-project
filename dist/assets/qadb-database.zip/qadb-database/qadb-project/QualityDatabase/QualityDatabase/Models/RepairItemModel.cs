﻿namespace QualityDatabase.Models
{
  public class RepairItemModel
  {
    public string Code { get; set; }
    public string Description { get; set; }

    public RepairItemModel()
    {
      Code = "";
      Description = "";
    }
  }
}