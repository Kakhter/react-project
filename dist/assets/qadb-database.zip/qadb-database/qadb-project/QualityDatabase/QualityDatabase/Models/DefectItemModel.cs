﻿namespace QualityDatabase.Models
{
    public class DefectItemModel
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public string DICID { get; set; }

        public DefectItemModel()
        {
            Code = "";
            Description = "";
            DICID = "";
        }
    }
}