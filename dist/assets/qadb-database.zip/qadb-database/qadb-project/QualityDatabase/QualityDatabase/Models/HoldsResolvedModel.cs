﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class HoldsResolvedModel
  {
    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Category")]
    public string Category { get; set; }

    [Display(Name = "Category Description")]
    public string CategoryDescription { get; set; }

    [Display(Name = "Description")]
    public string Description { get; set; }

    [Display(Name = "Hold Create Date")]
    public string HoldCreateDate { get; set; }

    [Display(Name = "Hold Create Time")]
    public string HoldCreateTime { get; set; }

    [Display(Name = "Hold Created By")]
    public string HoldCreatedBy { get; set; }

    [Display(Name = "Resolution Date")]
    public string ResolutionDate { get; set; }

    [Display(Name = "Resolution Time")]
    public string ResolutionTime { get; set; }

    [Display(Name = "Resolved By")]
    public string ResolvedBy { get; set; }

    //[Display(Name = "Resolved")]
    //public string Resolved { get; set; }

    [Display(Name = "Hold Create Date")]
    public string HoldCreateDateDisplay { get; set; }

    [Display(Name = "Resolution Date")]
    public string ResolutionDateDisplay { get; set; }

    [Display(Name = "Rework Hours")]
    public decimal ReworkHours { get; set; }

    public HoldsResolvedModel()
    {
      SerialNumber = "";
      Category = "";
      CategoryDescription = "";
      Description = "";
      HoldCreateDate = "";
      HoldCreateTime = "";
      HoldCreatedBy = "";
      ResolutionDate = "";
      ResolutionTime = "";
      ResolvedBy = "";
      //Resolved = "";
      HoldCreateDateDisplay = "";
      ResolutionDateDisplay = "";
      ReworkHours = 0;
    }

    public void ResetNullValues()
    {
      if (SerialNumber == null)
        SerialNumber = "";

      if (Category == null)
        Category = "";

      if (Description == null)
        Description = "";

      if (HoldCreateDate == null)
        HoldCreateDate = "";

      if (HoldCreateTime == null)
        HoldCreateTime = "";

      if (HoldCreatedBy == null)
        HoldCreatedBy = "";

      if (ResolutionDate == null)
        ResolutionDate = "";

      if (ResolutionTime == null)
        ResolutionTime = "";

      if (ResolvedBy == null)
        ResolvedBy = "";

      if (ReworkHours == null)
         ReworkHours = 0;

            //if (Resolved == null)
            //  Resolved = "";
        }
  }
}