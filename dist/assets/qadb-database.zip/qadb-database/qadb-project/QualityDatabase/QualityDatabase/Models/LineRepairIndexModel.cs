﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class LineRepairIndexModel
  {
    [Display(Name = "Date")]
    public string InspectionDate { get; set; }

    [Display(Name = "Area Desc")]
    public string AreaDesc { get; set; }

    [Display(Name = "Item Desc")]
    public string ItemDesc { get; set; }

    [Display(Name = "Type Desc")]
    public string TypeDesc { get; set; }

    [Display(Name = "Condition Desc")]
    public string ConditionDesc { get; set; }

    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Inspection Create Date")]
    public string InspectionCreateDate { get; set; }

    [Display(Name = "Inspection Create Time")]
    public string InspectionCreateTime { get; set; }

    [Display(Name = "Repair Action")]
    public string RepairAction { get; set; }

    [Display(Name = "Repair Action Desc")]
    public string RepairActionDesc { get; set; }

    [Display(Name = "Repair Time in Minutes")]
    public int RepairTimeMinutes { get; set; }

    [Display(Name = "Repair Create Date")]
    public string RepairCreateDate { get; set; }

    [Display(Name = "Repair Create Time")]
    public string RepairCreateTime { get; set; }

    [Display(Name = "Repair Created By")]
    public string RepairCreatedBy { get; set; }

    [Display(Name = "Rework")]
    public string Rework { get; set; }

        public LineRepairIndexModel()
    {
      AreaDesc = "";
      ItemDesc = "";
      TypeDesc = "";
      ConditionDesc = "";
      SerialNumber = "";
      InspectionCreateDate = "";
      InspectionCreateTime = "";
      RepairAction = "";
      RepairTimeMinutes = 0;
      RepairCreateDate = "";
      RepairCreateTime = "";
      RepairCreatedBy = "";
      Rework = "";
    }
  }
}