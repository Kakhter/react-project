﻿namespace QualityDatabase.Models
{
    public class DefectConditionModel
    {
        public string Code { get; set; }
        public string Description { get; set; }

        public string DCTID { get; set; }

        public DefectConditionModel()
        {
            Code = "";
            Description = "";
            DCTID = "";
        }
    }
}