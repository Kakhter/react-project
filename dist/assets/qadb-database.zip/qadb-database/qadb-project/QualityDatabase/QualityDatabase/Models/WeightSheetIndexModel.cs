﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class WeightSheetIndexModel
  {
    public string PDFFileName { get; set; }
    public DateTime PDFDateTime { get; set; }
  }
}