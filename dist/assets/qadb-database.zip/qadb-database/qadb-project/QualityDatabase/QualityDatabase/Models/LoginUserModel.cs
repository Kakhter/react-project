﻿using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class LoginUserModel
  {
    [Required(ErrorMessage = "Username is required")]
    [StringLength(10, ErrorMessage = "Username cannot be more than 10 characters")]
    [Display(Name = "Username")]
    public string Username { get; set; }

    [Required(ErrorMessage = "Password is required")]
    [StringLength(128, ErrorMessage = "Password cannot be more than 128 characters")]
    [Display(Name = "Password")]
    public string Password { get; set; }

    public LoginUserModel()
    {
      Username = "";
      Password = "";
    }
  }
}