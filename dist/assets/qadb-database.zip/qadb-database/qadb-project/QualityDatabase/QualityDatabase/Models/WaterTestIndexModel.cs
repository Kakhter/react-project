﻿using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class WaterTestIndexModel
  {
    [Display(Name = "Sequence")]
    public string InspectionType { get; set; }

    [Display(Name = "Date")]
    public string WaterTestDate { get; set; }

    [Display(Name = "Area")]
    public string DefectArea { get; set; }

    [Display(Name = "Area Desc")]
    public string AreaDesc { get; set; }

    [Display(Name = "Item")]
    public string DefectItem { get; set; }

    [Display(Name = "Item Desc")]
    public string ItemDesc { get; set; }

    [Display(Name = "Type Desc")]
    public string TypeDesc { get; set; }

    [Display(Name = "Type")]
    public string DefectType { get; set; }

    [Display(Name = "Gal/Min")]
    public string GallonsPerMinute { get; set; }

    [Display(Name = "Pressure")]
    public string WaterPressure { get; set; }

    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Water Test Create Date")]
    public string WaterTestCreateDate { get; set; }

    [Display(Name = "Water Test Create Time")]
    public string WaterTestCreateTime { get; set; }

    [Display(Name = "Leak Description")]
    public string Category { get; set; }


    }
}