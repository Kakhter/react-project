﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class LeakRepairModel
  {
    [Display(Name = "Repair Date")]
    public DateTime? RepairDate { get; set; }

    [Display(Name = "Action")]
    public string RepairAction { get; set; }

    [Display(Name = "Item")]
    public string RepairItem { get; set; }

    [Display(Name = "Serial Number")]
    public string SerialNumber { get; set; }

    [Display(Name = "Water Test Create Date")]
    public string WaterTestCreateDate { get; set; }

    [Display(Name = "Water TestCreate Time")]
    public string WaterTestCreateTime { get; set; }

    [Display(Name = "Leak Repair Create Date")]
    public string LeakRepairCreateDate { get; set; }

    [Display(Name = "Leak Repair Create Time")]
    public string LeakRepairCreateTime { get; set; }

    [Display(Name = "Leak Repair Create By")]
    public string LeakRepairCreatedBy { get; set; }

    public LeakRepairModel()
    {
      RepairDate = null;
      RepairAction = "";
      RepairItem = "";
      SerialNumber = "";
      WaterTestCreateDate = "";
      WaterTestCreateTime = "";
      LeakRepairCreateDate = "";
      LeakRepairCreateTime = "";
      LeakRepairCreatedBy = "";
    }

    public void ResetNullValues()
    {
      if (RepairAction == null)
        RepairAction = "";

      if (RepairItem == null)
        RepairItem = "";

      if (SerialNumber == null)
        SerialNumber = "";

      if (WaterTestCreateDate == null)
        WaterTestCreateDate = "";

      if (WaterTestCreateTime == null)
        WaterTestCreateTime = "";

      if (LeakRepairCreateDate == null)
        LeakRepairCreateDate = "";

      if (LeakRepairCreateTime == null)
        LeakRepairCreateTime = "";

      if (LeakRepairCreatedBy == null)
        LeakRepairCreatedBy = "";
    }
  }
}