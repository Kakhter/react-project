﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class HoldIssuesModel
  {
    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Category")]
    public string Category { get; set; }

    [Display(Name = "Category Description")]
    public string CategoryDescription { get; set; }
    
    [Display(Name = "Description")]
    public string Description { get; set; }

    [Display(Name = "Hold Create Date")]
    public string HoldCreateDate { get; set; }

    [Display(Name = "Hold Create Time")]
    public string HoldCreateTime { get; set; }

    [Display(Name = "Hold Created By")]
    public string HoldCreatedBy { get; set; }
        
    [Display(Name = "Resolution Date")]
    public string ResolutionDate { get; set; }

    [Display(Name = "Resolution Time")]
    public string ResolutionTime { get; set; }

    [Display(Name = "Resolved By")]
    public string ResolvedBy { get; set; }

    [Display(Name = "Resolved")]
    public string Resolved { get; set; }

    [Display(Name = "Hold Create Date")]
    public string HoldCreateDateDisplay { get; set; }

    [Display(Name = "Resolution Date")]
    public string ResolutionDateDisplay { get; set; }

    [Display(Name = "Hold")]
    public string Hold { get; set; }

        public HoldIssuesModel()
    {
      SerialNumber = "";
      Category = "";
      Description = "";
      HoldCreateDate = "";
      HoldCreateTime = "";
      HoldCreatedBy = "";
      CategoryDescription = "";
      ResolutionDate = "";
      ResolutionTime = "";
      ResolvedBy = "";
      Resolved = "";
      HoldCreateDateDisplay = "";
      ResolutionDateDisplay = "";
      Hold = "";
    }

    public void ResetNullValues()
    {
      if (SerialNumber == null)
        SerialNumber = "";

      if (Category == null)
        Category = "";

      if (Description == null)
        Description = "";

      if (HoldCreateDate == null)
        HoldCreateDate = "";

      if (HoldCreateTime == null)
        HoldCreateTime = "";

      if (HoldCreatedBy == null)
        HoldCreatedBy = "";

      if (ResolutionDate == null)
        ResolutionDate = "";

      if (ResolutionTime == null)
        ResolutionTime = "";

      if (ResolvedBy == null)
        ResolvedBy = "";

      if (Resolved == null)
        Resolved = "";
      if (Hold == null)
        Hold = "";
        }
  }
}