﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Models
{
  public class S1FModel
  {
    public string WeightFrontAxle { get; set; }
    public string WeightRearAxle { get; set; }
    public string VehicleWeight { get; set; }

    public S1FModel()
    {
      WeightFrontAxle = "";
      WeightRearAxle = "";
      VehicleWeight = "";
    }
  }
}