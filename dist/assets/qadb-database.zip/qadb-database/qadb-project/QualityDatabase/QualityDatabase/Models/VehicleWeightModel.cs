﻿using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.Models
{
  public class VehicleWeightModel
  {
    [DisplayFormat(DataFormatString = "{0:#####}")]
    [Display(Name = "Vehicle Weight")]
    public int VehicleWeight { get; set; }

    public VehicleWeightModel()
    {
      VehicleWeight = 0;
    }
  }
}