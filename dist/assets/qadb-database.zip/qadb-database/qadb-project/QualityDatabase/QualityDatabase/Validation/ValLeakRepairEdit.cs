﻿using QualityDatabase.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Validation
{
  public class ValLeakRepairEdit
  {
    ValLeakRepairEditParameters param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(ValLeakRepairEditParameters _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;

      //// Water Test Date
      //if (_param.RepairDate == null || _param.RepairDate == DateTime.MinValue)
      //{
      //  valError = new ValidationError();
      //  valError.Key = "RepairDate";
      //  valError.Message = "Date is required.";
      //  ErrorList.Add(valError);
      //}
      //else
      //{
      if (_param.RepairDate > DateTime.Today)
      {
        valError = new ValidationError();
        valError.Key = "RepairDate";
        valError.Message = "Date cannot be later than today.";
        ErrorList.Add(valError);
      }
      //}

      return ErrorList;
    }
  }
}