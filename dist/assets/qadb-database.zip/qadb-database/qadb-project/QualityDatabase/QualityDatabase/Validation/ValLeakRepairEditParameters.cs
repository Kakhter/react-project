﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Validation
{
  public class ValLeakRepairEditParameters
  {
    public DateTime? RepairDate { get; set; }
    public string RepairAction { get; set; }
    public string Repairtem { get; set; }
    public string LeakRepairCreateDate { get; set; }
    public string LeakRepairCreateTime { get; set; }
    public string LeakRepairCreatedBy { get; set; }

    public ValLeakRepairEditParameters()
    {
      RepairDate = DateTime.MinValue;
      RepairAction = "";
      Repairtem = "";
      LeakRepairCreateDate = "";
      LeakRepairCreateTime = "";
      LeakRepairCreatedBy = "";
    }
  }
}