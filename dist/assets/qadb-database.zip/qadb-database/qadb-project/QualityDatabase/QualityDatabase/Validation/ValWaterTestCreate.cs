﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using System;
using System.Collections.Generic;

namespace QualityDatabase.Validation
{
  public class ValWaterTestCreate
  {
    ValWaterTestParameters param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(ValWaterTestParameters _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;

      // Water Test Date
      if (_param.WaterTestDate == null || _param.WaterTestDate == DateTime.MinValue)
      {
        valError = new ValidationError();
        valError.Key = "WaterTestDate";
        valError.Message = "Date is required.";
        ErrorList.Add(valError);
      }
      else
      {
        if (_param.WaterTestDate > DateTime.Today)
        {
          valError = new ValidationError();
          valError.Key = "WaterTestDate";
          valError.Message = "Date cannot be later than today.";
          ErrorList.Add(valError);
        }
      }

      // Gallons Per Minute
      if (_param.GallonsPerMinute != null && _param.GallonsPerMinute.Trim() != "")
      {
        if (Utils.IsNumeric(_param.GallonsPerMinute) == false)
        {
          valError = new ValidationError();
          valError.Key = "GallonsPerMinute";
          valError.Message = "Must be numeric and no more than 2 characters.";
          ErrorList.Add(valError);
        }
        else
        {
          double conv = double.Parse(_param.GallonsPerMinute);
          if (conv != 0)
          {
            if (conv < 0)
            {
              valError = new ValidationError();
              valError.Key = "GallonsPerMinute";
              valError.Message = "Must be numeric and no more than 2 characters.";
              ErrorList.Add(valError);
            }
            else if (conv < 1 || conv > 99)
            {
              valError = new ValidationError();
              valError.Key = "GallonsPerMinute";
              valError.Message = "Must be numeric and no more than 2 characters.";
              ErrorList.Add(valError);
            }
          }
        }
      }

      // Water Pressure
      if (_param.WaterPressure != null && _param.WaterPressure.Trim() != "")
      {
        if (Utils.IsNumeric(_param.WaterPressure) == false)
        {
          valError = new ValidationError();
          valError.Key = "WaterPressure";
          valError.Message = "Must be numeric and no more than 2 characters.";
          ErrorList.Add(valError);
        }
        else
        {
          double conv = double.Parse(_param.WaterPressure);
          if (conv != 0)
          {
            if (conv < 0)
            {
              valError = new ValidationError();
              valError.Key = "WaterPressure";
              valError.Message = "Must be numeric and no more than 2 characters.";
              ErrorList.Add(valError);
            }
            else if (conv < 1 || conv > 99)
            {
              valError = new ValidationError();
              valError.Key = "WaterPressure";
              valError.Message = "Must be numeric and no more than 2 characters.";
              ErrorList.Add(valError);
            }
          }
        }

      }

      // Serial Number
      if (_param.SerialNumber == null || _param.SerialNumber.Trim() == "")
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "Serial Number missing.";
        ErrorList.Add(valError);
      }

      if((_param.Category).Length==0 || (_param.Category).Length <5 || (_param.Category).Length >150)
            {
                valError = new ValidationError();
                valError.Key = "Category";
                valError.Message = "Leak Description is required minimum 5 chars maximum 150 chars.";
                ErrorList.Add(valError);
            }
      // Water Test CreatedBy
      if (_param.WaterTestCreatedBy == null || _param.WaterTestCreatedBy.Trim() == "")
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "UserName missing.";
        ErrorList.Add(valError);
      }

      if ((_param.DefectArea.Trim().ToUpper() == "NL") ||
      (_param.DefectItem.Trim().ToUpper() == "NL") ||
      (_param.DefectType.Trim().ToUpper() == "NL"))
      {
        if ((_param.DefectArea.Trim().ToUpper() != "NL") ||
          (_param.DefectItem.Trim().ToUpper() != "NL") ||
          (_param.DefectType.Trim().ToUpper() != "NL"))
        {
          valError = new ValidationError();
          valError.Key = "DefectArea";
          valError.Message = "'No Leak' must be set for all defects or none.";
          ErrorList.Add(valError);

          valError = new ValidationError();
          valError.Key = "DefectItem";
          valError.Message = "'No Leak' must be set for all defects or none.";
          ErrorList.Add(valError);

          valError = new ValidationError();
          valError.Key = "DefectType";
          valError.Message = "'No Leak' must be set for all defects or none.";
          ErrorList.Add(valError);
        }
      }

      bool errorFound = false;
      if (_param.InspectionType.Trim().ToUpper() == "INIT")
      {
        WaterTestServices db = new WaterTestServices();
        List<WaterTestIndexModel> list = new List<WaterTestIndexModel>();
        list = db.GetInitialWaterTests(_param.SerialNumber, "", "");

        foreach (WaterTestIndexModel model in list)
        {
          if ((model.DefectArea.Trim().ToUpper() == "NL") &&
            (model.DefectItem.Trim().ToUpper() == "NL") &&
            (model.DefectType.Trim().ToUpper() == "NL"))
          {
            errorFound = true;
          }
        }
      }
      if (errorFound == true)
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "An all No Leak 'Initial' Water Test has already been entered. ";
        ErrorList.Add(valError);
      }




      //bool errorFound = false;
      //if ((_param.InspectionType.Trim().ToUpper() == "INIT") &&
      //((_param.DefectArea.Trim().ToUpper() != "NL") ||
      //(_param.DefectItem.Trim().ToUpper() != "NL") ||
      //(_param.DefectType.Trim().ToUpper() != "NL")))
      //{
      //  WaterTestServices db = new WaterTestServices();
      //  List<WaterTestIndexModel> list = new List<WaterTestIndexModel>();
      //  list = db.GetInitialWaterTests(_param.SerialNumber);

      //  foreach (WaterTestIndexModel model in list)
      //  {
      //    if ((model.DefectArea.Trim().ToUpper() == "NL") &&
      //      (model.DefectItem.Trim().ToUpper() == "NL") &&
      //      (model.DefectType.Trim().ToUpper() == "NL"))
      //    {
      //      errorFound = true;
      //    }
      //  }
      //}
      //if (errorFound == true)
      //{
      //  valError = new ValidationError();
      //  valError.Key = "";
      //  valError.Message = "An all No Leak 'Initial' Water Test has already been entered. ";
      //  ErrorList.Add(valError);
      //}


      return ErrorList;
    }
  }
}