﻿using QualityDatabase.Common;
using System.Collections.Generic;
using QualityDatabase.Models;

namespace QualityDatabase.Validation
{
  public class ValChassisHeightEdit
  {
    ChassisHeightModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(ChassisHeightModel _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;

      // Serial Number
      if (_param.SerialNumber == "" || _param.SerialNumber == null)
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "Serial Number is required.";
        ErrorList.Add(valError);
      }
      else
      {
        if (_param.SerialNumber.Length > 8)
        {
          valError = new ValidationError();
          valError.Key = "";
          valError.Message = "Serial Number cannot be greater than 8 characters.";
          ErrorList.Add(valError);
        }
      }

      // User
      if (_param.ChassisRailCreatedBy == "" || _param.ChassisRailCreatedBy == null)
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "Chassis Rail User is required.";
        ErrorList.Add(valError);
      }
      else
      {
        if (_param.ChassisRailCreatedBy.Length > 10)
        {
          valError = new ValidationError();
          valError.Key = "";
          valError.Message = "Chassis Rail User cannot be greater than 10 characters.";
          ErrorList.Add(valError);
        }
      }

      // Prior SS
      if (this.IsNumberValid(_param.PriorSS) == false)
      {
        valError = new ValidationError();
        valError.Key = "PriorSS";
        valError.Message = "Must be numeric of format nnn.nnn";
        ErrorList.Add(valError);
      }

      // Prior CS
      if (this.IsNumberValid(_param.PriorCS) == false)
      {
        valError = new ValidationError();
        valError.Key = "PriorCS";
        valError.Message = "Must be numeric of format nnn.nnn";
        ErrorList.Add(valError);
      }

      // After Mount SS
      if (this.IsNumberValid(_param.AfterMountSS) == false)
      {
        valError = new ValidationError();
        valError.Key = "AfterMountSS";
        valError.Message = "Must be numeric of format nnn.nnn";
        ErrorList.Add(valError);
      }

      // After Mount CS
      if (this.IsNumberValid(_param.AfterMountCS) == false)
      {
        valError = new ValidationError();
        valError.Key = "AfterMountCS";
        valError.Message = "Must be numeric of format nnn.nnn";
        ErrorList.Add(valError);
      }

      // After Test SS
      if (this.IsNumberValid(_param.AfterTestSS) == false)
      {
        valError = new ValidationError();
        valError.Key = "AfterTestSS";
        valError.Message = "Must be numeric of format nnn.nnn";
        ErrorList.Add(valError);
      }

      // After Mount CS
      if (this.IsNumberValid(_param.AfterTestCS) == false)
      {
        valError = new ValidationError();
        valError.Key = "AfterTestCS";
        valError.Message = "Must be numeric of format nnn.nnn";
        ErrorList.Add(valError);
      }

      return ErrorList;
    }

    private bool IsNumberValid(double _nbr)
    {

      if (_nbr != 0)
      {
        if (_nbr < 0 || _nbr > 999.999)
        {
          return false;
        }
        else if (Utils.NumberofPlacesToTheRight(_nbr) > 3)
        {
          return false;
        }
      }
      return true;
    }



    //private bool IsNumberValid(string _nbr)
    //{
    //  if (_nbr != null && _nbr.Trim() != "")
    //  {
    //    if (Utils.IsNumeric(_nbr) == false)
    //    {
    //      return false;
    //    }
    //    else
    //    {
    //      double conv = double.Parse(_nbr);
    //      if (conv != 0)
    //      {
    //        if (conv < 0 || conv > 99.999)
    //        {
    //          return false;
    //        }
    //        else if (Utils.NumberofPlacesToTheRight(conv) > 3)
    //        {
    //          return false;
    //        }
    //      }
    //    }
    //  }
    //  return true;
    //}


  }
}