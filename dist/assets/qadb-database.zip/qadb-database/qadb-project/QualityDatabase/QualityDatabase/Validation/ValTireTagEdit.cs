﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using System.Collections.Generic;

namespace QualityDatabase.Validation
{
  public class ValTireTagEdit
  {
    TireTagModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(TireTagModel _param)
    {
      ErrorList = new List<ValidationError>();
      param = _param;


      return ErrorList;
    }

  }
}