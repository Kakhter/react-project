﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Validation
{
  public class ValTorqueDelete
  {
     TorqueModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(TorqueModel _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;

      return ErrorList;
    }
  }
}