﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using System.Collections.Generic;

namespace QualityDatabase.Validation
{
  public class ValFuelEdit
  {
    FuelModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(FuelModel _param)
    {
      ErrorList = new List<ValidationError>();
      param = _param;


      return ErrorList;
    }

  }
}