﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.Validation
{
  public class ValLineInspectionDelete
  {
    LineInspectionModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(LineInspectionModel _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;

      return ErrorList;
    }
  }
}
