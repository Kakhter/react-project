﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using System.Collections.Generic;

namespace QualityDatabase.Validation
{
  public class ValHoldIssueDelete
  {
     HoldIssuesModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(HoldIssuesModel _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;

      return ErrorList;
    }
  }
}