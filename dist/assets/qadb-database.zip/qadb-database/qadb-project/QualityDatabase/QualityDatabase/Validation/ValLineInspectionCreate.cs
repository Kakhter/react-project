﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;

namespace QualityDatabase.Validation
{
  public class ValLineInspectionCreate
  {
    LineInspectionModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(LineInspectionModel _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;

      if ((_param.DefectArea.Trim().ToUpper() == "ND") ||
        (_param.DefectCondition.Trim().ToUpper() == "ND") ||
        (_param.DefectItem.Trim().ToUpper() == "ND") ||
        (_param.DefectType.Trim().ToUpper() == "ND"))
      {
        if ((_param.DefectArea.Trim().ToUpper() != "ND") ||
          (_param.DefectCondition.Trim().ToUpper() != "ND") ||
          (_param.DefectItem.Trim().ToUpper() != "ND") ||
          (_param.DefectType.Trim().ToUpper() != "ND"))
        {
          valError = new ValidationError();
          valError.Key = "DefectArea";
          valError.Message = "'No Defect' must be set for all defects or none.";
          ErrorList.Add(valError);

          valError = new ValidationError();
          valError.Key = "DefectItem";
          valError.Message = "'No Defect' must be set for all defects or none.";
          ErrorList.Add(valError);

          valError = new ValidationError();
          valError.Key = "DefectType";
          valError.Message = "'No Defect' must be set for all defects or none.";
          ErrorList.Add(valError);

          valError = new ValidationError();
          valError.Key = "DefectCondition";
          valError.Message = "'No Defect' must be set for all defects or none.";
          ErrorList.Add(valError);

        }
      }


      bool errorFound = false;
      string location = "";
      if (_param.InspectionType.Trim().ToUpper() == "INIT")
      {
       
        LineInspectionServices db = new LineInspectionServices();
        List<LineInspectionModel> list = new List<LineInspectionModel>();
        list = db.GetInitialLineInspections(_param.SerialNumber, _param.InspectionLocation ,"", "");

        foreach (LineInspectionModel model in list)
        {
          if ((model.DefectArea.Trim().ToUpper() == "ND") &&
            (model.DefectItem.Trim().ToUpper() == "ND") &&
            (model.DefectType.Trim().ToUpper() == "ND") &&
            (model.DefectCondition.Trim().ToUpper() == "ND"))
          {
            errorFound = true;
            location = model.InspectionLocation;
          }
        }
      }
      if (errorFound == true)
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "An all No Defect 'Initial' Sequence for Quality Station " + location + " has already been entered. ";
        ErrorList.Add(valError);
      }


      return ErrorList;
    }
  }
}