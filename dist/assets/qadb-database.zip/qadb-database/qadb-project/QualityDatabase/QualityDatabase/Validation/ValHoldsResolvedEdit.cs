﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using System.Collections.Generic;

namespace QualityDatabase.Validation
{
  public class ValHoldsResolvedEdit
  {
    HoldsResolvedModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(HoldsResolvedModel _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;

      return ErrorList;
    }
  }
}