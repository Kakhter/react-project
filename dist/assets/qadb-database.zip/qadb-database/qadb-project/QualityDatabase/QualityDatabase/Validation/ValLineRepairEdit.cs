﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using QualityDatabase.Common;
using QualityDatabase.Models;

namespace QualityDatabase.Validation
{
  public class ValLineRepairEdit
  {
    LineRepairModel param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(LineRepairModel _param)
    {
      param = _param;
      ErrorList = new List<ValidationError>();
      ValidationError valError = null;

      return ErrorList;
    }
  }
}