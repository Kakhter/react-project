﻿using System;

namespace QualityDatabase.Validation
{
  public class ValWaterTestParameters
  {
    public DateTime WaterTestDate { get; set; }
    public string WaterPressure { get; set; }
    public string GallonsPerMinute { get; set; }
    public string SerialNumber { get; set; }
    public string WaterTestCreateDate { get; set; }
    public string WaterTestCreateTime { get; set; }
    public string WaterTestCreatedBy { get; set; }
    public string DefectArea { get; set; }
    public string DefectItem { get; set; }
    public string DefectType { get; set; }
    public string InspectionType { get; set; }
    public string Category { get; set; } // Added by Khalid#2 for Category

    public ValWaterTestParameters()
    {
      WaterTestDate = DateTime.MinValue;
      WaterPressure = "";
      GallonsPerMinute = "";
      SerialNumber = "";
      WaterTestCreateDate = "";
      WaterTestCreateTime = "";
      WaterTestCreatedBy = "";
      DefectArea = "";
      DefectItem = "";
      DefectType = "";
      InspectionType = "";
      Category = ""; // Added by Khalid#2 for Category

        }
  }
}