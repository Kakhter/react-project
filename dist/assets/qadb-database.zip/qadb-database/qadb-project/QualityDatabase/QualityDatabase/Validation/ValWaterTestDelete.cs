﻿using QualityDatabase.Common;
using System.Collections.Generic;

namespace QualityDatabase.Validation
{
  public class ValWaterTestDelete
  {
    ValWaterTestParameters param = null;
    List<ValidationError> ErrorList = null;

    public List<ValidationError> Validate(ValWaterTestParameters _param)
    {
      param = _param;

      ErrorList = new List<ValidationError>();

      ValidationError valError = null;


      if (_param.SerialNumber == null || _param.SerialNumber.Trim() == "")
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "Serial Number missing.";
        ErrorList.Add(valError);
      }

      if (_param.WaterTestCreateDate == null || _param.WaterTestCreateDate.Trim() == "")
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "Record Create Date missing.";
        ErrorList.Add(valError);
      }
      else
      {
        if (Utils.IsNumeric(_param.WaterTestCreateDate) == false)
        {
          valError = new ValidationError();
          valError.Key = "";
          valError.Message = "Record Create Date must be numeric.";
          ErrorList.Add(valError);
        }
      }

      if (_param.WaterTestCreateTime == null || _param.WaterTestCreateTime.Trim() == "")
      {
        valError = new ValidationError();
        valError.Key = "";
        valError.Message = "Record Create Time missing.";
        ErrorList.Add(valError);
      }
      else
      {
        if (Utils.IsNumeric(_param.WaterTestCreateTime) == false)
        {
          valError = new ValidationError();
          valError.Key = "";
          valError.Message = "Record Create Time must be numeric.";
          ErrorList.Add(valError);
        }
      }



      return ErrorList;
    }
  }
}