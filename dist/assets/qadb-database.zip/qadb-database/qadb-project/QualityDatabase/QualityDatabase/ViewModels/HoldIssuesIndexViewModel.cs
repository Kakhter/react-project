﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System.Collections.Generic;

namespace QualityDatabase.ViewModels
{
  public class HoldIssuesIndexViewModel
  {
    public List<HoldIssuesModel> HoldList { get; set; }

    public HoldIssuesIndexViewModel()
    {
    }

    public void GetHoldListForIndex(string _serialNumber)
    {
      HoldIssuesServices db = new HoldIssuesServices();
      HoldList = db.GetHoldForIndex(_serialNumber);
    }
  }
}