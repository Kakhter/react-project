﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.ViewModels
{
  public class LeakRepairIndexViewModel
  {
    public List<LeakRepairIndexModel> LeakRepairList { get; set; }

    public LeakRepairIndexViewModel()
    {

    }

    public void GetLeakRepairListForIndex(string _serialNumber)
    {
      LeakRepairServices db = new LeakRepairServices();
      LeakRepairList = db.GetLeakRepairForIndex(_serialNumber);
    }
  }
}