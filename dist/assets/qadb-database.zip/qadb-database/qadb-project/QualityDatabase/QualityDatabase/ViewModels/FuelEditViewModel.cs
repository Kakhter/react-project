﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class FuelEditViewModel
  {
    [Display(Name = "Fuel Type")]
    public string FuelType { get; set; }

    public IEnumerable<SelectListItem> FuelTypeList
    {
      get
      {
        var db = new FuelTypeServices();
        var query = db.FuelTypeList.Select(c => new { c.Code, c.Description });
        return new SelectList(query.AsEnumerable(), "Code", "Description", FuelType);
      }
    }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Gallons of Fuel")]
    public double GallonsOfFuel { get; set; }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Price per Gallon")]
    public double PricePerGallon { get; set; }

    public string SerialNumber { get; set; }
    public string FuelCreateDate { get; set; }
    public string FuelCreateTime { get; set; }
    public string FuelUser { get; set; }

    public FuelEditViewModel()
    {
      FuelType = "";
      GallonsOfFuel = 0;
      PricePerGallon = 0;
      SerialNumber = "";
      FuelCreateDate = "";
      FuelCreateTime = "";
      FuelUser = "";
    }

    public void Populate(string _serialNumber)
    {
      this.SerialNumber = _serialNumber;

      FuelServices db = new FuelServices();
      FuelModel model = null;

      model = db.GetFuel(SerialNumber);

      this.FuelType = model.FuelType.Trim();
      this.GallonsOfFuel = model.GallonsOfFuel;
      this.PricePerGallon = model.PricePerGallon;
      this.FuelCreateDate = model.FuelCreateDate;
      this.FuelCreateTime = model.FuelCreateTime;
      this.FuelUser = model.FuelCreatedBy;
    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.FuelUser = _user;

      ValFuelEdit valEdit = new ValFuelEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetFuelModel());
      if (ErrorList.Count > 0)
        return ErrorList;

      FuelServices db = new FuelServices();
      FuelModel model = GetFuelModel();

      string ErrorMsg = "";
      ErrorMsg = db.UpdateFuel(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }


    private FuelModel GetFuelModel()
    {
      FuelModel model = new FuelModel();
      model.FuelType = this.FuelType;
      model.GallonsOfFuel = this.GallonsOfFuel;
      model.PricePerGallon = this.PricePerGallon;
      model.SerialNumber = this.SerialNumber;
      model.FuelCreateDate = this.FuelCreateDate;
      model.FuelCreateTime = this.FuelCreateTime;
      model.FuelCreatedBy = this.FuelUser;
      return model;
    }
  }
}