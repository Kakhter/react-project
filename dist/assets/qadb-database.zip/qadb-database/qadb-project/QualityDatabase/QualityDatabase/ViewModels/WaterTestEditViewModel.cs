﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class WaterTestEditViewModel
  {
    [Required(ErrorMessage = "Date is required")]
    [Display(Name = "Date")]
    [DataType(DataType.Date)]
    public DateTime WaterTestDate { get; set; }

    [StringLength(2, ErrorMessage = "Water Pressure cannot be more than 2 characters")]
    [Display(Name = "Pressure")]
    public string WaterPressure { get; set; }

    [StringLength(2, ErrorMessage = "Gallons per Minute cannot be more than 2 characters")]
    [Display(Name = "Gallons per Minute")]
    public string GallonsPerMinute { get; set; }

    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Water Test Create Date")]
    public string WaterTestCreateDate { get; set; }

    [Display(Name = "Water Test Create Time")]
    public string WaterTestCreateTime { get; set; }

    [Display(Name = "Water Test CreatedBy")]
    public string WaterTestCreatedBy { get; set; }

    [Required(ErrorMessage = "Area is required")]
    [Display(Name = "Area")]
    public string DefectArea { get; set; }
    [Required(ErrorMessage = "Leak Description is required, minimum 5 chars maximum 150 chars")]
    [StringLength(150, ErrorMessage = "Category cannot be more than 150 characters")]
    [Display(Name = "Leak Description")]
    public string Category { get; set; }

    public IEnumerable<SelectListItem> DefectAreaList
    {
      get
      {
        var db = new DefectAreaServices();
        var query = db.WaterTestAreaList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", DefectArea);
      }
    }

    [Required(ErrorMessage = "Item is required")]
    [Display(Name = "Item")]
    public string DefectItem { get; set; }

    public IEnumerable<SelectListItem> DefectItemList
    {
      get
      {
        var db = new DefectItemServices();
        var query = db.WaterTestItemList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", DefectItem);
      }
    }

    [Required(ErrorMessage = "Type is required")]
    [Display(Name = "Type")]
    public string DefectType { get; set; }

    public IEnumerable<SelectListItem> DefectTypeList
    {
      get
      {
        var db = new DefectTypeServices();
        var query = db.WaterTestTypeList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", DefectType);
      }
    }

    [Required(ErrorMessage = "Sequence is required")]
    [Display(Name = "Sequence")]
    public string InspectionType { get; set; }

    public IEnumerable<SelectListItem> InspectionTypeList
    {
      get
      {
        var db = new InspectionTypeServices();
        var query = db.WaterTestInspectionTypeList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", InspectionType);
      }
    }


    public WaterTestEditViewModel()
    {
      DefectArea = "";
      DefectItem = "";
      DefectType = "";
      InspectionType = "";
      WaterTestDate = DateTime.Today;
      WaterPressure = "";
      GallonsPerMinute = "";
      SerialNumber = "";
      WaterTestCreateDate = "";
      WaterTestCreateTime = "";
      Category = ""; //added by Khalid#2
      
    }

    public void Populate(string _serialNumber, string _createDate, string _createTime)
    {
      this.SerialNumber = _serialNumber;
      this.WaterTestCreateDate = _createDate;
      this.WaterTestCreateTime = _createTime;

      WaterTestServices wts = new WaterTestServices();
      WaterTestModel wt = null;

      wt = wts.GetSingleWaterTest(SerialNumber, WaterTestCreateDate, WaterTestCreateTime);

      this.WaterTestDate = wt.WaterTestDate;
      this.InspectionType = wt.InspectionType;
      this.DefectArea = wt.DefectArea;
      this.DefectItem = wt.DefectItem;
      this.DefectType = wt.DefectType;
      this.GallonsPerMinute = wt.GallonsPerMinute;
      this.WaterPressure = wt.WaterPressure;
      this.Category = wt.Category.Trim(); //Added by Khalid#2

    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.WaterTestCreatedBy = _user;

      ValWaterTestEdit valEdit = new ValWaterTestEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetValidationParameters());
      if (ErrorList.Count > 0)
        return ErrorList;

      WaterTestServices wts = new WaterTestServices();
      WaterTestModel wt = GetWaterTestModel();

      string ErrorMsg = "";
      ErrorMsg = wts.UpdateWaterTest(wt);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    private ValWaterTestParameters GetValidationParameters()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.WaterTestDate = this.WaterTestDate;
      param.WaterPressure = this.WaterPressure;
      param.GallonsPerMinute = this.GallonsPerMinute;
      param.SerialNumber = this.SerialNumber;
      param.WaterTestCreateDate = this.WaterTestCreateDate;
      param.WaterTestCreateTime = this.WaterTestCreateTime;
      param.WaterTestCreatedBy = this.WaterTestCreatedBy;
      param.DefectArea = this.DefectArea;
      param.DefectItem = this.DefectItem;
      param.DefectType = this.DefectType;
      param.InspectionType = this.InspectionType;
      param.Category = this.Category;
      return param;
    }


    private WaterTestModel GetWaterTestModel()
    {
      WaterTestModel wtm = new WaterTestModel();
      wtm.WaterTestDate = this.WaterTestDate;
      wtm.WaterPressure = this.WaterPressure;
      wtm.GallonsPerMinute = this.GallonsPerMinute;
      wtm.SerialNumber = this.SerialNumber;
      wtm.WaterTestCreateDate = this.WaterTestCreateDate;
      wtm.WaterTestCreateTime = this.WaterTestCreateTime;
      wtm.WaterTestCreatedBy = this.WaterTestCreatedBy;
      wtm.DefectArea = this.DefectArea;
      wtm.DefectItem = this.DefectItem;
      wtm.DefectType = this.DefectType;
      wtm.InspectionType = this.InspectionType;
      wtm.Category = this.Category; //added by Khalid#2
      return wtm;
    }

  }
}