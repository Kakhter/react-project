﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System.Collections.Generic;

namespace QualityDatabase.ViewModels
{
  public class ChassisHeightIndexViewModel
  {
    public List<ChassisHeightIndexModel> ChassisHeightList { get; set; }

    public ChassisHeightIndexViewModel()
    {

    }

    public void GetChassisHeightListForIndex(string _serialNumber)
    {
      ChassisHeightServices db = new ChassisHeightServices();
      ChassisHeightList = db.GetChassisHeightForIndex(_serialNumber);
    }
  }
}