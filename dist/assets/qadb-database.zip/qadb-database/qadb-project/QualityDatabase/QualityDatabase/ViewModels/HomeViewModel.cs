﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace QualityDatabase.ViewModels
{
  public class HomeViewModel
  {
    [Display(Name = "Find Unit S/N")]
    [StringLength(8, ErrorMessage = "The Serial Number cannot be more than 8 characters. ")]
    [Required(ErrorMessage = "The Serial Number is required.")]
    public string SerialNumber { get; set; }

    public List<NotificationModel> HoldsList { get; set; }

    public HomeViewModel()
    {
      SerialNumber = "";

      NotificationServices db = new NotificationServices();
      HoldsList = db.GetAllNotificationRecords();
    }
  }
}