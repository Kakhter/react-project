﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class LeakRepairEditViewModel
  {
   
    [Display(Name = "Date")]
    [DataType(DataType.Date)]
    public DateTime? RepairDate { get; set; }

    public string LeakRepairCreateDate { get; set; }
    public string LeakRepairCreateTime { get; set; }
    public string LeakRepairCreatedBy { get; set; }
    public string SerialNumber { get; set; }
    public string WaterTestCreateDate { get; set; }
    public string WaterTestCreateTime { get; set; }


    [Display(Name = "Action")]
    public string RepairAction { get; set; }

    public IEnumerable<SelectListItem> RepairActionList
    {
      get
      {
        var db = new RepairActionServices();
        var query = db.RepairActionList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", RepairAction);
      }
    }


    [Display(Name = "Item")]
    public string RepairItem { get; set; }

    public IEnumerable<SelectListItem> RepairItemList
    {
      get
      {
        var db = new RepairItemServices();
        var query = db.RepairItemList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", RepairItem);
      }
    }

    public LeakRepairEditViewModel()
    {
      RepairDate = null;
      RepairAction = "";
      RepairItem = "";
    }

    public void Populate(string _serialNumber, string _createDate, string _createTime)
    {
      this.SerialNumber = _serialNumber;
      this.WaterTestCreateDate = _createDate;
      this.WaterTestCreateTime = _createTime;

      LeakRepairServices db = new LeakRepairServices();
      LeakRepairModel model = null;

      model = db.GetSingleLeakRepair(SerialNumber, WaterTestCreateDate, WaterTestCreateTime);

      if (model.RepairDate == DateTime.MinValue)
        this.RepairDate = DateTime.Today;
      else
        this.RepairDate = model.RepairDate;

      this.RepairAction = model.RepairAction;
      this.RepairItem = model.RepairItem;
      this.LeakRepairCreateDate = model.LeakRepairCreateDate;
      this.LeakRepairCreateTime = model.LeakRepairCreateTime;
      this.LeakRepairCreatedBy = model.LeakRepairCreatedBy;

    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.LeakRepairCreatedBy = _user;

      ValLeakRepairEdit valEdit = new ValLeakRepairEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetValidationParameters());
      if (ErrorList.Count > 0)
        return ErrorList;

      LeakRepairServices db = new LeakRepairServices();
      LeakRepairModel model = GetLeakRepairModel();

      string ErrorMsg = "";
      ErrorMsg = db.UpdateLeakRepair(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    private ValLeakRepairEditParameters GetValidationParameters()
    {
      ValLeakRepairEditParameters param = new ValLeakRepairEditParameters();
      param.RepairDate = this.RepairDate;
      param.RepairAction = this.RepairAction;
      param.Repairtem = this.RepairItem;
      param.LeakRepairCreatedBy = this.LeakRepairCreatedBy; 
      return param;
    }

    private LeakRepairModel GetLeakRepairModel()
    {
      LeakRepairModel model = new LeakRepairModel();
      model.RepairDate = this.RepairDate;
      model.RepairAction = this.RepairAction;
      model.RepairItem = this.RepairItem;
      model.LeakRepairCreateDate = this.LeakRepairCreateDate;
      model.LeakRepairCreateTime = this.LeakRepairCreateTime;
      model.LeakRepairCreatedBy = this.LeakRepairCreatedBy;
      model.SerialNumber = this.SerialNumber;
      model.WaterTestCreateDate = this.WaterTestCreateDate;
      model.WaterTestCreateTime = this.WaterTestCreateTime;
      return model;
    }
  }
}