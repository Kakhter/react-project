﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System.Collections.Generic;

namespace QualityDatabase.ViewModels
{
  public class WeightSheetIndexViewModel
  {
    public List<WeightSheetIndexModel> WeightSheetList { get; set; }

    public void GetWeightSheetListForIndex(string _bodyNumber)
    {
      WeightSheetServices db = new WeightSheetServices();
      WeightSheetList = db.GetWeightSheetListForIndex(_bodyNumber);
    }
  }
}