﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;



namespace QualityDatabase.ViewModels
{
    public class LineInspectionEditViewModel
    {
        [Required(ErrorMessage = "Date is required")]
        [Display(Name = "Date")]
        [DataType(DataType.Date)]
        public DateTime InspectionDate { get; set; }

        [Display(Name = "Serial #")]
        public string SerialNumber { get; set; }

        [Display(Name = "Inspection Create Date")]
        public string InspectionCreateDate { get; set; }

        [Display(Name = "Inspection Create Time")]
        public string InspectionCreateTime { get; set; }

        [Display(Name = "Inspection Created By")]
        public string InspectionCreatedBy { get; set; }

        [Display(Name = "Quality Station")]
        public string InspectionLocation { get; set; }

        public IEnumerable<SelectListItem> InspectionLocationList
        {
            get
            {
                var db = new InspectionLocationService();
                var query = db.InspectionLocationList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", InspectionLocation);
            }
        }

        [Display(Name = "Offline Operation")]
        public string OfflineOperation { get; set; }

        public IEnumerable<SelectListItem> OfflineOperationList
        {
            get
            {
                var db = new OfflineOperationService();
                var query = db.OfflineOperationList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", InspectionLocation);
            }
        }

        [Display(Name = "Inspector")]
        public string Inspector { get; set; }

        public IEnumerable<SelectListItem> IndividualsList
        {
            get
            {
                var db = new IndividualsServices(Division);
                var query = db.IndividualsList.Select(c => new { c.NameID, c.Name });
                return new SelectList(query.AsEnumerable(), "NameID", "Name", Inspector);
            }
        }


        [Display(Name = "Sequence")]
        public string InspectionType { get; set; }

        public IEnumerable<SelectListItem> InspectionTypeList
        {
            get
            {
                var db = new InspectionTypeServices();
                var query = db.LineInspectionInspectionTypeList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", InspectionType);
            }
        }

        [Required(ErrorMessage = "Area is required")]
        [Display(Name = "Area")]
        public string DefectArea { get; set; }

        public IEnumerable<SelectListItem> DefectAreaList
        {
            get
            {
                var db = new DefectAreaServices();
                var query = db.LineInspectionAreaList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", DefectArea);
            }
        }

        [Required(ErrorMessage = "Item is required")]
        [Display(Name = "Item")]
        public string DefectItem { get; set; }

        public IEnumerable<SelectListItem> DefectItemList
        {
            get
            {
                var db = new DefectItemServices();
                var query = db.LineInspectionItemList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", DefectItem);
            }
        }

        [Required(ErrorMessage = "Type is required")]
        [Display(Name = "Type")]
        public string DefectType { get; set; }

        public IEnumerable<SelectListItem> DefectTypeList
        {
            get
            {
                var db = new DefectTypeServices();
                var query = db.LineInspectionTypeList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", DefectType);
            }
        }

        [Required(ErrorMessage = "Condition is required")]
        [Display(Name = "Condition")]
        public string DefectCondition { get; set; }

        public IEnumerable<SelectListItem> DefectConditionList
        {
            get
            {
                var db = new DefectConditionServices();
                var query = db.LineInspectionConditionList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", DefectCondition);
            }
        }
        public List<DropDownItem> GetConditionItems(string defectTypeCode)
        {
            var db = new DefectConditionServices();
            return db.LineInspectionConditionList
                     .Where(c => c.DCTID == defectTypeCode)
                     .Select(c => new DropDownItem
                     {
                         Value = c.Code,
                         Text = c.Code.Trim() + " - " + c.Description.Trim(),
                         Selected = false
                     }).ToList();
        }

        public  List<DropDownItem> GetDefectItems(string defectConditionCode)
        {
            var db = new DefectItemServices();
            return db.LineInspectionItemList
                     .Where(c => c.DICID == defectConditionCode)
                     .Select(c => new DropDownItem
                     {
                         Value = c.Code,
                         Text = c.Code.Trim() + " - " + c.Description.Trim(),
                         Selected = false
                     }).ToList();
        }

        

        public string Division { get; set; }
        public string originalDefectArea { get; set; }
        public string originalDefectType { get; set; }
        public string originalDefectCondition { get; set; }
        public string originalDefectItem { get; set; }

        public LineInspectionEditViewModel()
        {
            InspectionDate = DateTime.Today;
            InspectionLocation = " ";
            OfflineOperation = " ";
            Inspector = " ";
            InspectionType = " ";
            DefectArea = " ";
            DefectItem = " ";
            DefectType = " ";
            DefectCondition = " ";
            SerialNumber = "";
            InspectionCreateDate = "";
            InspectionCreateTime = "";
            InspectionCreatedBy = "";
            Division = "";
            originalDefectArea = "";
            originalDefectType = "";
            originalDefectCondition = "";
            originalDefectItem = "";
        }

        public void Populate(string _serialNumber, string _createDate, string _createTime, string _defectArea, string _defectType, string _defectCondition, string _defectItem)
        {
            this.SerialNumber = _serialNumber;
            this.InspectionCreateDate = _createDate;
            this.InspectionCreateTime = _createTime;
            this.DefectArea = _defectArea;
            this.DefectType = _defectType;
            this.DefectCondition = _defectCondition;
            this.DefectItem = _defectItem;

            LineInspectionServices db = new LineInspectionServices();
            LineInspectionModel model = null;

            model = db.GetSingleLineInspection(SerialNumber, InspectionCreateDate, InspectionCreateTime, DefectArea, DefectType, DefectCondition, DefectItem);

            this.InspectionDate = model.InspectionDate;
            this.InspectionLocation = model.InspectionLocation;
            this.OfflineOperation = model.OfflineOperation;
            this.Inspector = model.Inspector;
            this.InspectionType = model.InspectionType;
            this.DefectArea = model.DefectArea;
            this.DefectItem = model.DefectItem;
            this.DefectType = model.DefectType;
            this.DefectCondition = model.DefectCondition;
            this.InspectionCreateDate = model.InspectionCreateDate;
            this.InspectionCreateTime = model.InspectionCreateTime;
            this.InspectionCreatedBy = model.InspectionCreatedBy;
            this.originalDefectArea = model.DefectArea;
            this.originalDefectType = model.DefectType;
            this.originalDefectCondition = model.DefectCondition;
            this.originalDefectItem = model.DefectItem;

            DivisionService dbDiv = new DivisionService();
            this.Division = dbDiv.GetDivision(_serialNumber);
        }

        public List<ValidationError> Save(string _serialNumber, string _user)
        {
            this.SerialNumber = _serialNumber;
            this.InspectionCreatedBy = _user;

            ValLineInspectionEdit valEdit = new ValLineInspectionEdit();

            List<ValidationError> ErrorList = new List<ValidationError>();
            ErrorList = valEdit.Validate(GetLineInspectionModel());
            if (ErrorList.Count > 0)
                return ErrorList;

            LineInspectionModel model = GetLineInspectionModel();
            LineInspectionServices db = new LineInspectionServices();

            string ErrorMsg = "";
            ErrorMsg = db.UpdateLineInspection(model);
            if (ErrorMsg != "")
            {
                ValidationError valError = new ValidationError();
                valError.Key = "";
                valError.Message = ErrorMsg;
                ErrorList.Add(valError);
            }
            return ErrorList;
        }


        public LineInspectionModel GetLineInspectionModel()
        {
            LineInspectionModel model = new LineInspectionModel();
            model.InspectionDate = this.InspectionDate;
            model.InspectionLocation = this.InspectionLocation;
            model.OfflineOperation = this.OfflineOperation;
            model.Inspector = this.Inspector;
            model.InspectionType = this.InspectionType;
            model.DefectArea = this.DefectArea;
            model.DefectItem = this.DefectItem;
            model.DefectType = this.DefectType;
            model.DefectCondition = this.DefectCondition;
            model.SerialNumber = this.SerialNumber;
            model.InspectionCreateDate = this.InspectionCreateDate;
            model.InspectionCreateTime = this.InspectionCreateTime;
            model.InspectionCreatedBy = this.InspectionCreatedBy;
            model.originalDefectArea = this.originalDefectArea;
            model.originalDefectType = this.originalDefectType;
            model.originalDefectCondition = this.originalDefectCondition;
            model.originalDefectItem = this.originalDefectItem;
            return model;
        }

    }

    public class DropDownItem
    {
        public string Value { get; internal set; }
        public string Text { get; internal set; }
        public bool Selected { get; internal set; }
    }
}