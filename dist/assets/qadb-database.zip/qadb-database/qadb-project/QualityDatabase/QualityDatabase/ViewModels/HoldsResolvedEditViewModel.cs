﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class HoldsResolvedEditViewModel
  {
    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Category")]
    public string Category { get; set; }

    [Display(Name = "Category Description")]
    public string CategoryDescription { get; set; }

    [Display(Name = "Description")]
    public string Description { get; set; }

    [Display(Name = "Hold Create Date")]
    public string HoldCreateDate { get; set; }

    [Display(Name = "Hold Create Time")]
    public string HoldCreateTime { get; set; }

    [Display(Name = "Hold Created By")]
    public string HoldCreatedBy { get; set; }

    [Display(Name = "Resolution Date")]
    public string ResolutionDate { get; set; }

    [Display(Name = "Resolution Time")]
    public string ResolutionTime { get; set; }

    [Display(Name = "Resolved By")]
    public string ResolvedBy { get; set; }

    [Display(Name = "Rework Hours")]
    [Range(0.00, 99.99, ErrorMessage = "Rework Hours must be between 0.00 and 99.99")]
    public decimal ReworkHours { get; set; }

    public IEnumerable<SelectListItem> IndividualsList
    {
      get
      {
        var db = new IndividualsServices(Division);
        var query = db.IndividualsList.Select(c => new { c.NameID, c.Name });
        return new SelectList(query.AsEnumerable(), "NameID", "Name", ResolvedBy);
      }
    }

    public string Division { get; set; }

    //[Required(ErrorMessage = "Resolved field is required.")]
    //[Display(Name = "Resolved")]
    //public string Resolved { get; set; }

    //public IEnumerable<SelectListItem> ResolvedList
    //{
    //  get
    //  {
    //    var query = YesNoList.Select(c => new { c.Code, c.Description });
    //    return new SelectList(query.AsEnumerable(), "Code", "Description", Resolved);
    //  }
    //}

    //public List<YesNoModel> YesNoList
    //{
    //  get { return GetYesNo(); }
    //}

    //private List<YesNoModel> GetYesNo()
    //{
    //  List<YesNoModel> list = new List<YesNoModel>();
    //  YesNoModel model;

    //  model = new YesNoModel();
    //  model.Code = "YES";
    //  model.Description = "Yes";
    //  list.Add(model);

    //  model = new YesNoModel();
    //  model.Code = "NO";
    //  model.Description = "No";
    //  list.Add(model);

    //  return list;
    //}

    public HoldsResolvedEditViewModel()
    {
      SerialNumber = "";
      Category = "";
      CategoryDescription = "";
      Description = "";
      HoldCreateDate = "";
      HoldCreateTime = "";
      HoldCreatedBy = "";
      ResolutionDate = "";
      ResolutionTime = "";
      ResolvedBy = "";
      Division = "";
      ReworkHours = 0;
    }

    public void Populate(string _serialNumber, string _createDate, string _createTime)
    {
      this.SerialNumber = _serialNumber;
      this.HoldCreateDate = _createDate;
      this.HoldCreateTime = _createTime;

      HoldsResolvedServices db = new HoldsResolvedServices();
      HoldsResolvedModel model = null;

      model = db.GetSingleHoldsResolved(SerialNumber, HoldCreateDate, HoldCreateTime);
      this.Category = model.Category;
      this.CategoryDescription = model.CategoryDescription;
      this.Description = model.Description;
      this.HoldCreateDate = model.HoldCreateDate;
      this.HoldCreateTime = model.HoldCreateTime;
      this.HoldCreatedBy = model.HoldCreatedBy;
      this.ResolutionDate = model.ResolutionDate;
      this.ResolutionTime = model.ResolutionTime;
      this.ResolvedBy = model.ResolvedBy;
      this.ReworkHours = model.ReworkHours;

      DivisionService dbDiv = new DivisionService();
      this.Division = dbDiv.GetDivision(_serialNumber);
    }

    public List<ValidationError> Save(string _serialNumber)
    {
      this.SerialNumber = _serialNumber;
      //this.ResolvedBy = _user;

      ValHoldsResolvedEdit valEdit = new ValHoldsResolvedEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetHoldsResolvedModel());
      if (ErrorList.Count > 0)
        return ErrorList;

      HoldsResolvedServices db = new HoldsResolvedServices();
      HoldsResolvedModel model = GetHoldsResolvedModel();

      string ErrorMsg = "";
      ErrorMsg = db.UpdateHoldsResolved(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    private HoldsResolvedModel GetHoldsResolvedModel()
    {
      HoldsResolvedModel model = new HoldsResolvedModel();
      model.Category = this.Category;
      model.Description = this.Description;
      model.HoldCreateDate = this.HoldCreateDate;
      model.HoldCreatedBy = this.HoldCreatedBy;
      model.HoldCreateTime = this.HoldCreateTime;
      model.SerialNumber = this.SerialNumber;
      model.ResolutionDate = this.ResolutionDate;
      model.ResolutionTime = this.ResolutionTime;
      model.ResolvedBy = this.ResolvedBy;
      model.ReworkHours = this.ReworkHours;

      //model.Resolved = this.Resolved;
      return model;
    }


  }

}