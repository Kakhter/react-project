﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class WeightSheetUniversalViewModel
  {
    [Display(Name = "VIN")]
    public string VIN { get; set; }

    [Display(Name = "Vin Length")]
    public string VIN_Length { get; set; }

    [Required(ErrorMessage = "Vehicle Type is required")]
    [Display(Name = "Vehicle Type")]
    public string VehicleType { get; set; }

    public IEnumerable<SelectListItem> VehicleTypeList
    {
      get
      {
        var db = new VehicleTypeServices();
        var query = db.VehicleTypeList.Select(c => new { c.Code, Description = c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", VehicleType);
      }
    }

    [Required(ErrorMessage = "Weight Front Axle is required")]
    [Display(Name = "Weight Front Axle")]
    public string WeightFrontAxle { get; set; }

    [Required(ErrorMessage = "Total Vehicle Weight is required")]
    [Display(Name = "Total Vehicle Weight")]
    public string TotalVehicleWeight { get; set; }

    [Required(ErrorMessage = "Weight Rear Axle is required")]
    [Display(Name = "Weight Rear Axle")]
    public string WeightRearAxle { get; set; }

    [Display(Name = "Remarks")]
    public string Remarks { get; set; }

    public WeightSheetUniversalViewModel()
    {
      VehicleType = "";
      WeightFrontAxle = "";
      TotalVehicleWeight = "";
      WeightRearAxle = "";
      Remarks = "";
    }

    public void Populate(string _serialNumber)
    {
      S1FServices db = new S1FServices();
      S1FModel model;

      model = db.GetS1FData(_serialNumber);
      this.WeightFrontAxle = model.WeightFrontAxle;
      this.WeightRearAxle = model.WeightRearAxle;
      this.TotalVehicleWeight = model.VehicleWeight;

      WeightSheetServices dbWS = new WeightSheetServices();
      this.VehicleType = dbWS.GetVehicleType(_serialNumber);
      this.VIN = dbWS.GetVIN(_serialNumber);
      this.VIN_Length = " - " + this.VIN.Trim().Length.ToString() + " chars";
    }

    public List<ValidationError> Save(string _serialNumber)
    {
      List<ValidationError> list = null;
      list = this.Validate();
      if (list.Count > 0)
        return list;

      S1FServices db = new S1FServices();
      S1FModel model = new S1FModel();
      model.WeightFrontAxle = this.WeightFrontAxle;
      model.WeightRearAxle = this.WeightRearAxle;
      model.VehicleWeight = this.TotalVehicleWeight;
      db.Update(_serialNumber, model);
      return list;

    }

    public List<ValidationError> Validate()
    {
      List<ValidationError> ErrorList = new List<ValidationError>();
      ValidationError valError;
      if (IsNonZeroNumber(WeightFrontAxle) == false)
      {
        valError = new ValidationError();
        valError.Key = "WeightFrontAxle";
        valError.Message = "Weight Front Axle must be greater than zero.";
        ErrorList.Add(valError);
      }

      if (IsNonZeroNumber(TotalVehicleWeight) == false)
      {
        valError = new ValidationError();
        valError.Key = "TotalVehicleWeight";
        valError.Message = "Total Vehicle Weight must be greater than zero.";
        ErrorList.Add(valError);
      }

      if (IsNonZeroNumber(WeightRearAxle) == false)
      {
        valError = new ValidationError();
        valError.Key = "WeightRearAxle";
        valError.Message = "Weight Rear Axle must be greater than zero.";
        ErrorList.Add(valError);
      }

      return ErrorList;
    }

    private bool IsNonZeroNumber(string _value)
    {
      bool result = false;
      decimal number = 0;

      if (Decimal.TryParse(_value, out number))
      {
        if (number > 0)
          result = true;
      }
      return result;
    }
  }
}