﻿using QualityDatabase.Common;
using QualityDatabase.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class WeightSheetCaliforniaViewModel
  {
    [Display(Name = "VIN")]
    public string VIN { get; set; }

    [Display(Name = "Vin Length")]
    public string VIN_Length { get; set; }

    [Required(ErrorMessage = "Vehicle Type is required")]
    [Display(Name = "Vehicle Type")]
    public string VehicleType { get; set; }

    public IEnumerable<SelectListItem> VehicleTypeList
    {
      get
      {
        var db = new VehicleTypeServices();
        var query = db.VehicleTypeList.Select(c => new { c.Code, Description = c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", VehicleType);
      }
    }

    [Required(ErrorMessage = "Gross is required")]
    [Display(Name = "Gross")]
    public string Gross { get; set; }

    [Display(Name = "Tare")]
    public string Tare { get; set; }

    [Display(Name = "Remarks")]
    public string Remarks { get; set; }

    public WeightSheetCaliforniaViewModel()
    {
      VIN = "";
      VIN_Length = "";
      VehicleType = "";
      Gross = "";
      Tare = "0";
      Remarks = "";
    }

    public void Populate(string _serialNumber)
    {
      WeightSheetServices db = new WeightSheetServices();
      this.VehicleType = db.GetVehicleType(_serialNumber);
      this.VIN = db.GetVIN(_serialNumber);
      this.VIN_Length = " - " + this.VIN.Trim().Length.ToString() + " chars";

    }

    public List<ValidationError> Validate()
    {
      List<ValidationError> ErrorList = new List<ValidationError>();
      ValidationError valError;
      if (IsNonZeroNumber(Gross) == false)
      {
        valError = new ValidationError();
        valError.Key = "Gross";
        valError.Message = "Gross must be a number greater than zero.";
        ErrorList.Add(valError);
      }

      if (IsNonNegativeNumber(Tare) == false)
      {
        valError = new ValidationError();
        valError.Key = "Tare";
        valError.Message = "Tare must be a number zero or more.";
        ErrorList.Add(valError);
      }

      //if (IsNonZeroNumber(WeightRearAxle) == false)
      //{
      //  valError = new ValidationError();
      //  valError.Key = "WeightRearAxle";
      //  valError.Message = "Weight Rear Axle must be greater than zero.";
      //  ErrorList.Add(valError);
      //}

      return ErrorList;
    }

    private bool IsNonZeroNumber(string _value)
    {
      bool result = false;
      decimal number = 0;

      if (Decimal.TryParse(_value, out number))
      {
        if (number > 0)
          result = true;
      }
      return result;
    }

    private bool IsNonNegativeNumber(string _value)
    {
      bool result = false;
      decimal number = 0;

      if (Decimal.TryParse(_value, out number))
      {
        if (number >= 0)
          result = true;
      }
      return result;
    }
  }
}