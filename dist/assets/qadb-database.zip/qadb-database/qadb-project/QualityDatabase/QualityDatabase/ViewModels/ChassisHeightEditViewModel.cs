﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.ViewModels
{
  public class ChassisHeightEditViewModel
  {
    [DisplayFormat(DataFormatString = "{0:##.###}")]
    [Display(Name = "Prior SS")]
    public double PriorSS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    [Display(Name = "Prior CS")]
    public double PriorCS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    [Display(Name = "After Mount SS")]
    public double AfterMountSS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    [Display(Name = "After Mount CS")]
    public double AfterMountCS { get; set; }

    [DisplayFormat(DataFormatString = "{0:##.###}")]
    [Display(Name = "After Test SS")]
    public double AfterTestSS { get; set; }

    [DisplayFormat(DataFormatString = "{0:#0.###}")]
    [Display(Name = "After Test CS")]
    public double AfterTestCS { get; set; }

    public string SerialNumber { get; set; }
    public string ChassisRailCreateDate { get; set; }
    public string ChassisRailCreateTime { get; set; }
    public string ChassisRailCreatedBy { get; set; }


    public ChassisHeightEditViewModel()
    {
      PriorSS = 0;
      PriorCS = 0;
      AfterMountSS = 0;
      AfterMountCS = 0;
      AfterTestSS = 0;
      AfterTestCS = 0;
      SerialNumber = "";
      ChassisRailCreateDate = "";
      ChassisRailCreateTime = "";
      ChassisRailCreatedBy = "";
    }

    public void Populate(string _serialNumber)
    {
      this.SerialNumber = _serialNumber;

      ChassisHeightServices db = new ChassisHeightServices();
      ChassisHeightModel model = null;

      model = db.GetChassisHeight(SerialNumber);

      this.PriorSS = model.PriorSS;
      this.PriorCS = model.PriorCS;
      this.AfterMountSS = model.AfterMountSS;
      this.AfterMountCS = model.AfterMountCS;
      this.AfterTestSS = model.AfterTestSS;
      this.AfterTestCS = model.AfterTestCS;
      this.ChassisRailCreateDate = model.ChassisRailCreateDate;
      this.ChassisRailCreateTime = model.ChassisRailCreateTime;
      this.ChassisRailCreatedBy = model.ChassisRailCreatedBy;
    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.ChassisRailCreatedBy = _user;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetChassisHeightModel());
      if (ErrorList.Count > 0)
        return ErrorList;

      ChassisHeightServices db = new ChassisHeightServices();
      ChassisHeightModel model = GetChassisHeightModel();

      string ErrorMsg = "";
      ErrorMsg = db.UpdateChassisHeight(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;

    }

    private ChassisHeightModel GetChassisHeightModel()
    {
      ChassisHeightModel model = new ChassisHeightModel();
      model.PriorSS = this.PriorSS;
      model.PriorCS = this.PriorCS;
      model.AfterMountSS = this.AfterMountSS;
      model.AfterMountCS = this.AfterMountCS;
      model.AfterTestSS = this.AfterTestSS;
      model.AfterTestCS = this.AfterTestCS;
      model.SerialNumber = this.SerialNumber;
      model.ChassisRailCreateDate = this.ChassisRailCreateDate;
      model.ChassisRailCreateTime = this.ChassisRailCreateTime;
      model.ChassisRailCreatedBy = this.ChassisRailCreatedBy;
      return model;

    }
  }
}