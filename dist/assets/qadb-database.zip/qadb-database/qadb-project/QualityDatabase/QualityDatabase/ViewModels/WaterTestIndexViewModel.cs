﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System.Collections.Generic;


namespace QualityDatabase.ViewModels
{
  public class WaterTestIndexViewModel
  {
    public List<WaterTestIndexModel> WaterTestList { get; set; }

    public WaterTestIndexViewModel()
    {

    }

    public void GetWaterTestListForIndex(string _serialNumber)
    {
      WaterTestServices db = new WaterTestServices();
      WaterTestList = db.GetWaterTestForIndex(_serialNumber);
    }
  }
}