﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using QualityDatabase.Models;
using QualityDatabase.Services;
namespace QualityDatabase.ViewModels
{
  public class HoldsResolvedIndexViewModel
  {
    public List<HoldsResolvedModel> HoldsResolvedList { get; set; }

    public void GetHoldsResolvedList(string _serialNumber)
    {
      HoldsResolvedServices db = new HoldsResolvedServices();
      HoldsResolvedList = db.GetHoldsResolvedForIndex(_serialNumber);
    }
  }
}