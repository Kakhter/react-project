﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using QualityDatabase.Services;
using QualityDatabase.Models;
using QualityDatabase.Common;
using QualityDatabase.Validation;

namespace QualityDatabase.ViewModels
{
  public class LineInspectionDeleteViewModel
  {
    [Display(Name = "Date")]
    [DataType(DataType.Date)]
    public DateTime InspectionDate { get; set; }

    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Inspection Create Date")]
    public string InspectionCreateDate { get; set; }

    [Display(Name = "Inspection Create Time")]
    public string InspectionCreateTime { get; set; }

    [Display(Name = "Inspection Created By")]
    public string InspectionCreatedBy { get; set; }

    [Display(Name = "Quality Station")]
    public string InspectionLocation { get; set; }

    [Display(Name = "Offline Operation")]
    public string OfflineOperation { get; set; }

    [Display(Name = "Inspector")]
    public string Inspector { get; set; }

    [Display(Name = "Sequence")]
    public string InspectionType { get; set; }

    [Display(Name = "Area")]
    public string DefectArea { get; set; }

    [Display(Name = "Area Desc")]
    public string AreaDesc { get; set; }

    [Display(Name = "Item")]
    public string DefectItem { get; set; }

    [Display(Name = "Item Desc")]
    public string ItemDesc { get; set; }

    [Display(Name = "Type")]
    public string DefectType { get; set; }

    [Display(Name = "Type Desc")]
    public string TypeDesc { get; set; }

    [Display(Name = "Condition")]
    public string DefectCondition { get; set; }

    [Display(Name = "Condition Desc")]
    public string ConditionDesc { get; set; }

    public LineInspectionDeleteViewModel()
    {
      InspectionDate = DateTime.Today;
      SerialNumber = "";
      InspectionCreateDate = "";
      InspectionCreateTime = "";
      InspectionCreatedBy = "";
      InspectionLocation = " ";
      OfflineOperation = "";
      Inspector = " ";
      InspectionType = " ";
      DefectArea = " ";
      AreaDesc = " ";
      DefectItem = " ";
      ItemDesc = " ";
      DefectType = " ";
      TypeDesc = " ";
      DefectCondition = " ";
      ConditionDesc = " ";
    }

    public void Populate(string _serialNumber, string _createDate, string _createTime, string _defectArea, string _defectType, string _defectCondition, string _defectItem)
    {
      this.SerialNumber = _serialNumber;
      this.InspectionCreateDate = _createDate;
      this.InspectionCreateTime = _createTime;
            this.DefectArea = _defectArea;
            this.DefectType = _defectType;
            this.DefectCondition = _defectCondition;
            this.DefectItem = _defectItem;

            LineInspectionServices db = new LineInspectionServices();
      LineInspectionModel model = null;

      model = db.GetSingleLineInspectionForDelete(SerialNumber, InspectionCreateDate, InspectionCreateTime, DefectArea, DefectType, DefectCondition, DefectItem);

      this.InspectionDate = model.InspectionDate;
      this.InspectionLocation = model.InspectionLocation;
      this.OfflineOperation = model.OfflineDescription;
      this.Inspector = model.Inspector;
      this.InspectionType = model.InspectionType;
      this.DefectArea = model.DefectArea;
      this.AreaDesc = model.AreaDesc;
      this.DefectItem = model.DefectItem;
      this.ItemDesc = model.ItemDesc;
      this.DefectType = model.DefectType;
      this.TypeDesc = model.TypeDesc;
      this.DefectCondition = model.DefectCondition;
      this.ConditionDesc = model.ConditionDesc;
      this.InspectionCreateDate = model.InspectionCreateDate;
      this.InspectionCreateTime = model.InspectionCreateTime;
      this.InspectionCreatedBy = model.InspectionCreatedBy;
    }

    public List<ValidationError> Delete(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.InspectionCreatedBy = _user;

      ValLineInspectionDelete valDelete = new ValLineInspectionDelete();
      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(GetLineInspectionModel());
      if (ErrorList.Count > 0)
        return ErrorList;

      LineInspectionServices db = new LineInspectionServices();
      LineInspectionModel model = GetLineInspectionModel();

      string ErrorMsg = "";
      ErrorMsg = db.DeleteLineInspection(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    public LineInspectionModel GetLineInspectionModel()
    {
      var item = this;
      LineInspectionModel model = new LineInspectionModel();
      model.InspectionDate = this.InspectionDate;
      model.InspectionLocation = this.InspectionLocation;
      model.OfflineOperation = this.OfflineOperation;
      model.Inspector = this.Inspector;
      model.InspectionType = this.InspectionType;
      model.DefectArea = this.DefectArea;
      model.DefectItem = this.DefectItem;
      model.DefectType = this.DefectType;
      model.DefectCondition = this.DefectCondition;
      model.SerialNumber = this.SerialNumber;
      model.InspectionCreateDate = this.InspectionCreateDate;
      model.InspectionCreateTime = this.InspectionCreateTime;
      model.InspectionCreatedBy = this.InspectionCreatedBy;
      return model;
    }
  }
}