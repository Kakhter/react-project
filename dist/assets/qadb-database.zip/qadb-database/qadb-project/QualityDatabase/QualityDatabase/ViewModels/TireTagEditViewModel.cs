﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class TireTagEditViewModel
  {
    [DisplayFormat(DataFormatString = "{0:#####}")]
    [Display(Name = "GVRW")]
    public int GVRW { get; set; }

    [DisplayFormat(DataFormatString = "{0:#####}")]
    [Display(Name = "Vehicle Weight")]
    public int VehicleWeight { get; set; }

    [Display(Name = "Fuel Type")]
    public string FuelType { get; set; }

    public IEnumerable<SelectListItem> FuelTypeList
    {
      get
      {
        var db = new FuelTypeServices();
        var query = db.FuelTypeList.Select(c => new { c.Code, c.Description });
        return new SelectList(query.AsEnumerable(), "Code", "Description", FuelType);
      }
    }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Tank Size")]
    public double TankSize { get; set; }

    [DisplayFormat(DataFormatString = "{0:##}")]
    [Display(Name = "Front Seat Capacity")]
    public double FrontSeatCapacity { get; set; }

    [DisplayFormat(DataFormatString = "{0:##}")]
    [Display(Name = "Rear Seat Capacity")]
    public double RearSeatCapacity { get; set; }

    public string SerialNumber { get; set; }
    public string TireCreateDate { get; set; }
    public string TireCreateTime { get; set; }
    public string TireUser { get; set; }

    public TireTagEditViewModel()
    {
      GVRW = 0;
      VehicleWeight = 0;
      FuelType = "";
      TankSize = 0;
      FrontSeatCapacity = 0;
      RearSeatCapacity = 0;
      SerialNumber = "";
      TireCreateDate = "";
      TireCreateTime = "";
      TireUser = "";
    }

    public void Populate(string _serialNumber)
    {
      this.SerialNumber = _serialNumber;

      TireTagServices db = new TireTagServices();
      GVRWServices dbGVRW = new GVRWServices();
      VehicleWeightServices dbWeight = new VehicleWeightServices();

      TireTagModel model = null;

      model = db.GetTireTag(_serialNumber);

      this.FuelType = model.FuelType.Trim();
      this.TankSize = model.TankSize;
      this.FrontSeatCapacity = model.FrontSeatCapacity;
      this.RearSeatCapacity = model.RearSeatCapacity;
      this.TireCreateDate = model.TireCreateDate;
      this.TireCreateTime = model.TireCreateTime;
      this.TireUser = model.TireCreatedBy;

      GVRWModel modelGVRW = dbGVRW.GetGVRW(_serialNumber);
      this.GVRW = modelGVRW.GVRW;

      VehicleWeightModel modelWeight = dbWeight.GetVehicleWeight(_serialNumber);
      this.VehicleWeight = modelWeight.VehicleWeight;
    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.TireUser = _user;

      ValTireTagEdit valEdit = new ValTireTagEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetTireTag());
      if (ErrorList.Count > 0)
        return ErrorList;

      TireTagServices db = new TireTagServices();
      TireTagModel model = GetTireTag();

      string ErrorMsg = "";
      ErrorMsg = db.UpdateTireTag(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    private TireTagModel GetTireTag()
    {
      TireTagModel model = new TireTagModel();
      model.VehicleWeight = this.VehicleWeight;
      model.FuelType = this.FuelType;
      model.TankSize = this.TankSize;
      model.FrontSeatCapacity = this.FrontSeatCapacity;
      model.RearSeatCapacity = this.RearSeatCapacity;
      model.SerialNumber = this.SerialNumber;
      model.TireCreateDate = this.TireCreateDate;
      model.TireCreateTime = this.TireCreateTime;
      model.TireCreatedBy = this.TireUser;
      return model;
    }
  }
}