﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class LineRepairEditViewModel
  {
    [Display(Name = "Action")]
    public string RepairAction { get; set; }

    public IEnumerable<SelectListItem> RepairActionList
    {
      get
      {
        var db = new RepairActionServices();
        var query = db.RepairActionList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
        return new SelectList(query.AsEnumerable(), "Code", "Description", RepairAction);
      }
    }


    [Display(Name = "Minutes")]
    public int RepairTimeMinutes { get; set; }

    public string LineRepairCreateDate { get; set; }
    public string LineRepairCreateTime { get; set; }
    public string LineRepairCreatedBy { get; set; }
    public string SerialNumber { get; set; }
    public string InspectionCreateDate { get; set; }
    public string InspectionCreateTime { get; set; }

    public LineRepairEditViewModel()
    {
      RepairAction = "";
      RepairTimeMinutes = 0;
    }

    public void Populate(string _serialNumber, string _createDate, string _createTime)
    {
      this.SerialNumber = _serialNumber;
      this.InspectionCreateDate = _createDate;
      this.InspectionCreateTime = _createTime;

      LineRepairServices db = new LineRepairServices();
      LineRepairModel model = null;

      model = db.GetSingleLineRepair(SerialNumber, InspectionCreateDate, InspectionCreateTime);

      this.RepairAction = model.RepairAction;
      this.RepairTimeMinutes = model.RepairTimeMinutes;
      this.LineRepairCreateDate = model.RepairCreateDate;
      this.LineRepairCreateTime = model.RepairCreateTime;
      this.LineRepairCreatedBy = model.RepairCreatedBy;
    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.LineRepairCreatedBy = _user;

      ValLineRepairEdit valEdit = new ValLineRepairEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetValidationParameters());
      if (ErrorList.Count > 0)
        return ErrorList;

      LineRepairServices db = new LineRepairServices();
      LineRepairModel model = GetLineRepairModel();

      string ErrorMsg = "";
      ErrorMsg = db.UpdateLineRepair(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    private LineRepairModel GetValidationParameters()
    {
      LineRepairModel param = new LineRepairModel();
      param.RepairAction = this.RepairAction;
      param.RepairTimeMinutes = this.RepairTimeMinutes;
      return param;
    }

    private LineRepairModel GetLineRepairModel()
    {
      LineRepairModel model = new LineRepairModel();
      model.RepairAction = this.RepairAction;
      model.RepairTimeMinutes = this.RepairTimeMinutes;
      model.RepairCreateDate = this.LineRepairCreateDate;
      model.RepairCreateTime = this.LineRepairCreateTime;
      model.RepairCreatedBy = this.LineRepairCreatedBy;
      model.SerialNumber = this.SerialNumber;
      model.InspectionCreateDate = this.InspectionCreateDate;
      model.InspectionCreateTime = this.InspectionCreateTime;
      return model;
    }

  }
}