﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;


namespace QualityDatabase.ViewModels
{
  public class TorqueEditViewModel
  {
    [DisplayFormat(DataFormatString = "{0:##}")]
    [Display(Name = "Ubolt Number")]
    public double UboltNumber { get; set; }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Ubolt Street Side")]
    public double UboltStreetSide { get; set; }

    [DisplayFormat(DataFormatString = "{0:###.##}")]
    [Display(Name = "Ubolt Curb Side")]
    public double UboltCurbSide { get; set; }

    [Display(Name = "Inspector")]
    public string Inspector { get; set; }

    public IEnumerable<SelectListItem> IndividualsList
    {
      get
      {
        var db = new IndividualsServices(Division);
        var query = db.IndividualsList.Select(c => new { c.NameID, c.Name });
        return new SelectList(query.AsEnumerable(), "NameID", "Name", Inspector);
      }
    }


    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Torque Create Date")]
    public string TorqueCreateDate { get; set; }

    [Display(Name = "Torque Create Time")]
    public string TorqueCreateTime { get; set; }

    [Display(Name = "Inspection Created By")]
    public string TorqueCreatedBy { get; set; }

    public string Division { get; set; }

    public TorqueEditViewModel()
    {
      UboltNumber = 0;
      UboltStreetSide = 0;
      UboltCurbSide = 0;
      Inspector = "";
      SerialNumber = "";
      TorqueCreateDate = "";
      TorqueCreateTime = "";
      TorqueCreatedBy = "";
      Division = "";
    }

    public void Populate(string _serialNumber, string _createDate, string _createTime)
    {
      this.SerialNumber = _serialNumber;
      this.TorqueCreateDate = _createDate;
      this.TorqueCreateTime = _createTime;

      TorqueServices db = new TorqueServices();
      TorqueModel model = null;

      model = db.GetSingleTorque(SerialNumber, TorqueCreateDate, TorqueCreateTime);

      this.SerialNumber = model.SerialNumber;
      this.UboltNumber = model.UboltNumber;
      this.UboltStreetSide = model.UboltStreetSide;
      this.UboltCurbSide = model.UboltCurbSide;
      this.Inspector = model.Inspector;
      this.TorqueCreateDate = model.TorqueCreateDate;
      this.TorqueCreateTime = model.TorqueCreateTime;
      this.TorqueCreatedBy = model.TorqueCreatedBy;

      DivisionService dbDiv = new DivisionService();
      this.Division = dbDiv.GetDivision(_serialNumber);
    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.TorqueCreatedBy = _user;

      ValTorqueEdit valEdit = new ValTorqueEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetTorqueModel());
      if (ErrorList.Count > 0)
        return ErrorList;

      TorqueModel model = GetTorqueModel();
      TorqueServices db = new TorqueServices();

      string ErrorMsg = "";
      ErrorMsg = db.UpdateTorque(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    public TorqueModel GetTorqueModel()
    {
      TorqueModel model = new TorqueModel();
      model.UboltNumber = this.UboltNumber;
      model.UboltStreetSide = this.UboltStreetSide;
      model.UboltCurbSide = this.UboltCurbSide;
      model.Inspector = this.Inspector;
      model.SerialNumber = this.SerialNumber;
      model.TorqueCreateDate = this.TorqueCreateDate;
      model.TorqueCreateTime = this.TorqueCreateTime;
      model.TorqueCreatedBy = this.TorqueCreatedBy;
      return model;
    }
  }
}