﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.ViewModels
{
  public class InfoIndexViewModel
  {
    public List<HoldsResolvedModel> HoldsList { get; set; }

    public List<TRSModel> TRSList { get; set; }

    public List<WaterTestIndexModel> WaterTestList { get; set; }

    public List<LineInspectionModel> LineInspectionList { get; set; }

    public void GetLists(string _serialNumber, string _orderNumber)
    {
      HoldsResolvedServices db = new HoldsResolvedServices();
      HoldsList = db.GetHoldsResolvedForIndex(_serialNumber);

      TRSServices dbTRS = new TRSServices();
      TRSList = dbTRS.GetTRSRecords(_orderNumber);

      WaterTestServices dbWT = new WaterTestServices();
      WaterTestList = dbWT.GetWaterTestForIndex(_serialNumber);

      LineInspectionServices dbLI = new LineInspectionServices();
      LineInspectionList = dbLI.GetLineInspectionForIndex(_serialNumber);

    }

  }
}