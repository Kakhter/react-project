﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.ViewModels
{
  public class HoldIssuesDeleteViewModel
  {
    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Category")]
    public string Category { get; set; }

    [Display(Name = "Category Description")]
    public string CategoryDescription { get; set; }

    [Display(Name = "Description")]
    public string Description { get; set; }

    [Display(Name = "Hold Create Date")]
    public string HoldCreateDate { get; set; }

    [Display(Name = "Hold Create Time")]
    public string HoldCreateTime { get; set; }

    [Display(Name = "Hold Created By")]
    public string HoldCreatedBy { get; set; }

    [Display(Name = "Quality Station")]
    public string Hold { get; set; }

        public HoldIssuesDeleteViewModel()
    {
      SerialNumber = "";
      Category = "";
      CategoryDescription = "";
      Description = "";
      HoldCreateDate = "";
      HoldCreateTime = "";
      HoldCreatedBy = "";
      Hold = "";
    }

     public void Populate(string _serialNumber, string _createDate, string _createTime)
     {
       this.SerialNumber = _serialNumber;
       this.HoldCreateDate = _createDate;
       this.HoldCreateTime = _createTime;

       HoldIssuesServices db = new HoldIssuesServices();
       HoldIssuesModel model = null;

       model = db.GetSingleHoldIssue(SerialNumber, HoldCreateDate, HoldCreateTime);
       this.Category = model.Category;
       this.Description = model.Description;
       this.HoldCreateDate = model.HoldCreateDate;
       this.HoldCreateTime = model.HoldCreateTime;
       this.HoldCreatedBy = model.HoldCreatedBy;
       this.CategoryDescription = model.CategoryDescription;
       this.Hold = model.Hold;
     }

     public List<ValidationError> Delete(string _serialNumber, string _user)
     {
       this.SerialNumber = _serialNumber;
       this.HoldCreatedBy = _user;

       ValHoldIssueDelete valDelete = new ValHoldIssueDelete();

       List<ValidationError> ErrorList = new List<ValidationError>();
       ErrorList = valDelete.Validate(GetHoldIssuesModel());
       if (ErrorList.Count > 0)
         return ErrorList;

       HoldIssuesModel model = GetHoldIssuesModel();
       HoldIssuesServices db = new HoldIssuesServices();

       string ErrorMsg = "";
       ErrorMsg = db.DeleteHoldIssue(model);
       if (ErrorMsg != "")
       {
         ValidationError valError = new ValidationError();
         valError.Key = "";
         valError.Message = ErrorMsg;
         ErrorList.Add(valError);
       }
       return ErrorList;
     }

     private HoldIssuesModel GetHoldIssuesModel()
     {
       HoldIssuesModel model = new HoldIssuesModel();
       model.Category = this.Category;
       model.Description = this.Description;
       model.HoldCreateDate = this.HoldCreateDate;
       model.HoldCreatedBy = this.HoldCreatedBy;
       model.HoldCreateTime = this.HoldCreateTime;
       model.SerialNumber = this.SerialNumber;
       model.Hold = this.Hold;
       return model;
     }
  }
}