﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace QualityDatabase.ViewModels
{
  public class WaterTestDeleteViewModel
  {
    [Display(Name = "Date")]
    public string WaterTestDate { get; set; }

    [Display(Name = "Pressure")]
    public string WaterPressure { get; set; }

    [Display(Name = "Gallons per Minute")]
    public string GallonsPerMinute { get; set; }

    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Display(Name = "Water Test Create Date")]
    public string WaterTestCreateDate { get; set; }

    [Display(Name = "Water Test Create Time")]
    public string WaterTestCreateTime { get; set; }

    [Display(Name = "Water Test Created By")]
    public string WaterTestCreatedBy { get; set; }

    [Display(Name = "Area")]
    public string DefectArea { get; set; }

    [Display(Name = "Area Desc")]
    public string AreaDesc { get; set; }

    [Display(Name = "Item")]
    public string DefectItem { get; set; }

    [Display(Name = "Item Desc")]
    public string ItemDesc { get; set; }

    [Display(Name = "Type")]
    public string DefectType { get; set; }

    [Display(Name = "Type Desc")]
    public string TypeDesc { get; set; }

    [Display(Name = "Sequence")]
    public string InspectionType { get; set; }

    [Display(Name = "Leak Description")]
    public string Category { get; set; }


        public WaterTestDeleteViewModel()
    {
      //wt = new WaterTest();
      DefectArea = "";
      AreaDesc = "";
      DefectItem = "";
      ItemDesc = "";
      DefectType = "";
      TypeDesc = "";
      InspectionType = "";
      WaterTestDate = "";
      WaterPressure = "";
      GallonsPerMinute = "";
      SerialNumber = "";
      WaterTestCreateDate = "";
      WaterTestCreateTime = "";
      Category = "";
    }

    public void Populate(string _serialNumber, string _createDate, string _createTime)
    {
      this.SerialNumber = _serialNumber;
      this.WaterTestCreateDate = _createDate;
      this.WaterTestCreateTime = _createTime;

      WaterTestServices db = new WaterTestServices();
      WaterTestIndexModel model = null;

      model = db.GetSingleWaterTestForDelete(SerialNumber, WaterTestCreateDate, WaterTestCreateTime);

      this.WaterTestDate = model.WaterTestDate; // model.WaterTestDate.ToString("d");
      this.InspectionType = model.InspectionType;
      this.DefectArea = model.DefectArea;
      this.AreaDesc = model.AreaDesc;
      this.DefectItem = model.DefectItem;
      this.ItemDesc = model.ItemDesc;
      this.DefectType = model.DefectType;
      this.TypeDesc = model.TypeDesc;
      this.GallonsPerMinute = model.GallonsPerMinute;
      this.WaterPressure = model.WaterPressure;
      this.Category = model.Category;

    }

    public List<ValidationError> Delete(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.WaterTestCreatedBy = _user;

      ValWaterTestDelete valDelete = new ValWaterTestDelete();
      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(GetValidationParameters());
      if (ErrorList.Count > 0)
        return ErrorList;

      WaterTestServices db = new WaterTestServices();
      WaterTestModel wt = GetWaterTestModel();

      string ErrorMsg = "";
      ErrorMsg = db.DeleteWaterTest(wt);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    private ValWaterTestParameters GetValidationParameters()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      //param.WaterTestDate = this.WaterTestDate;
      param.WaterPressure = this.WaterPressure;
      param.GallonsPerMinute = this.GallonsPerMinute;
      param.SerialNumber = this.SerialNumber;
      param.WaterTestCreateDate = this.WaterTestCreateDate;
      param.WaterTestCreateTime = this.WaterTestCreateTime;
      param.WaterTestCreatedBy = this.WaterTestCreatedBy;
      param.DefectArea = this.DefectArea;
      param.DefectItem = this.DefectItem;
      param.DefectType = this.DefectType;
      param.InspectionType = this.InspectionType;
      return param;
    }
    
    private WaterTestModel GetWaterTestModel()
    {
      WaterTestModel wtm = new WaterTestModel();
      //wtm.WaterTestDate = this.WaterTestDate;
      wtm.WaterPressure = this.WaterPressure;
      wtm.GallonsPerMinute = this.GallonsPerMinute;
      wtm.SerialNumber = this.SerialNumber;
      wtm.WaterTestCreateDate = this.WaterTestCreateDate;
      wtm.WaterTestCreateTime = this.WaterTestCreateTime;
      wtm.WaterTestCreatedBy = this.WaterTestCreatedBy;
      wtm.DefectArea = this.DefectArea;
      wtm.DefectItem = this.DefectItem;
      wtm.DefectType = this.DefectType;
      wtm.InspectionType = this.InspectionType;
      return wtm;
    }


  }
}