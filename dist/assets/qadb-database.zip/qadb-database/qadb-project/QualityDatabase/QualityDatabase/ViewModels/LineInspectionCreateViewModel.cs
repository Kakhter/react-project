﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
    public class LineInspectionCreateViewModel
    {
        [Required(ErrorMessage = "Date is required")]
        [Display(Name = "Date")]
        [DataType(DataType.Date)]
        public DateTime InspectionDate { get; set; }

        [Display(Name = "Serial #")]
        public string SerialNumber { get; set; }

        [Display(Name = "Inspection Create Date")]
        public string InspectionCreateDate { get; set; }

        [Display(Name = "Inspection Create Time")]
        public string InspectionCreateTime { get; set; }

        [Display(Name = "Inspection Created By")]
        public string InspectionCreatedBy { get; set; }

        //[Required(ErrorMessage = "Quality Station is required")]
        [Display(Name = "Quality Station")]
        public string InspectionLocation { get; set; }



        public IEnumerable<SelectListItem> InspectionLocationList
        {
            get
            {
                var db = new InspectionLocationService();
                var query = db.InspectionLocationList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", InspectionLocation);
            }
        }

        [Display(Name = "Offline Operation")]
        public string OfflineOperation { get; set; }

        public IEnumerable<SelectListItem> OfflineOperationList
        {
            get
            {
                OfflineOperation = "";
                var db = new OfflineOperationService();
                var query = db.OfflineOperationList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", OfflineOperation);
            }
        }

        //[Required(ErrorMessage = "Inspector is required")]
        [Display(Name = "Inspector")]
        public string Inspector { get; set; }

        public IEnumerable<SelectListItem> IndividualsList
        {
            get
            {
                var db = new IndividualsServices(Division);
                var query = db.IndividualsList.Select(c => new { c.NameID, c.Name });
                return new SelectList(query.AsEnumerable(), "NameID", "Name", Inspector);
            }
        }

        //[Required(ErrorMessage = "Sequence is required")]
        [Display(Name = "Sequence")]
        public string InspectionType { get; set; }

        public IEnumerable<SelectListItem> InspectionTypeList
        {
            get
            {
                var db = new InspectionTypeServices();
                var query = db.LineInspectionInspectionTypeList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                InspectionType = "INIT";
                return new SelectList(query.AsEnumerable(), "Code", "Description", InspectionType);
            }
        }

        [Required(ErrorMessage = "Area is required")]
        [Display(Name = "Area")]
        public string DefectArea { get; set; }

        public IEnumerable<SelectListItem> DefectAreaList
        {
            get
            {
                var db = new DefectAreaServices();
                var query = db.LineInspectionAreaList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", DefectArea);
            }
        }



        [Required(ErrorMessage = "Item is required")]
        [Display(Name = "Item")]
        public string DefectItem { get; set; }

        /*public IEnumerable<SelectListItem> DefectItemList
        {
            get
            {
                var db = new DefectItemServices();
                var query = db.LineInspectionItemList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", DefectItem);
            }
        }*/

        public IDictionary<string, List<SelectListItem>> DefectItemList
        {
            get
            {
                var db = new DefectItemServices();

                var query = db.LineInspectionItemList.Select(c => new SelectListItem
                {
                    Value = c.Code,
                    Text = c.Code.Trim() + " - " + c.Description.Trim(),
                    Selected = c.Code == DefectCondition
                });

                var dict = new Dictionary<string, List<SelectListItem>>();

                return dict;
            }
        }

        [Required(ErrorMessage = "Type is required")]
        [Display(Name = "Type")]
        public string DefectType { get; set; }

        public IEnumerable<SelectListItem> DefectTypeList
        {
            get
            {
                var db = new DefectTypeServices();
                var query = db.LineInspectionTypeList.Select(c => new { c.Code, Description = c.Code.Trim() + " - " + c.Description.Trim() });
                return new SelectList(query.AsEnumerable(), "Code", "Description", DefectType);
            }
        }

        [Required(ErrorMessage = "Condition is required")]
        [Display(Name = "Condition")]
        public string DefectCondition { get; set; }


        public IDictionary<string, List<SelectListItem>> DefectConditionList
        {
            get
            {
                var db = new DefectConditionServices();

                var query = db.LineInspectionConditionList.Select(c => new SelectListItem
                {
                    Value = c.Code,
                    Text = c.Code.Trim() + " - " + c.Description.Trim(),
                    Selected = c.Code == DefectCondition
                });

                var dict = new Dictionary<string, List<SelectListItem>>();

                return dict;
            }
        }

        public string Division { get; set; }

        public LineInspectionCreateViewModel()
        {
            InspectionDate = DateTime.Today;
            InspectionLocation = " ";
            OfflineOperation = " ";
            Inspector = " ";
            InspectionType = " ";
            DefectArea = " ";
            DefectItem = " ";
            DefectType = " ";
            DefectCondition = " ";
            SerialNumber = "";
            InspectionCreateDate = "";
            InspectionCreateTime = "";
            InspectionCreatedBy = "";
            Division = "";
        }

        public void Populate(string _serialNumber)
        {
            DivisionService db = new DivisionService();
            Division = db.GetDivision(_serialNumber);

            LineInspectionServices lineInspectionServices = new LineInspectionServices();
            DateTime? lastEntryDate = lineInspectionServices.GetLastEntryDateFromQLIF(_serialNumber);

            InspectionDate = lastEntryDate ?? DateTime.Today;
        }

        public List<ValidationError> Save(string _serialNumber, string _user, LineInspectionModel _params)
        {
            this.SerialNumber = _serialNumber;
            this.InspectionCreatedBy = _user;

            ValLineInspectionCreate valCreate = new ValLineInspectionCreate();

            List<ValidationError> ErrorList = new List<ValidationError>();
            ErrorList = valCreate.Validate(_params);
            if (ErrorList.Count > 0)
                return ErrorList;

            LineInspectionModel model = _params;
            model.SerialNumber = _serialNumber;
            model.InspectionCreatedBy = _user;
            LineInspectionServices db = new LineInspectionServices();

            string ErrorMsg = "";
            ErrorMsg = db.AddLineInspection(model);
            if (ErrorMsg != "")
            {
                ValidationError valError = new ValidationError();
                valError.Key = "";
                valError.Message = ErrorMsg;
                ErrorList.Add(valError);
            }
            return ErrorList;
        }

        public List<ValidationError> Save(string _serialNumber, string _user, LineInspectionModel _params, string passFail)
        {
            this.SerialNumber = _serialNumber;
            this.InspectionCreatedBy = _user;

            ValLineInspectionCreate valCreate = new ValLineInspectionCreate();

            List<ValidationError> ErrorList = new List<ValidationError>();
            ErrorList = valCreate.Validate(_params);
            if (ErrorList.Count > 0)
                return ErrorList;

            LineInspectionModel model = _params;
            model.SerialNumber = _serialNumber;
            model.InspectionCreatedBy = _user;
            LineInspectionServices db = new LineInspectionServices();

            string ErrorMsg = "";
            ErrorMsg = db.AddLineInspection(model);
            if (ErrorMsg != "")
            {
                ValidationError valError = new ValidationError();
                valError.Key = "";
                valError.Message = ErrorMsg;
                ErrorList.Add(valError);
            }
            string ErrorMsgPassFail = "";
            // ErrorMsgPassFail = db.UpsertPassFail(model.SerialNumber, passFail);
            if (ErrorMsgPassFail != "")
            {
                ValidationError valError = new ValidationError();
                valError.Key = "";
                valError.Message = ErrorMsg;
                ErrorList.Add(valError);
            }
            return ErrorList;
        }


        public LineInspectionModel GetLineInspectionModel()
        {
            LineInspectionModel model = new LineInspectionModel();
            model.InspectionDate = this.InspectionDate;
            model.InspectionLocation = this.InspectionLocation;
            model.OfflineOperation = this.OfflineOperation;
            model.Inspector = this.Inspector;
            model.InspectionType = this.InspectionType;
            model.DefectArea = this.DefectArea;
            model.DefectItem = this.DefectItem;
            model.DefectType = this.DefectType;
            model.DefectCondition = this.DefectCondition;
            model.SerialNumber = this.SerialNumber;
            model.InspectionCreateDate = this.InspectionCreateDate;
            model.InspectionCreateTime = this.InspectionCreateTime;
            model.InspectionCreatedBy = this.InspectionCreatedBy;
            model.ResetNullValues();
            return model;
        }

    }
}