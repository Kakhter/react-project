﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using QualityDatabase.Models;
using QualityDatabase.Services;

namespace QualityDatabase.ViewModels
{
  public class LineRepairIndexViewModel
  {
    public List<LineRepairIndexModel> LineRepairList { get; set; }

    public LineRepairIndexViewModel()
    {
    }

    public void GetListRepairListForIndex(string _serialNumber)
    {
      LineRepairServices db = new LineRepairServices();
      LineRepairList = db.GetLineRepairForIndex(_serialNumber);
    }
  }
}