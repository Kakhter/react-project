﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QualityDatabase.ViewModels
{
  public class TireTagIndexViewModel
  {
    public List<TireTagModel> TireTagList { get; set; }

    public void GetTireTagListForIndex(string _serialNumber)
    {
      TireTagServices db = new TireTagServices();
      TireTagList = db.GetTireTagsForIndex(_serialNumber);

      GVRWServices dbGVRW = new GVRWServices();
      VehicleWeightServices dbWeight = new VehicleWeightServices();

      foreach (TireTagModel model in TireTagList)
      {
        GVRWModel modelGVRW = dbGVRW.GetGVRW(_serialNumber);
        model.GVRW = modelGVRW.GVRW;

        VehicleWeightModel modelWeight = dbWeight.GetVehicleWeight(_serialNumber);
        model.VehicleWeight = modelWeight.VehicleWeight;

        model.VehicleCapacitylbs = CalculateVehicleCapacitylbs(model.TankSize, model.GVRW, model.VehicleWeight, _serialNumber);
        model.VehicleCapacitykg = CalculateVehicleCapacitykg(model.VehicleCapacitylbs);
      }
    }

    private int CalculateVehicleCapacitylbs(double _tankSize, int _gvrw, int _vehicleWeight, string _serialNumber)
    {
      int lbs = 0;
      double fuelWeight = 0;

      if ((_tankSize == 0) || (_gvrw == 0) || (_vehicleWeight == 0))
        return 0;

      FuelServices fuelDB = new FuelServices();
      FuelModel model = fuelDB.GetFuel(_serialNumber);

      if (model.FuelType.ToUpper() == "GAS")
        fuelWeight = _tankSize * 6;
      else if (model.FuelType.ToUpper() == "DSL")
        fuelWeight = _tankSize * 7;
      else if (model.FuelType.ToUpper() == "PRO")
        fuelWeight = _tankSize * 4;
      else
        return 0;

      lbs = _gvrw - _vehicleWeight - Convert.ToInt32(fuelWeight);

      return lbs;
    }

    private int CalculateVehicleCapacitykg(int _lbs)
    {
      double kg = 0;
      if (_lbs == 0)
        return 0;

      kg = _lbs * 0.4536;

      return Convert.ToInt32(kg);
    }

  }
}