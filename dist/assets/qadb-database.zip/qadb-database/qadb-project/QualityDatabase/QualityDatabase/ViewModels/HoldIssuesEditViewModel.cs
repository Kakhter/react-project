﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class HoldIssuesEditViewModel
  {
    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Required(ErrorMessage = "Category is required.")]
    [Display(Name = "Category")]
    public string Category { get; set; }

    public IEnumerable<SelectListItem> CategoryList
    {
      get
      {
        var db = new HoldCategoryServices();
        var query = db.HoldCategoryList.Select(c => new { c.Code, c.Description });
        return new SelectList(query.AsEnumerable(), "Code", "Description", Category);
      }
    }

    [Display(Name = "Description")]
    public string Description { get; set; }

    [Display(Name = "Hold Create Date")]
    public string HoldCreateDate { get; set; }

    [Display(Name = "Hold Create Time")]
    public string HoldCreateTime { get; set; }

    [Display(Name = "Hold Created By")]
    public string HoldCreatedBy { get; set; }

    [Display(Name = "Quality Station")]
    public string Hold { get; set; }

    public IEnumerable<SelectListItem> HoldList
    {
        get
        {
            return new SelectList(new[] { "Line", "Final", "Offline Station" });
        }
    }

        public HoldIssuesEditViewModel()
    {
      SerialNumber = "";
      Category = "";
      Description = "";
      HoldCreateDate = "";
      HoldCreateTime = "";
      HoldCreatedBy = "";
      Hold = "";
    }

    public void Populate(string _serialNumber, string _createDate, string _createTime)
    {
      this.SerialNumber = _serialNumber;
      this.HoldCreateDate = _createDate;
      this.HoldCreateTime = _createTime;

      HoldIssuesServices db = new HoldIssuesServices();
      HoldIssuesModel model = null;

      model = db.GetSingleHoldIssue(SerialNumber, HoldCreateDate, HoldCreateTime);
      this.Category = model.Category;
      this.Description = model.Description;
      this.HoldCreateDate = model.HoldCreateDate;
      this.HoldCreateTime = model.HoldCreateTime;
      this.HoldCreatedBy = model.HoldCreatedBy;
      this.Hold = model.Hold;
    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.HoldCreatedBy = _user;

      ValHoldIssueEdit valEdit = new ValHoldIssueEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(GetHoldIssuesModel());
      if (ErrorList.Count > 0)
        return ErrorList;

      HoldIssuesModel model = GetHoldIssuesModel();
      HoldIssuesServices db = new HoldIssuesServices();

      string ErrorMsg = "";
      ErrorMsg = db.UpdateHoldIssue(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    private HoldIssuesModel GetHoldIssuesModel()
    {
      HoldIssuesModel model = new HoldIssuesModel();
      model.Category = this.Category;
      model.Description = this.Description;
      model.HoldCreateDate = this.HoldCreateDate;
      model.HoldCreatedBy = this.HoldCreatedBy;
      model.HoldCreateTime = this.HoldCreateTime;
      model.SerialNumber = this.SerialNumber;
      model.Hold = this.Hold;
      return model;
    }
  }
}