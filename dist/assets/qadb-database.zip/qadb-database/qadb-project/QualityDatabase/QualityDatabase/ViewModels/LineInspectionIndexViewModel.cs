﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System.Collections.Generic;

namespace QualityDatabase.ViewModels
{
  public class LineInspectionIndexViewModel
  {
    public List<LineInspectionModel> LineInspectionList { get; set; }
    public List<TorqueModel> TorqueList { get; set; }

    public void GetLineInspectionListForIndex(string _serialNumber)
    {
      LineInspectionServices db = new LineInspectionServices();
      LineInspectionList = db.GetLineInspectionForIndex(_serialNumber);

      TorqueServices dbTorque = new TorqueServices();
      TorqueList = dbTorque.GetTorqueForIndex(_serialNumber);
    }
  }
}