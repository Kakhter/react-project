﻿using QualityDatabase.Models;
using QualityDatabase.Services;
using System.Collections.Generic;

namespace QualityDatabase.ViewModels
{
  public class FuelViewModel
  {
    public List<FuelModel> FuelList { get; set; }

    public FuelViewModel()
    {
    }

    public void GetFuelListForIndex(string _serialNumber)
    {
      FuelServices db = new FuelServices();
      FuelList = db.GetFuelForIndex(_serialNumber);
    }
  }
}