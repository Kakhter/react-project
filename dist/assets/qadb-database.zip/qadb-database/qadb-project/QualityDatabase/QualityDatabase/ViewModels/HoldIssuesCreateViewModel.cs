﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.Validation;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace QualityDatabase.ViewModels
{
  public class HoldIssuesCreateViewModel
  {
    [Display(Name = "Serial #")]
    public string SerialNumber { get; set; }

    [Required(ErrorMessage = "Category is required.")]
    [Display(Name = "Category")]
    public string Category { get; set; }

    [Display(Name = "Quality Station")]
    public string Hold { get; set; }

    public IEnumerable<SelectListItem> CategoryList
    {
      get
      {
        var db = new HoldCategoryServices();
        var query = db.HoldCategoryList.Select(c => new { c.Code, c.Description });
        return new SelectList(query.AsEnumerable(), "Code", "Description", Category);
      }
    }

        public IEnumerable<SelectListItem> HoldList
        {
            get
            {
                //var db = new HoldCategoryServices();
                //var query = db.HoldCategoryList.Select(c => new { c.Code, c.Description });
                //return new SelectList("Code", "Description", Hold);

                return  new SelectList(new[] { "Line", "Final", "Offline Station" });
            }
        }

    [Display(Name = "Description")]
    public string Description { get; set; }

    [Display(Name = "Hold Create Date")]
    public string HoldCreateDate { get; set; }

    [Display(Name = "Hold Create Time")]
    public string HoldCreateTime { get; set; }

    [Display(Name = "Hold Created By")]
    public string HoldCreatedBy { get; set; }

    public HoldIssuesCreateViewModel()
    {
      SerialNumber = "";
      Category = "";
      Hold = "";
      Description = "";
      HoldCreateDate = "";
      HoldCreateTime = "";
      HoldCreatedBy = "";
    }

    public List<ValidationError> Save(string _serialNumber, string _user)
    {
      this.SerialNumber = _serialNumber;
      this.HoldCreatedBy = _user;

      ValHoldIssueCreate valCreate = new ValHoldIssueCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(GetHoldIssuesModel());
      if (ErrorList.Count > 0)
        return ErrorList;

      HoldIssuesModel model = GetHoldIssuesModel();
      HoldIssuesServices db = new HoldIssuesServices();

      string ErrorMsg = "";
      ErrorMsg = db.AddHoldIssue(model);
      if (ErrorMsg != "")
      {
        ValidationError valError = new ValidationError();
        valError.Key = "";
        valError.Message = ErrorMsg;
        ErrorList.Add(valError);
      }
      return ErrorList;
    }

    public HoldIssuesModel GetHoldIssuesModel()
    {
      HoldIssuesModel model = new HoldIssuesModel();
      model.SerialNumber = this.SerialNumber;
      model.Category = this.Category;
      model.Hold = this.Hold;
      model.Description = this.Description;
      model.HoldCreateDate = this.HoldCreateDate;
      model.HoldCreateTime = this.HoldCreateTime;
      model.HoldCreatedBy = this.HoldCreatedBy;
      return model;
    }
  }
}