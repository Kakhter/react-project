﻿using QualityDatabase.Common;
using QualityDatabase.ViewModels;
using QualityDatabase.Models;
using System.Collections.Generic;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.IO;
using QualityDatabase.Services;
using System.Linq;
using System;

namespace QualityDatabase.Controllers
{
    public class JsonModelBinder : IModelBinder
    {
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            var request = controllerContext.HttpContext.Request;
            request.InputStream.Position = 0;
            using (var reader = new StreamReader(request.InputStream))
            {
                var jsonString = reader.ReadToEnd();
                System.Diagnostics.Debug.WriteLine("Received JSON: " + jsonString); // Log the received JSON string
                return JsonConvert.DeserializeObject(jsonString, bindingContext.ModelType);
            }
        }
    }
    public class LineInspectionController : BaseController
    {
        // ***************************************************************
        //   Index
        // ***************************************************************
        public ActionResult Index()
        {
            SetViewBag("LineInspectionIndex");
            if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
            {
                return RedirectToAction("Index", "Home");
            }
            LineInspectionIndexViewModel vmIndex = new LineInspectionIndexViewModel();
            vmIndex.GetLineInspectionListForIndex(ViewBag.SerialNumber);
            return View(vmIndex);
        }

        // ***************************************************************
        //   Create
        // ***************************************************************
        public ActionResult Create()
        {
            SetViewBag("LineInspectionCreate");
            LineInspectionCreateViewModel vmCreate = new LineInspectionCreateViewModel();
            vmCreate.Inspector = User.Identity.Name.Trim();

            vmCreate.Populate(System.Web.HttpContext.Current.Session["SerialNumber"].ToString());
            return View(vmCreate);
        }

        

        [HttpPost]

        public ActionResult CreateBatch([ModelBinder(typeof(JsonModelBinder))] List<LineInspectionModel> LineInspectionModelBatch)
        {
            LineInspectionCreateViewModel vmCreate = new LineInspectionCreateViewModel();
            if (ModelState.IsValid)
            {

                if (LineInspectionModelBatch.Count > 0)
                {
                    for (int i = 0; i < LineInspectionModelBatch.Count; i++)
                    {

                        LineInspectionModel item = LineInspectionModelBatch[i];
                        List<ValidationError> ErrorList = null;
                        ErrorList = vmCreate.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name, item);
                        if (ErrorList.Count > 0)
                        {
                            foreach (ValidationError err in ErrorList)
                            {
                                ModelState.AddModelError(err.Key, err.Message);
                            }
                            SetViewBag("LineInspectionCreate");
                            return View(vmCreate);
                        }

                    }
                    return RedirectToAction("Index", "LineInspection");
                }
            }
            SetViewBag("LineInspectionCreate");
            return View(vmCreate);
        }

        public class LineInspectionPassViewModel
        {
            public System.DateTime InspectionDate { get; set; }
            public string InspectionLocation { get; set; }
            public string Inspector { get; set; }
            public string InspectionType { get; set; }
            public string PassFail { get; set; }
            public List<LineInspectionModel> LineInspectionList { get; set; }
        }
        [HttpPost]
        public ActionResult LineInspectionPass(LineInspectionPassViewModel _items)
        {
            LineInspectionCreateViewModel vmCreate = new LineInspectionCreateViewModel();
            LineInspectionModel _data = new LineInspectionModel();
            _data.InspectionDate = _items.InspectionDate;
            _data.InspectionLocation = _items.InspectionLocation;
            _data.Inspector = _items.Inspector;
            _data.InspectionType = _items.InspectionType;
            _data.PassFail = _items.PassFail;


            // Logic to handle "Pass"
            if (ModelState.IsValid)
            {
                if (_items.LineInspectionList != null && _items.LineInspectionList.Count > 0)
                {
                    List<LineInspectionModel> batch = _items.LineInspectionList;
                    for (int i = 0; i < batch.Count; i++)
                    {

                        LineInspectionModel item = batch[i];
                        item.PassFail = "PASS";
                        List<ValidationError> ErrorList = null;

                        ErrorList = vmCreate.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name, item);


                        if (ErrorList.Count > 0)
                        {
                            foreach (ValidationError err in ErrorList)
                            {
                                ModelState.AddModelError(err.Key, err.Message);
                            }
                            SetViewBag("LineInspectionCreate");
                            return View(vmCreate);
                        }

                    }
                    return Json(new { success = true, redirectUrl = Url.Action("Index", "LineInspection") });
                } else
                {
                    List<ValidationError> ErrorList = null;
                    ErrorList = vmCreate.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name, _data);
                    if (ErrorList.Count > 0)
                    {
                        foreach (ValidationError err in ErrorList)
                        {
                            ModelState.AddModelError(err.Key, err.Message);
                        }
                        return Json(new { success = false, message = "Validation failed." });
                    }
                    return Json(new { success = true, redirectUrl = Url.Action("Index", "LineInspection") });
                }
            }
            SetViewBag("LineInspectionCreate");
            return View(vmCreate);
        }

        [HttpPost]
        public ActionResult LineInepectionFail([ModelBinder(typeof(JsonModelBinder))] List<LineInspectionModel> LineInspectionModelBatch)
        {
            LineInspectionCreateViewModel vmCreate = new LineInspectionCreateViewModel();
            if (ModelState.IsValid)
            {

                if (LineInspectionModelBatch.Count > 0)
                {
                    for (int i = 0; i < LineInspectionModelBatch.Count; i++)
                    {

                        LineInspectionModel item = LineInspectionModelBatch[i];
                        item.PassFail = "FAIL";
                        List<ValidationError> ErrorList = null;

                        ErrorList = vmCreate.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name, item);
                        

                        if (ErrorList.Count > 0)
                        {
                            foreach (ValidationError err in ErrorList)
                            {
                                ModelState.AddModelError(err.Key, err.Message);
                            }
                            SetViewBag("LineInspectionCreate");
                            return View(vmCreate);
                        }

                    }
                    return RedirectToAction("Index", "LineInspection");
                }
            }
            SetViewBag("LineInspectionCreate");
            return View(vmCreate);
        }

        // ***************************************************************
        //   CreateTorque
        // ***************************************************************
        public ActionResult CreateTorque()
        {
            SetViewBag("TorqueCreate");
            TorqueCreateViewModel vmCreate = new TorqueCreateViewModel();
            vmCreate.Populate(System.Web.HttpContext.Current.Session["SerialNumber"].ToString());
            vmCreate.Inspector = User.Identity.Name.Trim();
            return View(vmCreate);
        }

        [HttpPost]
        public ActionResult CreateTorque(TorqueCreateViewModel vmCreate)
        {
            if (ModelState.IsValid)
            {
                // if data is valid, save to database
                List<ValidationError> ErrorList = null;
                ErrorList = vmCreate.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
                if (ErrorList.Count > 0)
                {
                    foreach (ValidationError err in ErrorList)
                    {
                        ModelState.AddModelError(err.Key, err.Message);
                    }
                    SetViewBag("TorqueCreate");
                    return View(vmCreate);
                }

                // return to grid
                return RedirectToAction("Index", "LineInspection");
            }
            else
            {
                SetViewBag("TorqueCreate");
                return View(vmCreate);
            }
        }


        // ***************************************************************
        //   Edit
        // ***************************************************************
        public ActionResult Edit()
        {
            SetViewBag("LineInspectionEdit");
            string SerialNumber = Request.QueryString["serial"].ToString();
            string CreateDate = Request.QueryString["cdate"].ToString();
            string CreateTime = Request.QueryString["ctime"].ToString();
            string DefectArea = Request.QueryString["darea"].ToString();
            string DefectType = Request.QueryString["dtype"].ToString();
            string DefectCondition = Request.QueryString["dcondition"].ToString();
            string DefectItem = Request.QueryString["ditem"].ToString();

            LineInspectionEditViewModel vmEdit = new LineInspectionEditViewModel();
            vmEdit.Populate(SerialNumber, CreateDate, CreateTime, DefectArea, DefectType, DefectCondition, DefectItem);
            return View(vmEdit);
        }

        [HttpPost]
        public ActionResult Edit(LineInspectionEditViewModel vmEdit)
        {
            if (ModelState.IsValid)
            {
                List<ValidationError> ErrorList = null;
                ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
                if (ErrorList.Count > 0)
                {
                    foreach (ValidationError err in ErrorList)
                    {
                        ModelState.AddModelError(err.Key, err.Message);
                    }
                    SetViewBag("LineInspectionEdit");
                    return View(vmEdit);
                }

                // return to grid
                return RedirectToAction("Index", "LineInspection");
            }
            else
            {
                SetViewBag("LineInspectionEdit");
                return View(vmEdit);
            }
        }

        // ***************************************************************
        //   Edit Torque
        // ***************************************************************
        public ActionResult EditTorque()
        {
            SetViewBag("TorqueEdit");
            string SerialNumber = Request.QueryString["serial"].ToString();
            string CreateDate = Request.QueryString["cdate"].ToString();
            string CreateTime = Request.QueryString["ctime"].ToString();

            TorqueEditViewModel vmEdit = new TorqueEditViewModel();
            vmEdit.Populate(SerialNumber, CreateDate, CreateTime);
            return View(vmEdit);
        }

        [HttpPost]
        public ActionResult EditTorque(TorqueEditViewModel vmEdit)
        {
            if (ModelState.IsValid)
            {
                List<ValidationError> ErrorList = null;
                ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
                if (ErrorList.Count > 0)
                {
                    foreach (ValidationError err in ErrorList)
                    {
                        ModelState.AddModelError(err.Key, err.Message);
                    }
                    SetViewBag("TorqueEdit");
                    return View(vmEdit);
                }

                // return to grid
                return RedirectToAction("Index", "LineInspection");
            }
            else
            {
                SetViewBag("TorqueEdit");
                return View(vmEdit);
            }
        }

        // ***************************************************************
        //   Delete
        // ***************************************************************
        public ActionResult Delete()
        {
            SetViewBag("LineInspectionDelete");
            string SerialNumber = Request.QueryString["serial"].ToString();
            string CreateDate = Request.QueryString["cdate"].ToString();
            string CreateTime = Request.QueryString["ctime"].ToString();
            string DefectArea = Request.QueryString["darea"].ToString();
            string DefectType = Request.QueryString["dtype"].ToString();
            string DefectCondition = Request.QueryString["dcondition"].ToString();
            string DefectItem = Request.QueryString["ditem"].ToString();

            LineInspectionDeleteViewModel vmDelete = new LineInspectionDeleteViewModel();
            vmDelete.Populate(SerialNumber, CreateDate, CreateTime, DefectArea, DefectType, DefectCondition, DefectItem);
            return View(vmDelete);
        }

        [HttpPost]
        public ActionResult Delete(LineInspectionDeleteViewModel vmDelete)
        {
            if (ModelState.IsValid)
            {
                List<ValidationError> ErrorList = null;
                ErrorList = vmDelete.Delete(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name );
                if (ErrorList.Count > 0)
                {
                    foreach (ValidationError err in ErrorList)
                    {
                        ModelState.AddModelError(err.Key, err.Message);
                    }
                    SetViewBag("LineInspectionDelete");
                    return View(vmDelete);
                }
                return RedirectToAction("Index", "LineInspection");
            }
            else
            {
                SetViewBag("LineInspectionDelete");
                return View(vmDelete);
            }
        }

        // ***************************************************************
        //   Delete Torque
        // ***************************************************************
        public ActionResult DeleteTorque()
        {
            SetViewBag("TorqueDelete");
            string SerialNumber = Request.QueryString["serial"].ToString();
            string CreateDate = Request.QueryString["cdate"].ToString();
            string CreateTime = Request.QueryString["ctime"].ToString();

            TorqueDeleteViewModel vmDelete = new TorqueDeleteViewModel();
            vmDelete.Populate(SerialNumber, CreateDate, CreateTime);
            return View(vmDelete);
        }

        [HttpPost]
        public ActionResult DeleteTorque(TorqueDeleteViewModel vmDelete)
        {
            if (ModelState.IsValid)
            {
                List<ValidationError> ErrorList = null;
                ErrorList = vmDelete.Delete(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
                if (ErrorList.Count > 0)
                {
                    foreach (ValidationError err in ErrorList)
                    {
                        ModelState.AddModelError(err.Key, err.Message);
                    }
                    SetViewBag("TorqueDelete");
                    return View(vmDelete);
                }
                return RedirectToAction("Index", "LineInspection");
            }
            else
            {
                SetViewBag("TorqueDelete");
                return View(vmDelete);
            }
        }

        public JsonResult GetDefectType(string defectAreaCode)
        {
            var a = defectAreaCode;
            var db = new DefectTypeServices();
            var defectType = db.LineInspectionTypeList.Select(c => new
            {
                Value = c.Code,
                Text = c.Code.Trim() + " - " + c.Description.Trim(),
                Selected = false
            }).ToList();

            return Json(defectType, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetDefectCondition(string defectTypeCode)
        {
            var db = new DefectConditionServices();
            var defectCondition = db.LineInspectionConditionList.Where(c => c.DCTID == defectTypeCode).Select(c => new
            {
                Value = c.Code,
                Text = c.Code.Trim() + " - " + c.Description.Trim(),
                Selected = false
            }).ToList();

            return Json(defectCondition, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetDefectItem(string defectConditionCode)
        {
            var db = new DefectItemServices();
            var defectItem = db.LineInspectionItemList.Where(c => c.DICID == defectConditionCode).Select(c => new
            {
                Value = c.Code,
                Text = c.Code.Trim() + " - " + c.Description.Trim(),
                Selected = false
            }).ToList();

            return Json(defectItem, JsonRequestBehavior.AllowGet);
        }
    }
}
