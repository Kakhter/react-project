﻿using QualityDatabase.Common;
using QualityDatabase.Services;
using QualityDatabase.ViewModels;
using System.Collections.Generic;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class HoldIssuesController : BaseController
  {
    // ***************************************************************
    //   Index
    // ***************************************************************
    public ActionResult Index()
    {
      SetViewBag("HoldIssuesIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      HoldIssuesIndexViewModel vmIndex = new HoldIssuesIndexViewModel();
      vmIndex.GetHoldListForIndex(ViewBag.SerialNumber);
      ViewBag.Authorization = AuthorizationLevel.GetLevel("HoldIssuesIndex", System.Web.HttpContext.Current.Session["UserAuthorization"].ToString());
      return View(vmIndex);
    }

    // ***************************************************************
    //   Create
    // ***************************************************************
    public ActionResult Create()
    {
      SetViewBag("HoldIssuesCreate");
      HoldIssuesCreateViewModel vmCreate = new HoldIssuesCreateViewModel();
      return View(vmCreate);
    }
    [HttpPost]
    public ActionResult Create(HoldIssuesCreateViewModel vmCreate)
    {
      if (ModelState.IsValid)
      {
        // if data is valid, save to database
        List<ValidationError> ErrorList = null;
        ErrorList = vmCreate.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("HoldIssuesCreate");
          return View(vmCreate);
        }

        HoldsResolvedServices hrDB = new HoldsResolvedServices();
        if (hrDB.AreAllHoldsResolved(System.Web.HttpContext.Current.Session["SerialNumber"].ToString()) == true)
          System.Web.HttpContext.Current.Session["OnHold"] = "";
        else
          System.Web.HttpContext.Current.Session["OnHold"] = "On Hold";

        // return to grid
        return RedirectToAction("Index", "HoldIssues");
      }
      else
      {
        SetViewBag("HoldIssuesCreate");
        return View(vmCreate);
      }
    }


    // ***************************************************************
    //   Edit
    // ***************************************************************
    public ActionResult Edit()
    {
      SetViewBag("HoldIssuesEdit");
      string SerialNumber = Request.QueryString["serial"].ToString();
      string CreateDate = Request.QueryString["cdate"].ToString();
      string CreateTime = Request.QueryString["ctime"].ToString();

      HoldIssuesEditViewModel vmEdit = new HoldIssuesEditViewModel();
      vmEdit.Populate(SerialNumber, CreateDate, CreateTime);
      return View(vmEdit);
    }

    [HttpPost]
    public ActionResult Edit(HoldIssuesEditViewModel vmEdit)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("HoldIssuesEdit");
          return View(vmEdit);
        }

        HoldsResolvedServices hrDB = new HoldsResolvedServices();
        if (hrDB.AreAllHoldsResolved(System.Web.HttpContext.Current.Session["SerialNumber"].ToString()) == true)
          System.Web.HttpContext.Current.Session["OnHold"] = "";
        else
          System.Web.HttpContext.Current.Session["OnHold"] = "On Hold";

        // return to grid
        return RedirectToAction("Index", "HoldIssues");
      }
      else
      {
        SetViewBag("HoldIssuesEdit");
        return View(vmEdit);
      }
    }

    // ***************************************************************
    //   Delete
    // ***************************************************************
    public ActionResult Delete()
    {
      SetViewBag("HoldIssuesDelete");
      string SerialNumber = Request.QueryString["serial"].ToString();
      string CreateDate = Request.QueryString["cdate"].ToString();
      string CreateTime = Request.QueryString["ctime"].ToString();

      HoldIssuesDeleteViewModel vmDelete = new HoldIssuesDeleteViewModel();
      vmDelete.Populate(SerialNumber, CreateDate, CreateTime);
      return View(vmDelete);
    }

    [HttpPost]
    public ActionResult Delete(HoldIssuesDeleteViewModel vmDelete)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmDelete.Delete(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("HoldIssuesDelete");
          return View(vmDelete);
        }

        HoldsResolvedServices hrDB = new HoldsResolvedServices();
        if (hrDB.AreAllHoldsResolved(System.Web.HttpContext.Current.Session["SerialNumber"].ToString()) == true)
          System.Web.HttpContext.Current.Session["OnHold"] = "";
        else
          System.Web.HttpContext.Current.Session["OnHold"] = "On Hold";


        return RedirectToAction("Index", "HoldIssues");
      }
      else
      {
        SetViewBag("HoldIssuesDelete");
        return View(vmDelete);
      }
    }

  }
}
