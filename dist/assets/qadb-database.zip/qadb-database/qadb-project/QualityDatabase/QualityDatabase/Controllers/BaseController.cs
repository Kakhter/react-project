﻿using QualityDatabase.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class BaseController : Controller
  {
    public void SetViewBag(string _source)
    {
      if (User.Identity.IsAuthenticated == true)
        ViewBag.LoggedInUser = User.Identity.Name;
      else 
        ViewBag.LoggedInUser = "Not Logged In";
      
      ViewBag.SerialNumber = System.Web.HttpContext.Current.Session["SerialNumber"];
      ViewBag.Model = System.Web.HttpContext.Current.Session["Model"];
      ViewBag.OrderNumber = System.Web.HttpContext.Current.Session["OrderNumber"];
      ViewBag.CustomerName = System.Web.HttpContext.Current.Session["CustomerName"];
      ViewBag.Warehouse = System.Web.HttpContext.Current.Session["Warehouse"];
      ViewBag.Line = System.Web.HttpContext.Current.Session["Line"];
      ViewBag.Date200 = System.Web.HttpContext.Current.Session["Date200"];
      ViewBag.Date900 = System.Web.HttpContext.Current.Session["Date900"];
      ViewBag.OnHold = System.Web.HttpContext.Current.Session["OnHold"];
      ViewBag.UserAuthorization = System.Web.HttpContext.Current.Session["UserAuthorization"];
      ViewBag.Authorization = AuthorizationLevel.GetLevel(_source, ViewBag.UserAuthorization);

      if (ViewBag.OnHold == null)
        ViewBag.OnHold = "";
    }

    public void ClearSessionVariables()
    {
      System.Web.HttpContext.Current.Session["SerialNumber"] = "";
      System.Web.HttpContext.Current.Session["Model"] = "";
      System.Web.HttpContext.Current.Session["OrderNumber"] = "";
      System.Web.HttpContext.Current.Session["CustomerName"] = "";
      System.Web.HttpContext.Current.Session["Warehouse"] = "";
      System.Web.HttpContext.Current.Session["Line"] = "";
      System.Web.HttpContext.Current.Session["Date200"] = "";
      System.Web.HttpContext.Current.Session["Date900"] = "";
      System.Web.HttpContext.Current.Session["OnHold"] = "";
      //System.Web.HttpContext.Current.Session["UserAuthorization"] = "";
    }

    protected override void OnException(ExceptionContext filterContext)
    {
      //ErrorLogger.Log("Unhandled Exception", "", filterContext.Controller.ToString(), filterContext.Exception);

      //if (filterContext.ExceptionHandled)
      //  return;

      //filterContext.ExceptionHandled = true;
      //filterContext.HttpContext.Response.Clear();

      ////filterContext.Result = new ViewResult
      ////{
      ////  ViewName = "~/Views/Shared/Error.aspx"
      ////};

      //filterContext.Controller.TempData["Exception"] = filterContext.Exception;
      //filterContext.Controller.TempData["FromModule"] = filterContext.Controller.ToString();

      //filterContext.Result = new RedirectToRouteResult(new System.Web.Routing.RouteValueDictionary(
      //  new { controller = "Error", action = "TestError" }));

      

      

    }
  }
}
