﻿using QualityDatabase.Common;
using QualityDatabase.Services;
using QualityDatabase.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mime;
using System.Text;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class WeightSheetController : BaseController
  {
    //
    // GET: /WeightSheet/

    public ActionResult Index()
    {
      SetViewBag("WeightSheetIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      WeightSheetIndexViewModel vmIndex = new WeightSheetIndexViewModel();
      vmIndex.GetWeightSheetListForIndex(ViewBag.SerialNumber);

      ViewBag.Authorization = AuthorizationLevel.GetLevel("WeightSheetIndex", System.Web.HttpContext.Current.Session["UserAuthorization"].ToString());

      return View(vmIndex);
    }

    public ActionResult ViewPDF()
    {
      SetViewBag("WeightSheetViewPDF");
      return View();
    }

    public ActionResult GetFile()
    {
      string BodyNumber = System.Web.HttpContext.Current.Session["SerialNumber"].ToString();

      PDFUtils pdfUtil = new PDFUtils();

      if (pdfUtil.DoesPDFExist(BodyNumber) == true)
      {
        MemoryStream m = new MemoryStream();
        m = pdfUtil.GetExistingPDF(BodyNumber);
        return File(m.ToArray(), MediaTypeNames.Application.Pdf);
      }
      else
      {
        ErrorLogger.Log("WeightSheetController", "", "Error in GetFile, Weight Sheet file for " + BodyNumber.Trim() + " cannot be found.");
        TempData["ErrorDescription"] = "Weight Sheet file for " + BodyNumber.Trim() + " cannot be found.";
        TempData["ErrorStack"] = "";
        TempData["FromModule"] = "Weight Sheet Controller - GetFile";
        return RedirectToAction("HandleError", "Error");
      }
    }




    public ActionResult Create()
    {
      string Division = "";
      SetViewBag("WeightSheetCreate");
      WeightSheetServices db = new WeightSheetServices();
      Division = db.GetDivision(System.Web.HttpContext.Current.Session["SerialNumber"].ToString());

      // for testing
      //Division = "41";

      if (Division.Trim() == "41")
        return RedirectToAction("CreateCalifornia", "WeightSheet");
      else
        return RedirectToAction("CreateUniversal", "WeightSheet");
    }

    public ActionResult CreateUniversal()
    {
      SetViewBag("WeightSheetUniversalCreate");
      WeightSheetUniversalViewModel vm = new WeightSheetUniversalViewModel();
      vm.Populate(System.Web.HttpContext.Current.Session["SerialNumber"].ToString());
      return View(vm);
    }

    [HttpPost]
    public ActionResult CreateUniversal(WeightSheetUniversalViewModel _vm)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = new List<ValidationError>();
        ErrorList = _vm.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString());
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("WeightSheetUniversalCreate");
          return View(_vm);
        }

        System.Web.HttpContext.Current.Session["PDFVehicleType"] = _vm.VehicleType;
        System.Web.HttpContext.Current.Session["PDFWeightFrontAxle"] = _vm.WeightFrontAxle;
        System.Web.HttpContext.Current.Session["PDFTotalVehicleWeight"] = _vm.TotalVehicleWeight;
        System.Web.HttpContext.Current.Session["PDFWeightRearAxle"] = _vm.WeightRearAxle;
        System.Web.HttpContext.Current.Session["PDFRemarks"] = _vm.Remarks;
        return RedirectToAction("ViewUniversalPDF", "WeightSheet");
      }
      else
      {
        SetViewBag("WeightSheetUniversalCreate");
        return View(_vm);
      }
    }

    public ActionResult ViewUniversalPDF()
    {
      SetViewBag("WeightSheetViewPDF");
      return View();
    }

    public ActionResult GetUniversalPDF()
    {
      try
      {
        PDFUtils util = new PDFUtils();

        System.IO.MemoryStream m = new MemoryStream();
        System.IO.MemoryStream mOld = new MemoryStream();
        System.IO.MemoryStream mFull = new MemoryStream();

        WeightSheetUniversalPDF pdf = new WeightSheetUniversalPDF();
        pdf.imagePath = Server.MapPath(@"~/Images/wabash-_primary_blue_rgb-1.png");
        pdf.SerialNumber = System.Web.HttpContext.Current.Session["SerialNumber"];
        pdf.PDFVehicleType = System.Web.HttpContext.Current.Session["PDFVehicleType"];
        pdf.PDFWeightFrontAxle = System.Web.HttpContext.Current.Session["PDFWeightFrontAxle"];
        pdf.PDFTotalVehicleWeight = System.Web.HttpContext.Current.Session["PDFTotalVehicleWeight"];
        pdf.PDFWeightRearAxle = System.Web.HttpContext.Current.Session["PDFWeightRearAxle"];
        pdf.PDFRemark = System.Web.HttpContext.Current.Session["PDFRemarks"];
        pdf.UserName = User.Identity.Name;
        m = pdf.CreateUniversalPDF();

        /*using (FileStream file = new FileStream("c:\\Users\\ming.gong\\source\\output.pdf", FileMode.Create, FileAccess.Write))
        {
            m.WriteTo(file);
        }*/


        if (util.DoesPDFExist(pdf.SerialNumber.ToString()) == true)
        {
          mOld = util.GetExistingPDF(pdf.SerialNumber.ToString());
          List<byte[]> list = new List<byte[]>();
          list.Add(mOld.ToArray());
          list.Add(m.ToArray());
          mOld = util.Merge(list);
          mFull = new MemoryStream(mOld.ToArray());
        }

        if (mFull.Capacity == 0)
        {
          Console.WriteLine(@"m len ${}");
          util.Upload(m, pdf.SerialNumber.ToString());
          //m.Close();
        }
        else
        {
          util.Delete(pdf.SerialNumber.ToString());
          util.Upload(mFull, pdf.SerialNumber.ToString());
        }
        return File(m.ToArray(), MediaTypeNames.Application.Pdf);
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WeightSheetServices", "", "Error in GetUniversalPDF", ex);
        TempData["ErrorDescription"] = ex.Message;
        TempData["ErrorStack"] = ex.StackTrace;
        TempData["FromModule"] = "Weight Sheet Controller - GetUniversalPDF";
        return RedirectToAction("HandleError", "Error");
      }
    }



    public ActionResult CreateCalifornia()
    {
      SetViewBag("WeightSheetCaliforniaCreate");
     
      WeightSheetCaliforniaViewModel vm = new WeightSheetCaliforniaViewModel();
      vm.Populate(System.Web.HttpContext.Current.Session["SerialNumber"].ToString());
     
      return View(vm);
    }

    [HttpPost]
    public ActionResult CreateCalifornia(WeightSheetCaliforniaViewModel _vm)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = new List<ValidationError>();
        ErrorList = _vm.Validate();
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("WeightSheetCaliforniaCreate");
          return View(_vm);
        }
        System.Web.HttpContext.Current.Session["PDFVehicleType"] = _vm.VehicleType;
        System.Web.HttpContext.Current.Session["PDFGross"] = _vm.Gross;
        System.Web.HttpContext.Current.Session["PDFTare"] = _vm.Tare;
        System.Web.HttpContext.Current.Session["PDFRemarks"] = _vm.Remarks;
        return RedirectToAction("ViewCaliforniaPDF", "WeightSheet");
      }
      else
      {
        SetViewBag("WeightSheetCaliforniaCreate");
        return View(_vm);
      }
    }

    public ActionResult ViewCaliforniaPDF()
    {
      SetViewBag("WeightSheetViewPDF");
      return View();
    }

    public ActionResult GetCaliforniaPDF()
    {
      try
      {
        PDFUtils util = new PDFUtils();
        System.IO.MemoryStream m = new MemoryStream();
        System.IO.MemoryStream mOld = new MemoryStream();
        System.IO.MemoryStream mFull = new MemoryStream();

        WeightSheetCaliforniaPDF pdf = new WeightSheetCaliforniaPDF();
        pdf.imagePath = Server.MapPath(@"~/Images/wabash-_primary_blue_rgb-1.png");
        pdf.SerialNumber = System.Web.HttpContext.Current.Session["SerialNumber"];
        pdf.PDFVehicleType = System.Web.HttpContext.Current.Session["PDFVehicleType"];
        pdf.PDFGross = System.Web.HttpContext.Current.Session["PDFGross"];
        pdf.PDFTare = System.Web.HttpContext.Current.Session["PDFTare"];
        pdf.PDFRemark = System.Web.HttpContext.Current.Session["PDFRemarks"];
        pdf.UserName = User.Identity.Name;
        m.Position = 0;
        m = pdf.CreateCaliforniaPDF();
        if (util.DoesPDFExist(pdf.SerialNumber.ToString()) == true)
        {
          mOld = util.GetExistingPDF(pdf.SerialNumber.ToString());
          List<byte[]> list = new List<byte[]>();
          list.Add(mOld.ToArray());
          list.Add(m.ToArray());
          mOld = util.Merge(list);
          mFull = new MemoryStream(mOld.ToArray());
        }

        if (mFull.Capacity == 0)
        {
          util.Upload(m, pdf.SerialNumber.ToString());
        }
        else
        {
          util.Delete(pdf.SerialNumber.ToString());
          util.Upload(mFull, pdf.SerialNumber.ToString());
        }
        return File(m.ToArray(), MediaTypeNames.Application.Pdf);
      }
      catch (Exception ex)
      {
        ErrorLogger.Log("WeightSheetServices", "", "Error in GetCaliforniaPDF", ex);
        TempData["ErrorDescription"] = ex.Message;
        TempData["ErrorStack"] = ex.StackTrace;
        TempData["FromModule"] = "Weight Sheet Controller - GetCaliforniaPDF";
        return RedirectToAction("HandleError", "Error");

      }
    }


  }
}
