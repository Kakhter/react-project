﻿using QualityDatabase.Common;
using QualityDatabase.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class ChassisHeightController : BaseController
  {
    // Chassis Height works differently than other pages.
    // authorization on other pages are for the complete page
    // i.e Quality can edit everything or nothing.
    // On this page Quality can process some fields but not all
    // Production can process some fields but not all
    private string GetAuthLevel(string _auth)
    {
      // if authorization is null, set to view only
      if (_auth == null)
        return "V";

      // if authorization is valid option, set to option
      if ((_auth.Trim() == "Q")
        || (_auth.Trim() == "P")
        || (_auth.Trim() == "S")
        || (_auth.Trim() == "V"))
        return _auth.Trim();

      // if it is anything else, set to view only
      return "V";
    }

    // ***************************************************************
    //   Index
    // ***************************************************************    
    public ActionResult Index()
    {
      SetViewBag("ChassisHeightIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      ChassisHeightIndexViewModel vmIndex = new ChassisHeightIndexViewModel();
      vmIndex.GetChassisHeightListForIndex(ViewBag.SerialNumber);

      ViewBag.Authorization = GetAuthLevel(System.Web.HttpContext.Current.Session["UserAuthorization"].ToString());
      return View(vmIndex);
    }

    // ***************************************************************
    //   Edit
    // ***************************************************************
    public ActionResult Edit()
    {
      SetViewBag("ChassisHeightEdit");
      string SerialNumber = Request.QueryString["serial"].ToString();

      ChassisHeightEditViewModel vmEdit = new ChassisHeightEditViewModel();
      vmEdit.Populate(SerialNumber);

      ViewBag.Authorization = GetAuthLevel(System.Web.HttpContext.Current.Session["UserAuthorization"].ToString());
      return View(vmEdit);
    }

    [HttpPost]
    public ActionResult Edit(ChassisHeightEditViewModel vmEdit)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("ChassisHeightEdit");
          return View(vmEdit);
        }

        return RedirectToAction("Index", "ChassisHeight");
      }
      else
      {
        SetViewBag("ChassisHeightEdit");
        return View(vmEdit);
      }
    }
  }
}
