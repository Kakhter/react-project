﻿using QualityDatabase.Common;
using QualityDatabase.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class FuelController : BaseController
  {
    // ***************************************************************
    //   Index
    // *************************************************************** 
    public ActionResult Index()
    {
      SetViewBag("FuelIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      FuelViewModel vmIndex = new FuelViewModel();
      vmIndex.GetFuelListForIndex(ViewBag.SerialNumber);
      return View(vmIndex);
    }

    // ***************************************************************
    //   Edit
    // ***************************************************************
    public ActionResult Edit()
    {
      SetViewBag("FuelEdit");
      string SerialNumber = Request.QueryString["serial"].ToString();

      FuelEditViewModel vmEdit = new FuelEditViewModel();
      vmEdit.Populate(SerialNumber);
      return View(vmEdit);
    }

    [HttpPost]
    public ActionResult Edit(FuelEditViewModel vmEdit)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("FuelEdit");
          return View(vmEdit);
        }
        return RedirectToAction("Index", "Fuel");
      }
      else
      {
        SetViewBag("FuelEdit");
        return View(vmEdit);
      }
    }
  }
}
