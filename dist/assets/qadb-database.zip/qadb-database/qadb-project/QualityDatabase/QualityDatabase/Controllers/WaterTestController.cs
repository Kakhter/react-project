﻿using QualityDatabase.Common;
using QualityDatabase.ViewModels;
using System.Collections.Generic;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class WaterTestController : BaseController
  {

    public WaterTestController()
    {
    }

    // ***************************************************************
    //   Index
    // ***************************************************************
    public ActionResult Index()
    {
      SetViewBag("WaterTestIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      WaterTestIndexViewModel vmIndex = new WaterTestIndexViewModel();
      vmIndex.GetWaterTestListForIndex(ViewBag.SerialNumber);
      
      ViewBag.Authorization = AuthorizationLevel.GetLevel("WaterTestIndex", System.Web.HttpContext.Current.Session["UserAuthorization"].ToString());
      
      return View(vmIndex);
    }

    // ***************************************************************
    //   Create
    // ***************************************************************
    public ActionResult Create()
    {
      SetViewBag("WaterTestCreate");
      WaterTestCreateViewModel vmCreate = new WaterTestCreateViewModel();
      return View(vmCreate);
    }

    [HttpPost]
    public ActionResult Create(WaterTestCreateViewModel vmCreate)
    {
      if (ModelState.IsValid)
      {
        // if data is valid, save to database
        List<ValidationError> ErrorList = null;
        ErrorList = vmCreate.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("WaterTestCreate");
          return View(vmCreate);
        }

        // return to grid
        return RedirectToAction("Index", "WaterTest");
      }
      else
      {
        SetViewBag("WaterTestCreate");
        return View(vmCreate);
      }
    }

    // ***************************************************************
    //   Edit
    // ***************************************************************
    public ActionResult Edit()
    {
      SetViewBag("WaterTestEdit");
      string SerialNumber = Request.QueryString["serial"].ToString();
      string CreateDate = Request.QueryString["cdate"].ToString();
      string CreateTime = Request.QueryString["ctime"].ToString();

      WaterTestEditViewModel vmEdit = new WaterTestEditViewModel();
      vmEdit.Populate(SerialNumber, CreateDate, CreateTime);
      return View(vmEdit);
    }

    [HttpPost]
    public ActionResult Edit(WaterTestEditViewModel vmEdit)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("WaterTestEdit");
          return View(vmEdit);
        }

        // return to grid
        return RedirectToAction("Index", "WaterTest");
      }
      else
      {
        SetViewBag("WaterTestEdit");
        return View(vmEdit);
      }
    }

    // ***************************************************************
    //   Delete
    // ***************************************************************
    public ActionResult Delete()
    {
      SetViewBag("WaterTestDelete");
      string SerialNumber = Request.QueryString["serial"].ToString();
      string CreateDate = Request.QueryString["cdate"].ToString();
      string CreateTime = Request.QueryString["ctime"].ToString();

      WaterTestDeleteViewModel vmDelete = new WaterTestDeleteViewModel();
      vmDelete.Populate(SerialNumber, CreateDate, CreateTime);
      return View(vmDelete);
    }


    [HttpPost]
    public ActionResult Delete(WaterTestDeleteViewModel vmDelete)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmDelete.Delete(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("WaterTestDelete");
          return View(vmDelete);
        }
        // return to grid
        return RedirectToAction("Index", "WaterTest");
      }
      else
      {
        SetViewBag("WaterTestDelete");
        return View(vmDelete);
      }
    }
  }
}
