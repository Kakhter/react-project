﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace QualityDatabase.Controllers
{
  public class LoginController : BaseController
  {

    // GET: /Login/
    public ActionResult Index()
    {
      LoginUserModel user = new LoginUserModel();
      return View(user);
    }

    // POST: /Login/
    [HttpPost]
    public ActionResult Index(LoginUserModel _user, string returnUrl)
    {
      if (ModelState.IsValid)
      {
        ValidateLogin vl = new ValidateLogin();
        // If the username/password are valid with the AS400
        if (vl.IsUserValid(_user.Username, _user.Password) == true)
        {
          _user.Username = _user.Username.ToUpper();
          _user.Password = _user.Password.ToUpper();

          // set the forms authentication cookie and
          // then go to the redirect
          FormsAuthentication.SetAuthCookie(_user.Username, false);
          System.Web.HttpContext.Current.Session["LoggedInUser"] = _user.Username;

          UserAuthorizationService auth = new UserAuthorizationService();
          System.Web.HttpContext.Current.Session["UserAuthorization"] = auth.GetAuthorizationLevel(_user.Username.Trim());

          return RedirectToAction("Index", "Home");

          //if (Url.IsLocalUrl(returnUrl)
          //  && returnUrl.Length > 1
          //  && returnUrl.StartsWith("/")
          //  && !returnUrl.StartsWith("//")
          //  && !returnUrl.StartsWith("/\\"))
          //{
          //  return Redirect(returnUrl);
          //}
          //else
          //{
          //  return RedirectToAction("Index", "Home");
          //}
        }
        else
        {
          if (vl.Expired == true)
          {
            ModelState.AddModelError("", @"Password has expired. Please sign in to the AS/400 to change your password.");
          }
          else
          {
            ModelState.AddModelError("Username", "Invalid Username/Password");
          }
          
          return View(_user);
        }
      }
      ModelState.AddModelError("Username", "Invalid Username/Password");
      return View(_user);
    }

    public ActionResult Logout()
    {
      FormsAuthentication.SignOut();
      Session.Abandon();

      // clear authentication cookie
      HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "");
      cookie1.Expires = DateTime.Now.AddYears(-1);
      Response.Cookies.Add(cookie1);

      // clear session cookie (not necessary for your current problem but i would recommend you do it anyway)
      HttpCookie cookie2 = new HttpCookie("ASP.NET_SessionId", "");
      cookie2.Expires = DateTime.Now.AddYears(-1);
      Response.Cookies.Add(cookie2);

      // Invalidate the Cache on the Client Side
      Response.Cache.SetCacheability(HttpCacheability.NoCache);
      Response.Cache.SetNoStore();

      FormsAuthentication.RedirectToLoginPage();

      return RedirectToAction("Index", "Home");
    }
  }
}
