﻿using QualityDatabase.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class InfoController : BaseController
  {
    //
    // GET: /Info/

    public ActionResult Index()
    {
      SetViewBag("InfoIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      InfoIndexViewModel vmIndex = new InfoIndexViewModel();
      vmIndex.GetLists(ViewBag.SerialNumber, ViewBag.OrderNumber);
      return View(vmIndex);
    }

  }
}
