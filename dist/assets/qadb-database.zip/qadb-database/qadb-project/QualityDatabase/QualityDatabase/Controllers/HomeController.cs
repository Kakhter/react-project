﻿using QualityDatabase.Common;
using QualityDatabase.Models;
using QualityDatabase.Services;
using QualityDatabase.ViewModels;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class HomeController : BaseController
  {
    //
    // GET: /Home/

    public ActionResult Index()
    {
      SetViewBag("HomeIndex");
      //FindSerialNumberModel fsn = new FindSerialNumberModel();
      HomeViewModel vmIndex = new HomeViewModel();


      ViewBag.Authorization = AuthorizationLevel.GetLevel("HomeIndex", System.Web.HttpContext.Current.Session["UserAuthorization"].ToString());
      return View(vmIndex);
    }

    [HttpPost]
    public ActionResult Index(HomeViewModel _vm)
    {

      if (ModelState.IsValid)
      {
        _vm.SerialNumber = _vm.SerialNumber.ToUpper();

        HeaderData hd = new HeaderData();
        HeaderDataServices hds = new HeaderDataServices();
        hd = hds.GetHeaderData(_vm.SerialNumber);
        if (hd.SerialNumber.Trim() == _vm.SerialNumber.Trim())
        {
          System.Web.HttpContext.Current.Session["SerialNumber"] = hd.SerialNumber.Trim();
          System.Web.HttpContext.Current.Session["Model"] = hd.Model.Trim();
          System.Web.HttpContext.Current.Session["OrderNumber"] = hd.OrderNumber.Trim();
          System.Web.HttpContext.Current.Session["CustomerName"] = hd.CustomerName.Trim();
          System.Web.HttpContext.Current.Session["Warehouse"] = hd.Warehouse.Trim();
          System.Web.HttpContext.Current.Session["Line"] = hd.Line.Trim();
          System.Web.HttpContext.Current.Session["Date200"] = hd.Date200.Trim();
          System.Web.HttpContext.Current.Session["Date900"] = hd.Date900.Trim();
          System.Web.HttpContext.Current.Session["OnHold"] = hd.OnHold.Trim();


          return RedirectToAction("Index", "Info");
        }
        else
        {
          ClearSessionVariables();
          ModelState.AddModelError("SerialNumber", "Invalid Serial Number");
          return View(_vm);
        }
      }
      ClearSessionVariables();
      return View(_vm);
    }

   
  }
}
