﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QualityDatabase.Common;
using QualityDatabase.ViewModels;

namespace QualityDatabase.Controllers
{
  public class LineRepairController : BaseController
  {
    //
    // GET: /LineRepair/

    public ActionResult Index()
    {
      SetViewBag("LineRepairIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      LineRepairIndexViewModel vmIndex = new LineRepairIndexViewModel();
      vmIndex.GetListRepairListForIndex(ViewBag.SerialNumber);
      return View(vmIndex);
    }

    // ***************************************************************
    //   Edit
    // ***************************************************************
    public ActionResult Edit()
    {
      SetViewBag("LineRepairEdit");
      string SerialNumber = Request.QueryString["serial"].ToString();
      string CreateDate = Request.QueryString["cdate"].ToString();
      string CreateTime = Request.QueryString["ctime"].ToString();

      LineRepairEditViewModel vmEdit = new LineRepairEditViewModel();
      vmEdit.Populate(SerialNumber, CreateDate, CreateTime);
      return View(vmEdit);
    }

    [HttpPost]
    public ActionResult Edit(LineRepairEditViewModel vmEdit)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("LineRepairEdit");
          return View(vmEdit);
        }

        // return to grid
        return RedirectToAction("Index", "LineRepair");
      }
      else
      {
        SetViewBag("LineRepairEdit");
        return View(vmEdit);
      }
    }

  }
}
