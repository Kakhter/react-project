﻿using QualityDatabase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
    public class ErrorController : BaseController
    {
        //
        // GET: /Error/

      public ActionResult Index(int statusCode, Exception exception)
      {
        SetViewBag("ErrorControllerIndex");
        ErrorFoundModel model = new ErrorFoundModel();
        model.ErrorDescription = exception.Message;
        model.ErrorStack = exception.StackTrace;
        model.FromModule = exception.TargetSite.Name;

        Response.StatusCode = statusCode;

        return View(model);
      }

      public ActionResult HandleError()
      {
        SetViewBag("ErrorControllerHandleError");
        ErrorFoundModel model = new ErrorFoundModel();

        if (TempData["ErrorDescription"] != null)
        {
          model.ErrorDescription = TempData["ErrorDescription"].ToString();
        }
        
        if (TempData["ErrorStack"] != null)
        {
          model.ErrorStack = TempData["ErrorStack"].ToString();
        }

        if (TempData["FromModule"] != null)
        {
          model.FromModule = TempData["FromModule"].ToString();
        }

        return View(model);
      }

     
    }
}
