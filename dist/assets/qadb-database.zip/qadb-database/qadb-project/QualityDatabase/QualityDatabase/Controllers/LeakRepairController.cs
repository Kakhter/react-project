﻿using QualityDatabase.Common;
using QualityDatabase.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class LeakRepairController : BaseController
  {

    // ***************************************************************
    //   Index
    // ***************************************************************    
    public ActionResult Index()
    {
      SetViewBag("LeakRepairIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      LeakRepairIndexViewModel vmIndex = new LeakRepairIndexViewModel();
      vmIndex.GetLeakRepairListForIndex(ViewBag.SerialNumber);
      return View(vmIndex);
    }

    // ***************************************************************
    //   Edit
    // ***************************************************************
    public ActionResult Edit()
    {
      SetViewBag("LeakRepairEdit");
      string SerialNumber = Request.QueryString["serial"].ToString();
      string CreateDate = Request.QueryString["cdate"].ToString();
      string CreateTime = Request.QueryString["ctime"].ToString();

      LeakRepairEditViewModel vmEdit = new LeakRepairEditViewModel();
      vmEdit.Populate(SerialNumber, CreateDate, CreateTime);
      return View(vmEdit);
    }

    [HttpPost]
    public ActionResult Edit(LeakRepairEditViewModel vmEdit)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("LeakRepairEdit");
          return View(vmEdit);
        }

        // return to grid
        return RedirectToAction("Index", "LeakRepair");
      }
      else
      {
        SetViewBag("LeakRepairEdit");
        return View(vmEdit);
      }
    }

  }
}
