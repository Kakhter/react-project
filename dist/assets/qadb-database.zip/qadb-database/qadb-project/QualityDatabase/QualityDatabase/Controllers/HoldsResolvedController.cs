﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QualityDatabase.ViewModels;
using QualityDatabase.Common;
using QualityDatabase.Services;

namespace QualityDatabase.Controllers
{
  public class HoldsResolvedController : BaseController
  {
    //
    // GET: /HoldResolved/

    public ActionResult Index()
    {
      SetViewBag("HoldsResolvedIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }
      HoldsResolvedIndexViewModel vm = new HoldsResolvedIndexViewModel();
      vm.GetHoldsResolvedList(ViewBag.SerialNumber);
      return View(vm);
    }

    // ***************************************************************
    //   Edit
    // ***************************************************************
    public ActionResult Edit()
    {
      SetViewBag("HoldsResolvedEdit");
      string SerialNumber = Request.QueryString["serial"].ToString();
      string CreateDate = Request.QueryString["cdate"].ToString();
      string CreateTime = Request.QueryString["ctime"].ToString();

      HoldsResolvedEditViewModel vmEdit = new HoldsResolvedEditViewModel();
      vmEdit.Populate(SerialNumber, CreateDate, CreateTime);
      return View(vmEdit);
    }

    [HttpPost]
    public ActionResult Edit(HoldsResolvedEditViewModel vmEdit)
    {

            if (!ModelState.IsValid)
            {
                SetViewBag("HoldsResolvedEdit");
                string CreateDate = Request.QueryString["cdate"].ToString();
                string CreateTime = Request.QueryString["ctime"].ToString();
                vmEdit.Populate(vmEdit.SerialNumber, CreateDate, CreateTime);
                return View(vmEdit);
                // Manually handle invalid input
                //if (ModelState["ReworkHours"]?.Errors.Count > 0)
                //{
                //    ModelState["ReworkHours"].Errors.Clear();
                //    vmEdit.ReworkHours = 0; // Assign default value
                //}
            }


            if (ModelState.IsValid)
      {
        if (vmEdit.ResolvedBy == null)
          vmEdit.ResolvedBy = "";

        List<ValidationError> ErrorList = null;
        ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString());
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("HoldsResolvedEdit");
          return View(vmEdit);
        }

        HoldsResolvedServices hrDB = new HoldsResolvedServices();
        if (hrDB.AreAllHoldsResolved(System.Web.HttpContext.Current.Session["SerialNumber"].ToString()) == true)
          System.Web.HttpContext.Current.Session["OnHold"] = "";
        else
          System.Web.HttpContext.Current.Session["OnHold"] = "On Hold";

        // return to grid
        return RedirectToAction("Index", "HoldsResolved");
      }
      else
      {
        SetViewBag("HoldsResolvedEdit");
        return View(vmEdit);
      }
    }

  }
}
