﻿using QualityDatabase.Common;
using QualityDatabase.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QualityDatabase.Controllers
{
  public class TireTagController : BaseController
  {
    // ***************************************************************
    //   Index
    // *************************************************************** 
    public ActionResult Index()
    {
      SetViewBag("TireTagIndex");
      if (ViewBag.SerialNumber == "" || ViewBag.SerialNumber == null)
      {
        return RedirectToAction("Index", "Home");
      }

      TireTagIndexViewModel vmIndex = new TireTagIndexViewModel();
      vmIndex.GetTireTagListForIndex(ViewBag.SerialNumber);
      return View(vmIndex);
    }

    // ***************************************************************
    //   Edit
    // ***************************************************************
    public ActionResult Edit()
    {
      SetViewBag("TireTagEdit");
      string SerialNumber = Request.QueryString["serial"].ToString();

      TireTagEditViewModel vmEdit = new TireTagEditViewModel();
      vmEdit.Populate(SerialNumber);
      return View(vmEdit);
    }

    [HttpPost]
    public ActionResult Edit(TireTagEditViewModel vmEdit)
    {
      if (ModelState.IsValid)
      {
        List<ValidationError> ErrorList = null;
        ErrorList = vmEdit.Save(System.Web.HttpContext.Current.Session["SerialNumber"].ToString(), User.Identity.Name);
        if (ErrorList.Count > 0)
        {
          foreach (ValidationError err in ErrorList)
          {
            ModelState.AddModelError(err.Key, err.Message);
          }
          SetViewBag("TireTagEdit");
          return View(vmEdit);
        }
        return RedirectToAction("Index", "TireTag");
      }
      else
      {
        SetViewBag("TireTagEdit");
        return View(vmEdit);
      }
    }
  }
}
