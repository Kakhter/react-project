﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using QualityDatabase.Common;
using QualityDatabase.Validation;
using QualityDatabase.Models;
using System;
using System.Collections.Generic;

namespace QualityDatabaseTest.Validation
{
  [TestClass]
  public class ValChassisHeightEditTest
  {
    private static bool IsMessageInErrorList(List<ValidationError> ErrorList, string message)
    {
      bool found = false;
      foreach (ValidationError err in ErrorList)
      {
        if (err.Message == message)
          found = true;
      }
      return found;
    }

    private static bool IsKeyInErrorList(List<ValidationError> ErrorList, string key)
    {
      bool found = false;
      foreach (ValidationError err in ErrorList)
      {
        if (err.Key == key)
          found = true;
      }
      return found;
    }

    private ChassisHeightModel GetDefaultParameter()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param.PriorSS = 0;
      param.PriorCS = 0;
      param.AfterMountSS = 0;
      param.AfterMountCS = 0;
      param.AfterTestSS = 0;
      param.AfterTestCS = 0;
      param.SerialNumber = "12345";
      param.ChassisRailCreateDate = "20130701";
      param.ChassisRailCreateTime = "10000";
      param.ChassisRailCreatedBy = "123456";
      return param;
    }


    [TestMethod]
    public void ValidParameters()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void SerialNumberEmpty()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.SerialNumber = "";

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Serial Number is required.");
      Assert.IsTrue(found == true, "SerialNumber error not found in Error List.");
    }

    [TestMethod]
    public void SerialNumberNull()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.SerialNumber = null;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Serial Number is required.");
      Assert.IsTrue(found == true, "SerialNumber error not found in Error List.");
    }

    [TestMethod]
    public void SerialNumberGreaterThanEight()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.SerialNumber = "123456789";

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Serial Number cannot be greater than 8 characters.");
      Assert.IsTrue(found == true, "SerialNumber error not found in Error List.");
    }


    [TestMethod]
    public void UserEmpty()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.ChassisRailCreatedBy = "";

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Chassis Rail User is required.");
      Assert.IsTrue(found == true, "Chassis Rail User error not found in Error List.");
    }

    [TestMethod]
    public void UserNull()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.ChassisRailCreatedBy = null;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Chassis Rail User is required.");
      Assert.IsTrue(found == true, "Chassis Rail User error not found in Error List.");
    }

    [TestMethod]
    public void UserGreaterThanTen()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.ChassisRailCreatedBy = "12345678901";

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Chassis Rail User cannot be greater than 10 characters.");
      Assert.IsTrue(found == true, "Chassis Rail User cannot be more than 10 characters.");
    }


    [TestMethod]
    public void PriorSSTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 100;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "PriorSS");
      Assert.IsTrue(found == true, "PriorSS error not found in Error List.");
    }

    [TestMethod]
    public void PriorSSDecimalTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 10.0001;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "PriorSS");
      Assert.IsTrue(found == true, "PriorSS error not found in Error List.");
    }

    [TestMethod]
    public void PriorSSDecimal3Digits()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 10.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalOneDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 1.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalOneDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 1.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalOneDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 1.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalTwoDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 11.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalTwoDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 11.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalOneDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalTwoDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 12;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalZeroDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 0.1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalZeroDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = .11;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorSSDecimalZeroDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorSS = 0.111;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }




    [TestMethod]
    public void PriorCSTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 100;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "PriorCS");
      Assert.IsTrue(found == true, "PriorCS error not found in Error List.");
    }

    [TestMethod]
    public void PriorCSDecimalTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 10.0001;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "PriorCS");
      Assert.IsTrue(found == true, "PriorCS error not found in Error List.");
    }

    [TestMethod]
    public void PriorCSDecimal3Digits()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 10.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalOneDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 1.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalOneDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 1.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalOneDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 1.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalTwoDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 11.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalTwoDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 11.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalOneDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalTwoDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 12;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalZeroDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 0.1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalZeroDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 0.11;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void PriorCSDecimalZeroDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.PriorCS = 0.111;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }


    [TestMethod]
    public void AfterMountSSTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 100;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "AfterMountSS");
      Assert.IsTrue(found == true, "AfterMountSS error not found in Error List.");
    }

    [TestMethod]
    public void AfterMountSSDecimalTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param.AfterMountSS = 10.0001;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "AfterMountSS");
      Assert.IsTrue(found == true, "AfterMountSS error not found in Error List.");
    }

    [TestMethod]
    public void AfterMountSSDecimal3Digits()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 10.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalOneDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 1.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalOneDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 1.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalOneDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 1.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalTwoDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 11.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalTwoDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 11.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalOneDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalTwoDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 12;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalZeroDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 0.1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalZeroDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 0.11;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountSSDecimalZeroDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountSS = 0.111;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }



    [TestMethod]
    public void AfterMountCSTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 100;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "AfterMountCS");
      Assert.IsTrue(found == true, "AfterMountCS error not found in Error List.");
    }

    [TestMethod]
    public void AfterMountCSDecimalTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param.AfterMountCS = 10.0001;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "AfterMountCS");
      Assert.IsTrue(found == true, "AfterMountCS error not found in Error List.");
    }

    [TestMethod]
    public void AfterMountCSDecimal3Digits()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 10.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalOneDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 1.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalOneDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 1.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalOneDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 1.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalTwoDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 11.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalTwoDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 11.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalOneDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalTwoDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 12;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalZeroDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 0.1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalZeroDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 0.11;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterMountCSDecimalZeroDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterMountCS = 0.111;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }



    [TestMethod]
    public void AfterTestSSTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 100;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "AfterTestSS");
      Assert.IsTrue(found == true, "AfterTestSS error not found in Error List.");
    }

    [TestMethod]
    public void AfterTestSSDecimalTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param.AfterTestSS = 10.0001;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "AfterTestSS");
      Assert.IsTrue(found == true, "AfterTestSS error not found in Error List.");
    }

    [TestMethod]
    public void AfterTestSSDecimal3Digits()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 10.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalOneDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 1.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalOneDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 1.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalOneDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 1.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalTwoDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 11.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalTwoDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 11.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalOneDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalTwoDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 12;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalZeroDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 0.1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalZeroDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 0.11;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestSSDecimalZeroDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestSS = 0.111;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }


    [TestMethod]
    public void AfterTestCSTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 100;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "AfterTestCS");
      Assert.IsTrue(found == true, "AfterTestCS error not found in Error List.");
    }

    [TestMethod]
    public void AfterTestCSDecimalTooBig()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param.AfterTestCS = 10.0001;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "AfterTestCS");
      Assert.IsTrue(found == true, "AfterTestCS error not found in Error List.");
    }

    [TestMethod]
    public void AfterTestCSDecimal3Digits()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 10.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalOneDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 1.002;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalOneDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 1.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalOneDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 1.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalTwoDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 11.2;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalTwoDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 11.02;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalOneDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalTwoDotZero()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 12;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalZeroDotOne()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 0.1;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalZeroDotTwo()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 0.11;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void AfterTestCSDecimalZeroDotThree()
    {
      ChassisHeightModel param = new ChassisHeightModel();
      param = GetDefaultParameter();
      param.AfterTestCS = 0.111;

      ValChassisHeightEdit valEdit = new ValChassisHeightEdit();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valEdit.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }
  }
}
