﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using QualityDatabase.Common;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;

namespace QualityDatabaseTest.Validation
{
  [TestClass]
  public class ValWaterTestCreateTest
  {
    private static bool IsMessageInErrorList(List<ValidationError> ErrorList, string message)
    {
      bool found = false;
      foreach (ValidationError err in ErrorList)
      {
        if (err.Message == message)
          found = true;
      }
      return found;
    }

    private static bool IsKeyInErrorList(List<ValidationError> ErrorList, string key)
    {
      bool found = false;
      foreach (ValidationError err in ErrorList)
      {
        if (err.Key == key)
          found = true;
      }
      return found;
    }


    [TestMethod]
    public void UserValuesNull()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = null;
      param.DefectItem = null;
      param.DefectType = null;
      param.InspectionType = null;
      param.GallonsPerMinute = null;
      param.WaterPressure = null;
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void UserValuesEmpty()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "NL";
      param.DefectItem = "NL";
      param.DefectType = "NL";
      param.InspectionType = "1ST";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void SerialNumberEmpty()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Serial Number missing.");
      Assert.IsTrue(found == true, "Serial Number error not found in Error List.");
    }

    [TestMethod]
    public void SerialNumberNull()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = null;
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);


      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Serial Number missing.");
      Assert.IsTrue(found == true, "Serial Number error not found in Error List.");
    }

      [TestMethod]
    public void UserNameNull()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = null;
      param.DefectItem = null;
      param.DefectType = null;
      param.InspectionType = null;
      param.GallonsPerMinute = null;
      param.WaterPressure = null;
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = null;

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "UserName missing.");
      Assert.IsTrue(found == true, "UserName missing error not found in Error List.");

    }

    [TestMethod]
    public void UserNameEmpty()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "UserName missing.");
      Assert.IsTrue(found == true, "UserName missing error not found in Error List.");
    }

    [TestMethod]
    public void GallonsPerMinute3Characters()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "123";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "GallonsPerMinute");
      Assert.IsTrue(found == true, "GallonsPerMinute error not found in Error List.");
    }

    [TestMethod]
    public void GallonsPerMinute2Alpha()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "AB";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "GallonsPerMinute");
      Assert.IsTrue(found == true, "GallonsPerMinute error not found in Error List.");
    }

    [TestMethod]
    public void GallonsPerMinuteDecimal()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = ".2";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "GallonsPerMinute");
      Assert.IsTrue(found == true, "GallonsPerMinute error not found in Error List.");
    }

    [TestMethod]
    public void GallonsPerMinuteNegative()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "-2";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "GallonsPerMinute");
      Assert.IsTrue(found == true, "GallonsPerMinute error not found in Error List.");
    }

    [TestMethod]
    public void GallonsPerMinuteValid1Digit()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "NL";
      param.DefectItem = "NL";
      param.DefectType = "NL";
      param.InspectionType = "1ST";
      param.GallonsPerMinute = "2";
      param.WaterPressure = "0";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void GallonsPerMinuteValid2Digits()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "NL";
      param.DefectItem = "NL";
      param.DefectType = "NL";
      param.InspectionType = "1ST";
      param.GallonsPerMinute = "88";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void GallonsPerMinuteValidZero()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "NL";
      param.DefectItem = "NL";
      param.DefectType = "NL";
      param.InspectionType = "1ST";
      param.GallonsPerMinute = "0";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }


    [TestMethod]
    public void WaterPressure3Characters()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "123";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "WaterPressure");
      Assert.IsTrue(found == true, "WaterPressure error not found in Error List.");
    }

    [TestMethod]
    public void WaterPressure2Alpha()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "AB";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "WaterPressure");
      Assert.IsTrue(found == true, "WaterPressure error not found in Error List.");
    }

    [TestMethod]
    public void WaterPressureDecimal()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = ".2";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "WaterPressure");
      Assert.IsTrue(found == true, "WaterPressure error not found in Error List.");
    }

    [TestMethod]
    public void WaterPressureNegative()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "-2";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsKeyInErrorList(ErrorList, "WaterPressure");
      Assert.IsTrue(found == true, "WaterPressure error not found in Error List.");
    }

    [TestMethod]
    public void WaterPressureValid1Digit()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "2";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void WaterPressureValid2Digits()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "55";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void WaterPressureValidZero()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "0";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }

    [TestMethod]
    public void WaterTestDateMinValue()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.MinValue;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Date is required.");
      Assert.IsTrue(found == true, "WaterTestDate error not found in Error List.");
    }

    [TestMethod]
    public void WaterTestDateToday()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty");

    }

    [TestMethod]
    public void WaterTestDateFutureDate()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Today.AddDays(1);
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Date cannot be later than today.");
      Assert.IsTrue(found == true, "WaterTestDate error not found in Error List.");
    }

    [TestMethod]
    public void WaterTestDateValidDate()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Today;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";

      ValWaterTestCreate valCreate = new ValWaterTestCreate();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valCreate.Validate(param);

      Assert.IsTrue(ErrorList.Count == 0, "ErrorList should be empty.");
    }
  }
}
