﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using QualityDatabase.Common;
using QualityDatabase.Validation;
using System;
using System.Collections.Generic;

namespace QualityDatabaseTest.Validation
{
  [TestClass]
  public class ValWaterTestDeleteTest
  {
    private static bool IsMessageInErrorList(List<ValidationError> ErrorList, string message)
    {
      bool found = false;
      foreach (ValidationError err in ErrorList)
      {
        if (err.Message == message)
          found = true;
      }
      return found;
    }

    private static bool IsKeyInErrorList(List<ValidationError> ErrorList, string key)
    {
      bool found = false;
      foreach (ValidationError err in ErrorList)
      {
        if (err.Key == key)
          found = true;
      }
      return found;
    }

    [TestMethod]
    public void SerialNumberEmpty()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = "";
      param.WaterTestCreatedBy = "SomeUser";
      param.WaterTestCreateDate = "010113";
      param.WaterTestCreateTime = "0101";

      ValWaterTestDelete valDelete = new ValWaterTestDelete();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Serial Number missing.");
      Assert.IsTrue(found == true, "Serial Number error not found in Error List.");
    }

    [TestMethod]
    public void SerialNumberNull()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.Now;
      param.SerialNumber = null;
      param.WaterTestCreatedBy = "SomeUser";
      param.WaterTestCreateDate = "010113";
      param.WaterTestCreateTime = "0101";

      ValWaterTestDelete valDelete = new ValWaterTestDelete();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(param);


      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Serial Number missing.");
      Assert.IsTrue(found == true, "Serial Number error not found in Error List.");
    }

    [TestMethod]
    public void CreateDateEmpty()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.MinValue;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";
      param.WaterTestCreateDate = "";
      param.WaterTestCreateTime = "0101";

      ValWaterTestDelete valDelete = new ValWaterTestDelete();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Record Create Date missing.");
      Assert.IsTrue(found == true, "WaterTestCreateDate error not found in Error List.");
    }

    [TestMethod]
    public void CreateDateNull()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.MinValue;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";
      param.WaterTestCreateDate = null;
      param.WaterTestCreateTime = "0101";

      ValWaterTestDelete valDelete = new ValWaterTestDelete();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Record Create Date missing.");
      Assert.IsTrue(found == true, "WaterTestCreateDate error not found in Error List.");
    }

    [TestMethod]
    public void CreateDateNotNumeric()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.MinValue;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";
      param.WaterTestCreateDate = "abc";
      param.WaterTestCreateTime = "0101";

      ValWaterTestDelete valDelete = new ValWaterTestDelete();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Record Create Date must be numeric.");
      Assert.IsTrue(found == true, "WaterTestCreateDate error not found in Error List.");
    }

    [TestMethod]
    public void CreateTimeEmpty()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.MinValue;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";
      param.WaterTestCreateDate = "010113";
      param.WaterTestCreateTime = "";

      ValWaterTestDelete valDelete = new ValWaterTestDelete();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Record Create Time missing.");
      Assert.IsTrue(found == true, "WaterTestCreateTime error not found in Error List.");
    }

    [TestMethod]
    public void CreateTimeNull()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.MinValue;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";
      param.WaterTestCreateDate = "010113";
      param.WaterTestCreateTime = null;

      ValWaterTestDelete valDelete = new ValWaterTestDelete();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Record Create Time missing.");
      Assert.IsTrue(found == true, "WaterTestCreateTime error not found in Error List.");
    }
    [TestMethod]
    public void CreateTimeNotNumeric()
    {
      ValWaterTestParameters param = new ValWaterTestParameters();
      param.DefectArea = "";
      param.DefectItem = "";
      param.DefectType = "";
      param.InspectionType = "";
      param.GallonsPerMinute = "";
      param.WaterPressure = "";
      param.WaterTestDate = DateTime.MinValue;
      param.SerialNumber = "abcdef";
      param.WaterTestCreatedBy = "SomeUser";
      param.WaterTestCreateDate = "010113";
      param.WaterTestCreateTime = "abcd";

      ValWaterTestDelete valDelete = new ValWaterTestDelete();

      List<ValidationError> ErrorList = new List<ValidationError>();
      ErrorList = valDelete.Validate(param);

      Assert.IsTrue(ErrorList.Count > 0, "ErrorList empty, should have at least one entry.");

      bool found = false;
      found = IsMessageInErrorList(ErrorList, "Record Create Time must be numeric.");
      Assert.IsTrue(found == true, "WaterTestCreateTime error not found in Error List.");
    }
  }
}
